This file provides a guide to the replication files for "Sectoral vs. Aggregate Shocks: A Structural Factor Analysis of Industrial Production," by Andrew Foerster, Pierre-Daniel Sarte, and Mark Watson, January, 2011.

All programs are in GAUSS (run under GAUSS 10.0.). The programs are in the subdirectory ..\gss
 
Data files are Excel files and are in the subdirectory ...\data. 

Data:

1. The IO tables for the benchmark years 1977 and 1998, for different levels of disaggregation,  are in the files IO77.xls and IO98.xls respectively.

2. The capital flow table for 1998 is is CapFlow98.gss

3. The files IP77.xls and IP98.xls contain the IP data (sectoral indices and shares using different levels of disaggregation) broken down by SIC and NAICS code respectively.

Programs:

Preliminaries:  

(1) IPload_77.gss and IPload_98.gss load the IP data in Excel format and produce corresponding .fmt data saved  in the subdirectory ...\fmt.

(2) Gam_alpha_77.gss and gam_alpha_98.gss load the GAMMA and Alpha_d matrices for the IO tables.

(3) GetTheta98.gss loads the capital flow table Theta.


Models:  The various models are solved using programs in the ..\gss\models folder.
   Notes: 
     (1) The paper uses the matrices, Phi, Theta_0 and Theta_1 for the ARMA(1,1) Coefficient Matrices
         In the various programs these are called "Cap_Rho", "PII_A" and "XI";
     (2) The model parameters, gamma, theta, alpha, are stored as GAUSS files in ..\gss\fmt
     (3) The average value of gamma and alpha used in the results in Table 8 are computed using the program AVG_GAMMA_ALPHA.GSS
     (4) The benchmark model (NAICS, 117 sectors, 4 digit level), and its special cases with are solved using RESOLKW_98.GSS.  Note that this program calls MODELS_98.GSS which reads in the various models parameters and so forth.  MODELS_98.GSS must be modified to construct solutions to the various models -- see the comments in the program. 
     (5) The benchmark model (NAICS, 26 sectors,  2 digit level) is solved using RESOLKW_98_2.GSS.
     (6) The benchmark model (NAICS, 88 sectors,  3 digit level) is solved using RESOLKW_98_3.GSS.        
     (7) The model with Theta = I (SIC, 109 Sectors) using the 1977 value for Gamma is computed in RESOLKW_77.GSS 



Figures:
Figure 1:  
 Monthly Data are from produced using FIGURE_1_A.GSS
 Quarterly Data are from UNIVARIATESUMMARY_Q.GSS
 Plot is constructed in FIGURE_1.GSS
Figure 2: produced usuing UNIVARIATESUMMARY_Q.GSS
Figure 3: produced usuing UNIVARIATESUMMARY_Q.GSS  
Figure 4: produced in FACTOR.GSS
Figure 5: produced in FACTOR.GSS
Figure 6: produced in GRAPH_GAMMA_THETA.GSS

Tables:
Appendix Table A.1: produced usuing UNIVARIATESUMMARY_Q.GSS
Table 1: produced usuing UNIVARIATESUMMARY_Q.GSS  
Table 2: produced usuing UNIVARIATESUMMARY_Q.GSS  
Table 3: produced usuing UNIVARIATESUMMARY_Q.GSS  
Table 4: produced in factor.gss
Table 5: produced in factor.gss
Table 6: produced in factor.gss
Table 7: produced in factor_io.gss
Table 8: produced in table_8.gss
Table 9: 2 digit results from factor_io_2.gss; 3 digit from factor_io_3.gss; 4 digit from factor_io.gss
Table 10: Results for NAICS are computed in factor_io_thetai.gss
          Results for SIC are computed in factor_io_77.gss and factor_77.gss
Table 11: These results are from factor_io_77.gss (panel A), factor_io_thetai.gss (panel B), and factor_io.gss (panel C).










 



 

     







