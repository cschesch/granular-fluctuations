%% CODES FOR SECTION IIA1
% 1) Assembles fundamental volatility measures
% 2) Constructs measures of volatility in quarterly GDP for US
% 3) Outputs Table 1 Regressions
% 4) Outputs Figure 1
% 5) Computes analysis of sectoral TFP variance in split sample

%% 1) ASSEMBLE FUNDAMENTAL VOLATILITY MEASURE & VARIANTS THEREOF

%Load US sector data

load allUSdata.mat;

%Compute baseline measure Sig_F and alternative, Sig_F_Full (taking into
%account TFP covariances) for Annual data and Quarterly Interpolation
%Annual Sig_F and Sig_F_Full measures
covstfpsv=cov((stfp(1:end,2:end)'));

for k=1:size(dweightalt,2)
    for i=1:size(dweightalt,1)
        sigfun(i,k)=0;
        sigfun(i,k)=((((covstfpsv(i,i))))*(dweightalt(i,k)*dweightalt(i,k)))+sigfun(i,k);
        sigfunx(i,k)=0;
        for j=1:size(dweightalt,1)
            sigfunx(i,k)=((covstfpsv(i,j))*(dweightalt(i,k)*dweightalt(j,k)))+sigfunx(i,k);
        end
    end
end

sigfun=sum(sigfun); %This is Sig_F^2 
sigfunx=sum(sigfunx);  %This is Sig_F_Full^2 

%Quarterly version of Sigma_F, Sigma_F_Full
%Interpolate (Linearly) to get Quarterly version of Fundamental Vol. measures

xi=1960:0.25:2008.75;
xi=xi';
y=sigfunx;
sigfunxq = interp1(1960:2008,y,xi,'linear');
y=sigfun;
sigfunq = interp1(1960:2008,y,xi,'linear');

%% 2) CONSTRUCT MEASURES OF VOLATILITY IN GDP

%Load QGDP Growth for Sigma_Y_Inst measure
qgdp = xlsread('qgdp.xls');
qgdp=qgdp./100;
%AR(1) regression of growth rates; retrieve absolute values of residuals
whichstats = {'tstat','r'};
qgdpoutr=regstats(qgdp(2:size(sigfunq-3,1)),qgdp(1:size(sigfunq-3,1)-1), 'linear', whichstats);
absqr=abs(qgdpoutr.r);

%Load QGDP levels for Sigma_Y_Roll measure
load qgdpl.mat

%Construct Sigma_Y_RollQ: Quarterly rolling window volatility measure

%Deviations of log levels from HP filter, 1600 Smoothing Parameter for
%Quarterly data
qgdplhp=hpfilter(log(qgdpl),1600);
qgdpdev=log(qgdpl)-qgdplhp;
%Rolling Centered standard deviation over 41 quarters
for i=21:(max(size(qgdpdev))-20)
    stdr(i)=std(qgdpdev(i-20:i+20));
end
%Progressively more uncentered for end of sample 
for i=1:20
    j=max(size(qgdpdev))-20+i;
    stdruc(j)=std(qgdpdev(j-20:max(size(qgdpdev))));
end
stdruc(1:max(size(qgdpdev))-20)=stdr;

%Construct Sigma_Y_Roll_A: Annual rolling window volatility measure
%4-quarter average of quarterly measure

for i=0:4:(max(size(stdruc))-4)
    stdrucannual(i+1)=mean(stdruc(i+1:i+4));
end
stdrucannual5209=nonzeros(stdrucannual);

%Construct Sigma_Y_Inst_A: Annual Instantaneous volatility measure as
%defined in paper

for i=4:4:(max(size(absqr)))
    stdiannual(i)=mean(2*sqrt(pi/2)*absqr(i:i+3));
end
stdiannual(1)=mean(2*sqrt(pi/2)*absqr(1:4));
stdiannual6008=nonzeros(stdiannual);



%% 3) Basic OLS Regressions
whichstats = {'tstat','yhat','rsquare','r'};

% Baseline Annual Regressions
% TABLE 1 REGRESSIONS
% Sigma_Y_Roll
absrfun=regstats(((stdrucannual5209(9:end-1))),[sqrt(sigfun)], 'linear', whichstats);
% Sigma_Y_Roll Regression Output
absrfun.tstat.beta
absrfun.tstat.se
absrfun.tstat.t
absrfun.rsquare
% Sigma_Y_Inst
absifun=regstats(((stdiannual6008)),[sqrt(sigfun(1:end))], 'linear', whichstats);
% Sigma_Y_Inst Regression Output
absifun.tstat.beta
absifun.tstat.se
absifun.tstat.t
absifun.rsquare

% Robustness checks with quarterly data
absrfunq=regstats(stdruc(53:248),sqrt(sigfunq((1:end)')), 'linear', whichstats);
absifunq=regstats((2*sqrt(pi/2).*absqr),sqrt(sigfunq((2:end)')), 'linear', whichstats);



%% 4) FIGURE 1
% All figures are demeaned as in paper

%FIGURE 1
smoothing_param_annual_hp=6.5;
plot(1960:2008,stdrucannual5209(9:end-1)-mean(stdrucannual5209(9:end-1)),'-', 1960:2008, hpfilter(stdiannual6008,smoothing_param_annual_hp)-mean(hpfilter(stdiannual6008,smoothing_param_annual_hp)),'o-', 1960:2008, 4.5*sqrt(sigfun)-mean(4.5*sqrt(sigfun)),'s-r')
xlabel('year')
ylabel('Cyclical Volatility (demeaned)')
grid on
axis tight


%% 5) SPLIT SAMPLE ANALYSIS FOR SECTORAL TFP GROWTH VOLATILITY

% Cross-sector Average of Sectoral TFP growth variances: pre 1984 v post 84
stdev_prepost=[std(stfp(:,2:24)')' std(stfp(:,25:end)')'];
mean(stdev_prepost); % gives mean sectoral volatility in each period
% T-TEST for equality of mean volatility
[h,p] = ttest2(stdev_prepost(:,1),stdev_prepost(:,2))

% LEVENE's test for equal variances for each sectoral TFP growth series
% Comparing pre-1984 vs. post 1984 samples.
% Note: Need equally sized samples of growth rates for each sector in order 
%       to implement Levene's test so comparing 1962-198 vs 1984-2005

for i=1:77
    [p(i), Stats]=vartestn([stfp([i],25:end')',(stfp([i] ,3:24'))'],[],'off','robust');
end
n_sectors_stat_dif_variance=size(find(p<0.05),2);


%% Output the baseline series

GDPvol_SigmaF=[[1960:2008]' stdrucannual5209(9:end-1) stdiannual6008 sqrt(sigfun)'] % Year Sigma_Y_Roll Sigma_Y_Inst Sigma_F

save GDPvol_SigmaF.mat GDPvol_SigmaF