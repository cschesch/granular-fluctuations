// CODES FOR SECTION IIB
// Implements International Panel Regressions 
// Outputs Table 3


/* NOTE 1: Adjust path in "use" command below to your directory */
/* NOTE 2: This requires the newey2 function. To install type: ssc install newey2 */

clear all

use "C:\Users\Vasco\Dropbox\greatdiv_latest\Revision_AER\Carvalho_Gabaix_AER_Final_Codes\Section II\SectionIIB_Panel_Data.dta"

xtset var4 var1, yearly


// TABLE 3 Panel Regressions//

/* Country fixed effects; two lags for Newey-West Std. Errors */


xi: newey2 var2 var3 i.var4 if var4<6,lag(2)


/* Country fixed effects and time fixed effects; two lags for Newey-West Std. Errors */


xi: newey2 var2 var3 i.var4 i.var1 if var4<6,lag(2)




// Extra Results//

/* Country fixed effects and linear time trend; two lags for Newey-West Std. Errors */

xi: newey2 var2 var3 var10 i.var4 if var4<6,lag(2)


/* Country fixed effects with JS measure; two lags for Newey-West Std. Errors */


xi: newey2 var2 var3 var11 i.var4 if var4<6,lag(2)


/* Country and time fixed effects with JS measure; two lags for Newey-West Std. Errors */


xi: newey2 var2 var3 var11 i.var4 i.var1 if var4<6,lag(2)


/* Country fixed effects with JS measure & interaction ; two lags for Newey-West Std. Errors */


xi: newey2 var2 var3 var11 var14 i.var4 if var4<6,lag(2)


/* Country and time fixed effects with JS measure & interaction; two lags for Newey-West Std. Errors */


xi: newey2 var2 var3 var11 var14 i.var4 i.var1 if var4<6,lag(2)


