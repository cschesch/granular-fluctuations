%% CODES FOR SECTION IIB
% 1) & 2) Imports GDP data and computes country-specific business cycle
% volatility
% 3) % 4) Imports country-specific fundamental volatility measures and Outputs Figure 2

%% 1) IMPORT GDP DATA
newData1 = importdata('SW_Q_GDP_Rev2.xls');

% Create new variables in the base workspace from those fields.
vars = fieldnames(newData1);
for i = 1:length(vars)
    assignin('base', vars{i}, newData1.(vars{i}));
end

G7GDP=data;

clear data newData1 textdata vars i

%% 2) COMPUTE COUNTRY-SPECIFIC BUSINESS CYCLE VOLATILITY
% Computing Deviations from HP trend and then computing rolling window
% standard deviations (40 quarter centered window) for each country

%UK
qgdplhp=hpfilter(log(G7GDP(1:end,1)),1600);
qgdpdev=(log(G7GDP(1:end,1)))-qgdplhp;

for i=21:(max(size(qgdpdev))-20)
    stdruk(i)=std(qgdpdev(i-20:i+20));
end

for i=0:4:(max(size(stdruk))-4)
    stdrannualuk(i+1)=mean(stdruk(i+1:i+4));
end

stdrannualuk6504=nonzeros(stdrannualuk);
stdrannualuk7004=stdrannualuk6504(6:end);


%JAPAN
qgdplhpjp=hpfilter(log(G7GDP(1:end,2)),1600);
qgdpdevjp=(log(G7GDP(1:end,2)))-qgdplhpjp;

for i=21:(max(size(qgdpdevjp))-20);
    stdrjp(i)=std(qgdpdevjp(i-20:i+20));
end

for i=0:4:(max(size(stdrjp))-4)
    stdrannualjp(i+1)=mean(stdrjp(i+1:i+4));
end
stdrannualjp6504=nonzeros(stdrannualjp);
stdrannualjp7004=stdrannualjp6504(6:end);

%GERMANY
qgdplhpg=hpfilter(log(G7GDP(2:end,3)),1600);
qgdpdevg=(log(G7GDP(2:end,3)))-qgdplhpg;
qgdpdevg=[NaN;qgdpdevg];

for i=21:(max(size(qgdpdevg))-20);
    stdrg(i)=std(qgdpdevg(i-20:i+20));
end

for i=0:4:(max(size(stdrg))-4)
    stdrannualg(i+1)=mean(stdrg(i+1:i+4));
end

stdrannualg6504=nonzeros(stdrannualg);
stdrannualg7004=stdrannualg6504(6:end);

%FRANCE
qgdplhpfr=hpfilter(log(G7GDP(13:end,4)),1600);
qgdpdevfr=(log(G7GDP(13:end,4)))-qgdplhpfr;
qgdpdevfr=[NaN; NaN;NaN; NaN;NaN; NaN;NaN; NaN;NaN; NaN;NaN; NaN;qgdpdevfr];

for i=21:(max(size(qgdpdevfr))-20);
    stdrfr(i)=std(qgdpdevfr(i-20:i+20));
end

for i=0:4:(max(size(stdrfr))-4)
    stdrannualfr(i+1)=mean(stdrfr(i+1:i+4));
end
stdrannualfr6004=nonzeros(stdrannualfr);
stdrannualfr7004=stdrannualfr6004(6:end);


%% 3) LOAD INTERNATIONAL FUNDAMENTAL VOLATILITY MEASURES
newData1 = importdata('EUKLEMS_Sigma2_Rev_Final.xls');

% Create new variables in the base workspace from those fields.
vars = fieldnames(newData1);
for i = 1:length(vars)
    assignin('base', vars{i}, newData1.(vars{i}));
end

SigmaF=sqrt(data(:, 2:end));

clear data newData1 textdata vars i


%% 4) FIGURE 2
subplot(2,2,1)
plot(1970:2004,hpfilter(stdrannualuk7004,2)-mean(hpfilter(stdrannualuk7004,6.5)),'-', 1970:2004, 4.5*SigmaF(1:end-1,1)-mean(4.5*SigmaF(1:end-1,1)),'o-r')
xlabel('year')
ylabel('Cyclical Volatility (demeaned)')
title('UK')
grid on
axis([1970 2004 -0.01 0.015])

subplot(2,2,2)
plot(1973:2004,hpfilter(stdrannualjp7004(1:end-3),6.5)-mean(hpfilter(stdrannualjp7004(1:end-3),6.5)),'-', 1973:2004, 4.5*SigmaF(4:end-1,2)-mean(4.5*SigmaF(4:end-1,2)),'o-r')
xlabel('year')
ylabel('Cyclical Volatility (demeaned)')
title('JAPAN')
grid on
axis([1973 2004 -0.01 0.015])

subplot(2,2,3)
plot(1970:2004,hpfilter(stdrannualg7004,6.5)-mean(hpfilter(stdrannualg7004,6.5)),'-', 1970:2004, 4.5*SigmaF(1:end-1,3)-mean(4.5*SigmaF(1:end-1,3)),'o-r')
xlabel('year')
ylabel('Cyclical Volatility (demeaned)')
title('GERMANY')
grid on
axis([1970 2004 -0.01 0.015])

subplot(2,2,4)
plot(1970:2004,hpfilter(stdrannualfr7004,6.5)-mean(hpfilter(stdrannualfr7004,6.5)),'-', 1970:2004, 4.5*SigmaF(1:end-1,4)-mean(4.5*SigmaF(1:end-1,4)),'o-r')
xlabel('year')
ylabel('Cyclical Volatility (demeaned)')
title('FRANCE')
grid on
axis([1970 2004 -0.01 0.015])
