%% CODES FOR SECTION IIIB1
% 1) Computes H Statistic
% 2) Outputs Figure 4 and 5

%% 1) H STATISTICS

%Load US sector data

load allUSdata.mat;

% Compute baseline measure Sig_F for Annual data
covstfpsv=cov((stfp(1:end,2:end)'));

for k=1:size(dweightalt,2)
    for i=1:size(dweightalt,1)
        sigfun(i,k)=0;
        sigfun(i,k)=((((covstfpsv(i,i))))*(dweightalt(i,k)*dweightalt(i,k)))+sigfun(i,k);
        sigfunx(i,k)=0;
        for j=1:size(dweightalt,1)
            sigfunx(i,k)=((covstfpsv(i,j))*(dweightalt(i,k)*dweightalt(j,k)))+sigfunx(i,k);
        end
    end
end

sigfun=sum(sigfun); %This is Sig_F^2 


% Compute H statistics

for i=1:max(size(covstfpsv))
    h(i,:)=((dweightalt(i,:).^2)*covstfpsv(i,i));
end

% 1960-1989
t1=1;
t2=30;
H6089=((h(:,t2)-h(:,t1))/(sigfun(t2)-sigfun(t1)))';
% 1971-1980
t1=12;
t2=21;
H7180=((h(:,t2)-h(:,t1))/(sigfun(t2)-sigfun(t1)))';
%1981-1986
t1=20;
t2=27;
H8186=((h(:,t2)-h(:,t1))/(sigfun(t2)-sigfun(t1)))';
% 1990-2006
t1=31
t2=47;
H9006=((h(:,t2)-h(:,t1))/(sigfun(t2)-sigfun(t1)))';

% OUTPUT: H's reported in text
H6089_Heavy_manuf=H6089(8)+H6089(12)+H6089(13)+H6089(14)+H6089(21) % Heavy manufacturing 1960-1989
H7180_Energy_related=H7180(7)+H7180(39) % Energy sectors 1971-1980
H8186_Energy_related=H8186(7)+H8186(39) % Energy sectors 1981-1986
H8186_Manuf_plus_Chemicals=H8186(12)+H8186(13)+H8186(14)+H8186(21)+H8186(37) % Heavy manufacturing + chemicals 1981-1986
H9006_Finance_Related=H9006(56)+H9006(57)+H9006(58) % Finance related sectors 1990-2006

%% FIGURES 4 AND 5
% Preliminary Computations
for i=1:size(dweightalt,1)
    for j=2:size(dweightalt,2)
        deltadw2(i,j)=((dweightalt(i,j)^2)*covstfpsv(i,i)-(dweightalt(i,j-1)^2)*covstfpsv(i,i));
        
    end
end

for i=1:size(dweightalt,1)
    for j=1:size(dweightalt,2)
        dw2(i,j)=((dweightalt(i,j)^2)*covstfpsv(i,i))/sigfun(j);
    end
end

for i=1:size(grossalt,1)
    for j=1:size(grossalt,2)
        dweight2_sans_oil(i,j)=(grossalt(i,j)/(sum(vaddalt(:,j))));
        dweight2_sans_fin(i,j)=(grossalt(i,j)/(sum(vaddalt(:,j))));
        dweight2_sans_consmanuf(i,j)=(grossalt(i,j)/(sum(vaddalt(:,j))));
    end
end

% Preliminary Computations for Figure 4
dweight2_sans_consmanuf(8,:)=mean(dweight2_sans_consmanuf(8,:));
dweight2_sans_consmanuf(12,:)=mean(dweight2_sans_consmanuf(12,:));
dweight2_sans_consmanuf(13,:)=mean(dweight2_sans_consmanuf(13,:));
dweight2_sans_consmanuf(14,:)=mean(dweight2_sans_consmanuf(14,:));
dweight2_sans_consmanuf(21,:)=mean(dweight2_sans_consmanuf(21,:));

for i=1:size(grossalt,1)
    for j=1:size(grossalt,2)
        sigfuni_sans_consmanuf(i,j)=(dweight2_sans_consmanuf(i,j).^2)*covstfpsv(i,i);
    end
end

sigfun_sans_consmanuf=sqrt(sum(sigfuni_sans_consmanuf));
a= 4.5*sigfun_sans_consmanuf-mean(4.5*sigfun_sans_consmanuf);

% FIGURE 4
subplot(1,2,1)
plot(1960:2008,dw2(1,:)+dw2(12,:)+dw2(13,:)+dw2(14,:)+dw2(21,:))
xlabel('years');
ylabel('Weight of Heavy Manufacturing in   \sigma_F(t)^2');
grid on
axis tight

subplot(1,2,2)
plot(1960:2008,4.5*sqrt(sigfun)-mean(4.5*sqrt(sigfun)),1960:2008,a,'o-'); 
ylabel('Fundamental Volatility');
xlabel('years'); 
grid on
axis tight


% Preliminary Computations for Figure 5
dweight2_sans_fin(56,:)=mean(dweight2_sans_fin(56,:));
dweight2_sans_fin(57,:)=mean(dweight2_sans_fin(57,:));
dweight2_sans_fin(58,:)=mean(dweight2_sans_fin(58,:));

for i=1:size(grossalt,1)
    for j=1:size(grossalt,2)
        sigfuni_sans_fin(i,j)=(dweight2_sans_fin(i,j).^2)*covstfpsv(i,i);
    end
end
sigfun_sans_fin=sqrt(sum(sigfuni_sans_fin));
clear c
c=4.5*sigfun_sans_fin-mean(4.5*sigfun_sans_fin);

% FIGURE 5
subplot(1,2,1)
b=((dweightalt(56,:).^2)*(covstfpsv(56,56))+covstfpsv(57,57)*(dweightalt(57,:).^2)+(dweightalt(58,:).^2)*(covstfpsv(58,58)))./sigfun;
plot(1960:2004, dw2(56,1:45)+dw2(57,1:45)+dw2(58,1:45))
xlabel('year')
ylabel('Weight of Finance-related Sectors in  \sigma_F(t)^2')
grid on
axis tight

subplot(1,2,2)
plot(1960:2005,4.5*sqrt(sigfun(1,1:46))-mean(4.5*sqrt(sigfun(1,1:46))),1960:2005,c(1:46),'o-'); 
xlabel('years'); ylabel('Fundamental Volatility');
grid on
axis tight

