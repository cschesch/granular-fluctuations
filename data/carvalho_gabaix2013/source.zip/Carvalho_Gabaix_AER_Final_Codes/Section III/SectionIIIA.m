%% CODES FOR SECTION IIIA 
% 1) Assembles baseline fundamental volatility measure
% 2) Computes counterfactual volatility measures
% 3) Outputs Figure 3


%% 1) ASSEMBLE FUNDAMENTAL VOLATILITY MEASURE

%Load US sector data

load allUSdata.mat;

%Compute baseline measure Sig_F and alternative, Sig_F_Full (taking into
%account TFP covariances) for Annual data
covstfpsv=cov((stfp(1:end,2:end)'));

for k=1:size(dweightalt,2)
    for i=1:size(dweightalt,1)
        sigfun(i,k)=0;
        sigfun(i,k)=((((covstfpsv(i,i))))*(dweightalt(i,k)*dweightalt(i,k)))+sigfun(i,k);
        sigfunx(i,k)=0;
        for j=1:size(dweightalt,1)
            sigfunx(i,k)=((covstfpsv(i,j))*(dweightalt(i,k)*dweightalt(j,k)))+sigfunx(i,k);
        end
    end
end

sigfun=sum(sigfun); %This is Sig_F^2 
sigfunx=sum(sigfunx);  %This is Sig_F_Full^2 

SigF=sqrt(sigfun);

%% 2) ASSEMBLE COUNTERFACTUAL FUNDAMENTAL VOLATILITY MEASURE

% Compute Counterfactual Fundamental Volatility Measures to display in
% Figure 3 of paper

% Sig_F_Bar = holding fixed time variation in sector gross-output to value
% added weights (fixed at sample average for each sector)
% Sig_F_Tilda = holding fixed time variation in sector value added weight
% weights (fixed at sample average for each sector)
% Sig_F_Hat = holding fixed cross sectional variation sectoral TFP
% variances (fixed at sample average across sectors)

% Preliminaries
% Form Sector Gross Ouput over Sector Value Added Matrix (sector by year)
% grossalt variable is gross output for all sectors

for i=1:size(grossalt,1)
    for j=1:size(grossalt,2)
        S_Y(i,j)=grossalt(i,j)/vaddalt(i,j);
        S_Y2(i,j)=S_Y(i,j)^2;
    end
end

% Form Sector Value Added Weights (sector by year)
% vaddalt variable is gross output for all sectors

for i=1:size(vaddalt,1)
    for j=1:size(vaddalt,2)
        Y_totY(i,j)=vaddalt(i,j)/sum(vaddalt(:,j));
        Y_totY2(i,j)=Y_totY(i,j)^2;
    end
end

% Now construct counterfactual fundamental volatility measures by fixing 1 at a time
% Alternative Fundamental Vol with Fixed Sales over Value Added
for i=1:size(vaddalt,1)
    for j=1:size(vaddalt,2)
        SigF_Bar(i,j)=((mean(S_Y(i,:))*Y_totY(i,j))^2)*covstfpsv(i,i);
    end
end

SigF_Bar=sqrt(sum(SigF_Bar));

% Alternative Fundamental Vol with Fixed Value Added Wieghts 
for i=1:size(vaddalt,1)
    for j=1:size(vaddalt,2)
        SigF_Tilda(i,j)=((S_Y(i,j)*(mean(Y_totY(i,:))))^2)*covstfpsv(i,i);
    end
end

SigF_Tilda=sqrt(sum(SigF_Tilda));

% Alternative Fundamental Vol with Average Sectoral TFP variance

for i=1:size(vaddalt,1)
    for j=1:size(vaddalt,2)
        SigF_Hat(i,j)=((S_Y(i,j)*Y_totY(i,j))^2)*mean(diag(covstfpsv));
    end
end

SigF_Hat=sqrt(sum(SigF_Hat));

%% 3) FIGURE 3
subplot(1,3,1)
plot(1960:2008,4.5*(SigF)-mean(4.5*(SigF)),'-', 1960:2008,4.5*SigF_Bar-mean(4.5*SigF_Bar),'o-r')
xlabel('year')
ylabel('Fundamental Volatility (demeaned)')
title('PANEL A')
grid on
axis([1960 2008 -0.01 0.01])
axis square

subplot(1,3,2)
plot(1960:2008,4.5*(SigF)-mean(4.5*(SigF)),'-', 1960:2008,4.5*SigF_Tilda-mean(4.5*SigF_Tilda),'o-r')
xlabel('year')
ylabel('Fundamental Volatility (demeaned)')
title('PANEL B')
grid on
axis([1960 2008 -0.01 0.01])
axis square

subplot(1,3,3)
plot(1960:2008,4.5*(SigF)-mean(4.5*(SigF)),'-', 1960:2008,4.5*SigF_Hat-mean(4.5*SigF_Hat),'o-r')
xlabel('year')
ylabel('Fundamental Volatility (demeaned)')
title('PANEL C')
grid on
axis([1960 2008 -0.01 0.01])
axis square
