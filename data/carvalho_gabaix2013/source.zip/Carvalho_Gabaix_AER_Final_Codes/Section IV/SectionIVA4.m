%% CODES FOR SECTION IVA4
% 1) Assembles fundamental volatility measure from value added perspective
% 2) Assembles measures of time varying volatility in US GDP
% 3) Outputs regression results 

%% 1) ASSEMBLE FUNDAMENTAL VOLATILITY MEASURE- VALUE ADDED PERSPECTIVE
%Load US sector data

load allUSdata.mat;
%Compute Sig_F_VA (VALUE ADDED PERSPECTIVE) for Annual data
covstfpsv_va=cov((stfpva(1:end,2:end)'));

for i=1:77
    for j=1:49
        vadd_weight_alt(i,j)=vaddalt(i,j)/(sum(vaddalt(:,j)));
    end
end
    

for k=1:size(dweightalt,2)
    for i=1:size(dweightalt,1)
        sigfun_va(i,k)=0;
        sigfun_va(i,k)=((((covstfpsv_va(i,i))))*(vadd_weight_alt(i,k)*vadd_weight_alt(i,k)))+sigfun_va(i,k);
        sigfunx_va(i,k)=0;
        for j=1:size(dweightalt,1)
            sigfunx_va(i,k)=((covstfpsv_va(i,j))*(vadd_weight_alt(i,k)*vadd_weight_alt(j,k)))+sigfunx_va(i,k);
        end
    end
end

sigfun_va=sum(sigfun_va);  % This is Sig_F_VA^2

%Quarterly version of Sigma_F, Sigma_F_Full
%Interpolate (Linearly) to get Quarterly version of Fundamental Vol. measures

xi=1960:0.25:2008.75;
xi=xi';
y=sigfun_va;
sigfun_vaq = interp1(1960:2008,y,xi,'linear');

%% 2) CONSTRUCT MEASURES OF VOLATILITY IN GDP

%Load QGDP Growth for Sigma_Y_Inst measure
qgdp = xlsread('qgdp.xls');
qgdp=qgdp./100;
%AR(1) regression of growth rates; retrieve absolute values of residuals
whichstats = {'tstat','r'};
qgdpoutr=regstats(qgdp(2:size(sigfun_vaq-3,1)),qgdp(1:size(sigfun_vaq-3,1)-1), 'linear', whichstats);
absqr=abs(qgdpoutr.r);

%Load QGDP levels for Sigma_Y_Roll measure
load qgdpl.mat

%Construct Sigma_Y_RollQ: Quarterly rolling window volatility measure

%Deviations of log levels from HP filter, 1600 Smoothing Parameter for
%Quarterly data
qgdplhp=hpfilter(log(qgdpl),1600);
qgdpdev=log(qgdpl)-qgdplhp;
%Rolling Centered standard deviation over 41 quarters
for i=21:(max(size(qgdpdev))-20)
    stdr(i)=std(qgdpdev(i-20:i+20));
end
%Progressively more uncentered for end of sample 
for i=1:20
    j=max(size(qgdpdev))-20+i;
    stdruc(j)=std(qgdpdev(j-20:max(size(qgdpdev))));
end
stdruc(1:max(size(qgdpdev))-20)=stdr;

%Construct Sigma_Y_Roll_A: Annual rolling window volatility measure
%4-quarter average of quarterly measure

for i=0:4:(max(size(stdruc))-4)
    stdrucannual(i+1)=mean(stdruc(i+1:i+4));
end
stdrucannual5209=nonzeros(stdrucannual);

%Construct Sigma_Y_Inst_A: Annual Instantaneous volatility measure as
%defined in paper

for i=4:4:(max(size(absqr)))
    stdiannual(i)=mean(2*sqrt(pi/2)*absqr(i:i+3));
end
stdiannual(1)=mean(2*sqrt(pi/2)*absqr(1:4));
stdiannual6008=nonzeros(stdiannual);

%% 3) REGRESSIONS
whichstats = {'tstat','yhat','rsquare','r'};
%Sigma_Y_Roll measure
absrfun_va=regstats(((stdrucannual5209(9:end-1))),[sqrt(sigfun_va)], 'linear', whichstats);
%Output
absrfun_va.tstat.beta;
absrfun_va.tstat.se;
absrfun_va.tstat.t;
absrfun_va.rsquare % Output R^2

%Sigma_Y_Inst measure
absifun_va=regstats(((stdiannual6008)),[sqrt(sigfun_va(1:end))], 'linear', whichstats);
absifun_va.tstat.beta;
absifun_va.tstat.se;
absifun_va.tstat.t;
absifun_va.rsquare % Output R^2

