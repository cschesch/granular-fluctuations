######################################################
######################################################
### Clean and Prepare Workspace
######################################################
######################################################

######################################################
### Wipe Down Workspace
rm(list=ls())

######################################################
### Load Packages
library(foreign)
library(reshape)
library(plm)
library(plyr)
library(ggplot2)
library(matlab)
library(xtable)
library(tikzDevice)
library(Formula)
library(strucchange)
library(mFilter)
library(gmm)
library(car)
























######################################################
######################################################
### Setup GreatDiv Data Object
######################################################
######################################################

######################################################
### Define Function to Pull Compustat Data
PullGlobalCompustatData <- function() {
  
  setClass("CompData",
           representation(data    = "data.frame",
                          dataDir = "character"
                          )
           )
  object <- new("CompData")
  
  object@data        <- read.csv(paste(getwd(),'/data/compustatData.csv',sep =''), stringsAsFactors = FALSE )
  object@data        <- object@data[,c('gvkey','fyear','emp','sale','sic')]
  names(object@data) <- c('id','year','globalEmployees','globalSales','sic')
  
  object@data <- object@data[!is.na(object@data$id),]
  object@data <- unique(object@data)

  return(object@data)
  
}



######################################################
### Define Function to Pull CPI Data
PullAnnualCpiData <- function(...) UseMethod('PullAnnualCpiData')

PullAnnualCpiData.default <- function(...) {
  
  setClass("AnnualCpiData",
           representation(data    = "data.frame",
                          dataDir = "character"
                          )
           )

  object <- new("AnnualCpiData")
  
  object@data        <- read.csv(paste(getwd(),'/data/fredCpiData.csv',sep=''), stringsAsFactors = FALSE)
  names(object@data) <- c('dateString','cpi')
  
  object@data$dt <- 0
  for (DATE in object@data$dateString) {
    object@data[object@data$dateString == DATE,]$dt <- as.numeric(unlist(strsplit(DATE,'-'))[1])
  }
  
  object@data        <- ddply(object@data, c('dt'), function(X)mean(X$cpi, na.rm =TRUE))
  names(object@data) <- c('dt','cpi')
  
  return(object@data)
  
}


######################################################
### Define Function to Pull GDP Data
PullQuarterlyRealGdpData <- function(...) UseMethod('PullQuarterlyRealGdpData')

PullQuarterlyRealGdpData.default <- function(...) {
  
  setClass("QuarterlyRealGdpData",
           representation(data    = "data.frame",
                          freq    = "character",
                          dataDir = "character"
                          )
           )
  
  object <- new("QuarterlyRealGdpData")

  object@data        <- read.csv(paste(getwd(),'/data/fredRealGdp_quarterly.csv',sep=''), stringsAsFactors = FALSE)
  names(object@data) <- c('date','gdp')
  object@data$date   <- as.character(object@data$date)
  object@data$year   <- object@data$quarter <- object@data$dt <- NA
  
  for (ROW in 1:dim(object@data)[1]) {
    object@data$year[ROW]    <- as.numeric(unlist(strsplit(object@data$date[ROW],'-'))[1])
    object@data$quarter[ROW] <- (as.numeric(unlist(strsplit(object@data$date[ROW],'-'))[2])+2)/3
  }
  object@data$dt <- with(object@data , year + (quarter-1)/4)
  object@data    <- object@data[,c('dt','gdp')]  
  
  return(object@data)
  
}

######################################################
### Define Function to Pull GDP Data
PullAnnualNominalGdpData <- function(...) UseMethod('PullAnnualNominalGdpData')

PullAnnualNominalGdpData.default <- function(...) {
  
  setClass("AnnualNominalGdpData",
           representation(data    = "data.frame",
                          freq    = "character",
                          dataDir = "character"
                          )
           )
  
  object <- new("AnnualNominalGdpData")

  object@data        <- read.csv(paste(getwd(),'/data/fredGdp_annual.csv',sep=''), stringsAsFactors = FALSE)
  names(object@data) <- c('date','gdp')
  object@data$date   <- as.character(object@data$date)
  object@data$year   <- object@data$quarter <- object@data$dt <- NA
  
  for (ROW in 1:dim(object@data)[1]) {
    object@data$year[ROW]    <- as.numeric(unlist(strsplit(object@data$date[ROW],'-'))[1])
  }
  object@data$dt <- with(object@data , year)
  object@data    <- object@data[,c('dt','gdp')]  
  
  return(object@data)
  
}



######################################################
### Create GreatDiv Data Object
setClass("GreatDiv",
         representation(firm        = "ANY",
                        ind3        = "ANY",
                        ind4        = "ANY",
                        firm.top100 = "ANY",
                        ind3.top100 = "ANY",
                        ind4.top100 = "ANY",
                        gdp         = "ANY",
                        sigma.q     = "ANY",
                        sigma.y     = "ANY",
                        results     = "list",
                        pValues     = "ANY",
                        figDir      = "character"
                        )
         )

######################################################
### Initialize Data Object
setMethod("initialize",
          "GreatDiv",
          function(.Object) {
            
            ## Load COMPUSTAT Data
            .Object@firm             <- merge(PullGlobalCompustatData(),
                                              PullAnnualCpiData(FREQ = 'YEAR'),
                                              by.x  = 'year',
                                              by.y  = 'dt',
                                              all.x = TRUE
                                              )
            .Object@firm             <- .Object@firm[order(.Object@firm$id, .Object@firm$year), ]
            .Object@firm$globalSales <- with(.Object@firm, globalSales / cpi * 100) / 1000
            .Object@firm             <- .Object@firm[is.finite(.Object@firm$globalSales) & (.Object@firm$globalSales > 0), ]
            .Object@firm             <- .Object@firm[, c('year', 'id', 'globalSales', 'sic')]
            names(.Object@firm)      <- c('year', 'id', 'sales', 'sic')
            .Object@firm             <- .Object@firm[.Object@firm$year >= 1960, ]
            
            ## Load Real GDP (2005 Dollars) Data
            .Object@gdp <- PullQuarterlyRealGdpData()

            ## Compute Growth and Lagged Growth in Real GDP
            LEN                 <- dim(.Object@gdp)[1]
            .Object@gdp$gdp.g   <- 100*(log(.Object@gdp$gdp) - c(NA, log(.Object@gdp$gdp[1:(LEN-1)])))
            .Object@gdp$gdp.g.l <- c(NA, .Object@gdp$gdp.g[1:(LEN-1)])
            .Object@gdp         <- .Object@gdp[.Object@gdp$dt >= 1960, ]
            
            ## Return Data Object
            return(.Object)
            
          })
GreatDiv <- new("GreatDiv")



















######################################################
######################################################
### Compute Real GDP Growth Volatility
######################################################
######################################################

######################################################
### Estimate GDP Growth Volatility
GreatDiv@results[[1]] <- summary(lm(gdp.g ~ gdp.g.l, data=GreatDiv@gdp))

GreatDiv@sigma.q            <- GreatDiv@gdp
GreatDiv@sigma.q$error      <- GreatDiv@results[[1]]$residuals
GreatDiv@sigma.q$sigma.inst <- sqrt(pi/2)*abs(GreatDiv@sigma.q$error)



######################################################
### Compute Rolling GDP Std. Dev. Estimate
GreatDiv@sigma.q$hpCycle    <- hpfilter(log(GreatDiv@sigma.q$gdp), freq=1600, drift=TRUE)$cycle
LEN                         <- dim(GreatDiv@sigma.q)[1]
GreatDiv@sigma.q$sigma.roll <- NA
for (TIME in 1:LEN) {
  num.interval                      <- seq(TIME-20,TIME+20)
  num.interval                      <- num.interval[num.interval %in% seq(1,LEN)]
  GreatDiv@sigma.q$sigma.roll[TIME] <- sd(GreatDiv@sigma.q$hpCycle[num.interval],na.rm=TRUE)
}



######################################################
### Aggregate GDP Growth Volatility to Yearly Frequency
GreatDiv@sigma.q$year   <- floor(GreatDiv@sigma.q$dt)
GreatDiv@sigma.y        <- ddply(GreatDiv@sigma.q,
                                 c('year'),
                                 function(X)c(mean(X$gdp.g,na.rm=TRUE),
                                              mean(X$sigma.inst,na.rm=TRUE),
                                              mean(X$sigma.roll,na.rm=TRUE)
                                              )
                                 )
names(GreatDiv@sigma.y) <- c('year','gdp.g','sigma.inst','sigma.roll')
GreatDiv@sigma.q        <- GreatDiv@sigma.q[,!(names(GreatDiv@sigma.q) %in% c('year'))]



######################################################
### Plot GDP Growth Volatility
df.plotData        <- GreatDiv@sigma.y[,c('year','gdp.g','sigma.inst','sigma.roll')]
names(df.plotData) <- c('t',
                        '$dy_t$',
                        '$\\sqrt{\\pi/2} \\cdot \\left\\vert dy_t - (a + b \\cdot dy_{t-1}) \\right\\vert$',
                        '$\\left( \\sqrt{\\pi/2} / 41 \\right) \\cdot \\sum_{s = (t-20)}^{t+20} \\left\\vert dy_s - (a + b \\cdot dy_{s-1}) \\right\\vert$'
                        )
df.plotData        <- melt(df.plotData,c('t'))

RAW_FILE <- 'plot__gdp_growth_volatility'
TEX_FILE <- paste(RAW_FILE,'.tex',sep='')
PDF_FILE <- paste(RAW_FILE,'.pdf',sep='')
PNG_FILE <- paste(RAW_FILE,'.png',sep='')
tikz(file = TEX_FILE, height = 7, width = 9, standAlone=TRUE)
p <- ggplot(df.plotData, aes(x=t, y=value))
p <- p + geom_path()
p <- p + facet_wrap(~variable, ncol=1, scales="free_y")
p <- p + ylab('') + xlab('$t{\\scriptstyle (\\mathtt{qtr})}$')
p <- p + opts(legend.position='none')
print(p)
dev.off()
tools::texi2dvi(TEX_FILE, pdf = TRUE, clean = TRUE)
system(paste('convert -density 450 ', file.path(PDF_FILE), ' ', file.path(PNG_FILE)))
system(paste('mv ', PNG_FILE, ' ', getwd(), '/figures/', sep = ''))
system(paste('rm ', TEX_FILE, sep = ''))
system(paste('rm ', PDF_FILE, sep = ''))



























######################################################
######################################################
### Compute Fundamental Volatility
######################################################
######################################################

######################################################
### Remove Banned Industries
int.oilSicCodes    <- c(2911,5172,1311,4922,4923,4924,1389)
int.energySicCodes <- seq(4900,4940)
GreatDiv@firm      <- GreatDiv@firm[!(GreatDiv@firm$sic %in% int.energySicCodes),]



######################################################
### Compute Industry Level Data
GreatDiv@firm$sic3 <- floor(GreatDiv@firm$sic/10)
GreatDiv@firm$sic4 <- GreatDiv@firm$sic

GreatDiv@ind3        <- aggregate(GreatDiv@firm[,c('sales')], by=list(GreatDiv@firm$sic3,GreatDiv@firm$year), sum, na.rm=TRUE)
names(GreatDiv@ind3) <- c('id','year','sales')

GreatDiv@ind4        <- aggregate(GreatDiv@firm[,c('sales')], by=list(GreatDiv@firm$sic4,GreatDiv@firm$year), sum, na.rm=TRUE)
names(GreatDiv@ind4) <- c('id','year','sales')

GreatDiv@firm        <- GreatDiv@firm[,c('id','year','sales')]
names(GreatDiv@firm) <- c('id','year','sales')



######################################################
### Keep Largest 100 Units based on Lagged Domestic Sales
KeepLargest100 <- function(df.data) {
  
  df.data <- pdata.frame(df.data, index=c('id','year'))
  
  df.data$sales.lag <- lag(df.data$sales, 1)
  df.data           <- df.data[!is.na(df.data$sales.lag),]
  
  df.data      <- as.data.frame(df.data)
  df.data$id   <- as.character(df.data$id)
  df.data$year <- as.numeric(as.character(df.data$year))
  
  df.data <- ddply(df.data, c('year'), function(X)X[order(-X$sales.lag),][1:100,])
  df.data <- df.data[,!(names(df.data) %in% c('sales.lag'))]
  
  df.data <- df.data[!is.na(df.data$year),]
  
  return(df.data)
  
}

GreatDiv@firm.top100 <- KeepLargest100(GreatDiv@firm)
GreatDiv@ind3.top100 <- KeepLargest100(GreatDiv@ind3)
GreatDiv@ind4.top100 <- KeepLargest100(GreatDiv@ind4)




######################################################
### Plot Sales Data
df.plotData        <- as.data.frame(rbind(GreatDiv@firm.top100[,c('year','sales')],
                                          GreatDiv@ind3.top100[,c('year','sales')],
                                          GreatDiv@ind4.top100[,c('year','sales')]
                                          )
                                    )
names(df.plotData) <- c('dt','value')
df.plotData$facet  <- c(rep('Firm',dim(GreatDiv@firm.top100)[1]),
                        rep('3-Digit Industry',dim(GreatDiv@ind3.top100)[1]),
                        rep('4-Digit Industry',dim(GreatDiv@ind4.top100)[1])
                        )

RAW_FILE <- 'plot__total_sales_of_top_100_firms'
TEX_FILE <- paste(RAW_FILE,'.tex',sep='')
PDF_FILE <- paste(RAW_FILE,'.pdf',sep='')
PNG_FILE <- paste(RAW_FILE,'.png',sep='')
tikz(file = TEX_FILE, height = 7, width = 9, standAlone=TRUE)
p <- ggplot(df.plotData, aes(x=dt, y=value, group=dt))
p <- p + geom_boxplot()
p <- p + facet_wrap(~facet,ncol=1,scales="free_y")
p <- p + ylab('$\\$\\mathtt{Mil}$') + xlab('$t{\\scriptstyle (\\mathtt{yr})}$')
p <- p + opts(legend.position='none')
print(p)
dev.off()
tools::texi2dvi(TEX_FILE, pdf = TRUE, clean = TRUE)
system(paste('convert -density 450 ', file.path(PDF_FILE), ' ', file.path(PNG_FILE)))
system(paste('mv ', PNG_FILE, ' ', getwd(), '/figures/', sep = ''))
system(paste('rm ', TEX_FILE, sep = ''))
system(paste('rm ', PDF_FILE, sep = ''))



######################################################
### Compute Fundamental Volatility
ComputeFundamentalVolatility <- function(df.data, NAME) {
  
  df.data     <- merge(df.data, PullAnnualNominalGdpData(), by.x='year', by.y='dt')
  df.data     <- merge(df.data, PullAnnualCpiData(), by.x='year', by.y='dt')
  df.data$gdp <- with(df.data, gdp/cpi*100)
  
  df.sigma        <- ddply(df.data, c('year'), function(X)sqrt(sum((X$sales/X$gdp)^2))*.12)
  names(df.sigma) <- c('year',NAME)
  
  return(df.sigma)
  
}

GreatDiv@sigma.y <- merge(GreatDiv@sigma.y, ComputeFundamentalVolatility(GreatDiv@firm,'sigma.firm'),by=c('year'))
GreatDiv@sigma.y <- merge(GreatDiv@sigma.y, ComputeFundamentalVolatility(GreatDiv@firm.top100,'sigma.firm.top100'),by=c('year'))
GreatDiv@sigma.y <- merge(GreatDiv@sigma.y, ComputeFundamentalVolatility(GreatDiv@ind3.top100,'sigma.ind3.top100'),by=c('year'))
GreatDiv@sigma.y <- merge(GreatDiv@sigma.y, ComputeFundamentalVolatility(GreatDiv@ind4.top100,'sigma.ind4.top100'),by=c('year'))



######################################################
### Write Data Frame of Fundamental Volatilities to File
write.csv(GreatDiv@sigma.y, file=paste(getwd(),'/data/FundamentalVolatility.csv',sep=''))



######################################################
### Plot Fundamental and GDP Growth Volatility Estimates demeaned
df.plotData        <- GreatDiv@sigma.y[,c('year','sigma.roll','sigma.firm','sigma.firm.top100')]
names(df.plotData) <- c('dt','$\\sigma_y$','$\\sigma_F$ (All Firms)','$\\sigma_F$ (Top 100)')
df.plotData        <- melt(df.plotData, c('dt'))

df.means          <- ddply(df.plotData, c('variable'), function(X)mean(X$value,na.rm=TRUE))
names(df.means)   <- c('variable','mean')
df.plotData       <- merge(df.plotData, df.means, by='variable')
df.plotData$value <- with(df.plotData, value-mean)

df.plotData[df.plotData$variable != '$\\sigma_y$',]$value <- 4.5 * df.plotData[df.plotData$variable!='$\\sigma_y$',]$value

RAW_FILE <- 'plot__firm_based_fundamental_volatility_and_gdp_volatility'
TEX_FILE <- paste(RAW_FILE,'.tex',sep='')
PDF_FILE <- paste(RAW_FILE,'.pdf',sep='')
PNG_FILE <- paste(RAW_FILE,'.png',sep='')
tikz(file = TEX_FILE, height = 5, width = 9, standAlone=TRUE)
p <- ggplot(df.plotData)
p <- p + geom_hline(yintercept = 0, size = 0.50, linetype = 2, colour='black')
p <- p + geom_path(aes(x        = dt,
                       y        = value,
                       group    = variable,
                       colour   = variable,
                       linetype = variable
                       ),
                   size = 1.5
                   )
p <- p + labs(colour = "", linetype = "", group = "")
p <- p + ylab('$\\%{\\scriptstyle /\\mathtt{yr}}$') + xlab('$t{\\scriptstyle (\\mathtt{yr})}$')
print(p)
dev.off()
tools::texi2dvi(TEX_FILE, pdf = TRUE, clean = TRUE)
system(paste('convert -density 450 ', file.path(PDF_FILE), ' ', file.path(PNG_FILE)))
system(paste('mv ', PNG_FILE, ' ', getwd(), '/figures/', sep = ''))
system(paste('rm ', TEX_FILE, sep = ''))
system(paste('rm ', PDF_FILE, sep = ''))
