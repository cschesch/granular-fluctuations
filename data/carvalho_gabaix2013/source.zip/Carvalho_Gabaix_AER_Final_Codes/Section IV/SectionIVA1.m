%% CODES FOR SECTION IVA1
% 1) Assembles correlation-based fundamental volatility measure
% 2) Outputs Figure 6
% 3) Outputs Table 4 regressions

%% 1) ASSEMBLE FUNDAMENTAL VOLATILITY MEASURE

%Load US sector data

load allUSdata.mat;

%Compute Sig_F_Full (taking into account TFP covariances) for Annual data
covstfpsv=cov((stfp(1:end,2:end)'));

for k=1:size(dweightalt,2)
    for i=1:size(dweightalt,1)
        sigfun(i,k)=0;
        sigfun(i,k)=((((covstfpsv(i,i))))*(dweightalt(i,k)*dweightalt(i,k)))+sigfun(i,k);
        sigfunx(i,k)=0;
        for j=1:size(dweightalt,1)
            sigfunx(i,k)=((covstfpsv(i,j))*(dweightalt(i,k)*dweightalt(j,k)))+sigfunx(i,k);
        end
    end
end

sigfun=sum(sigfun); %This is Sig_F^2 
sigfunx=sum(sigfunx);  %This is Sig_F_Full^2 

%Quarterly version of Sigma_F, Sigma_F_Full
%Interpolate (Linearly) to get Quarterly version of Fundamental Vol. measures

xi=1960:0.25:2008.75;
xi=xi';
y=sigfunx;
sigfunxq = interp1(1960:2008,y,xi,'linear');
y=sigfun;
sigfunq = interp1(1960:2008,y,xi,'linear');

%% 2) CONSTRUCT MEASURES OF VOLATILITY IN GDP

%Load QGDP Growth for Sigma_Y_Inst measure
qgdp = xlsread('qgdp.xls');
qgdp=qgdp./100;
%AR(1) regression of growth rates; retrieve absolute values of residuals
whichstats = {'tstat','r'};
qgdpoutr=regstats(qgdp(2:size(sigfunq-3,1)),qgdp(1:size(sigfunq-3,1)-1), 'linear', whichstats);
absqr=abs(qgdpoutr.r);

%Load QGDP levels for Sigma_Y_Roll measure
load qgdpl.mat

%Construct Sigma_Y_RollQ: Quarterly rolling window volatility measure

%Deviations of log levels from HP filter, 1600 Smoothing Parameter for
%Quarterly data
qgdplhp=hpfilter(log(qgdpl),1600);
qgdpdev=log(qgdpl)-qgdplhp;
%Rolling Centered standard deviation over 41 quarters
for i=21:(max(size(qgdpdev))-20)
    stdr(i)=std(qgdpdev(i-20:i+20));
end
%Progressively more uncentered for end of sample 
for i=1:20
    j=max(size(qgdpdev))-20+i;
    stdruc(j)=std(qgdpdev(j-20:max(size(qgdpdev))));
end
stdruc(1:max(size(qgdpdev))-20)=stdr;

%Construct Sigma_Y_Roll_A: Annual rolling window volatility measure
%4-quarter average of quarterly measure

for i=0:4:(max(size(stdruc))-4)
    stdrucannual(i+1)=mean(stdruc(i+1:i+4));
end
stdrucannual5209=nonzeros(stdrucannual);

%Construct Sigma_Y_Inst_A: Annual Instantaneous volatility measure as
%defined in paper

for i=4:4:(max(size(absqr)))
    stdiannual(i)=mean(2*sqrt(pi/2)*absqr(i:i+3));
end
stdiannual(1)=mean(2*sqrt(pi/2)*absqr(1:4));
stdiannual6008=nonzeros(stdiannual);

%% 3) TABLE 4 REGRESSIONS
whichstats = {'tstat','yhat','rsquare','r'};
%Sigma_Y_Roll measure
absrfunx=regstats(((stdrucannual5209(9:end-1))),[sqrt(sigfunx)], 'linear', whichstats);
%Output
absrfunx.tstat.beta
absrfunx.tstat.se
absrfunx.tstat.t
absrfunx.rsquare

%Sigma_Y_Inst measure
absifunx=regstats(((stdiannual6008)),[sqrt(sigfunx(1:end))], 'linear', whichstats);
absifunx.tstat.beta
absifunx.tstat.se
absifunx.tstat.t
absifunx.rsquare

%% 4) FIGURE 6
smoothing_param_annual_hp=6.5;
plot(1960:2008,stdrucannual5209(9:end-1)-mean(stdrucannual5209(9:end-1)),'-', 1960:2008, hpfilter(stdiannual6008,smoothing_param_annual_hp)-mean(hpfilter(stdiannual6008,smoothing_param_annual_hp)),'o-', 1960:2008, 4.5*sqrt(sigfunx)-mean(4.5*sqrt(sigfunx)),'s-r')
xlabel('year')
ylabel('Cyclical Volatility (demeaned)')
grid on
axis tight
