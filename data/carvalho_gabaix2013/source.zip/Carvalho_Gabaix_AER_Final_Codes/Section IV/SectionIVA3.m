%% CODES FOR SECTION IVA3
% NOTE: These codes use functions in the UCSD_GARCH Toolbox
% available at http://www.kevinsheppard.com/wiki/UCSD_GARCH which in turn
% uses the JPL Econometrics toolbox available at
% http://www.spatial-econometrics.com/

% 1) Performs Garch(1,1) estimation for sectoral tfp growth series
% 2) Computes alternative measures to fundamental volatility with
% time-varying micro volatility
% 3) Outputs results of regressions with such measures



%% 1) GARCH ESTIMATION FOR SECTORAL TFP
%Load US sector data

load allUSdata.mat;

% GARCH(1,1) with Normal Distribution
for i=1:76
    [parameters, likelihood, ht, stderrors, robustSE, scores, grad] = garchpq(stfp(i,2:end)' , 1 , 1);
    Sigma2_i_garch_mat(i,:)=ht';
end
Sigma2_i_garch_mat(77,:)=zeros(1,size(Sigma2_i_garch_mat,2)); % for last sector (HH) no sectoral TFP data


%Average squared domar weights
mean_dweight_sq=mean(dweightalt(:,:)'.^2);


%% 2) COMPUTE SIGMAF_Prime and SIGMAF_Prime_Prime 
% SigmaF_Prime fixes squared domar weights at their average and keeps time
% varying sectoral TFP volatility
% SigmaF_Prime_Prime has time varying squared domar weights and time
% varying sectoral TFP volatility

for i=1:size(Sigma2_i_garch_mat,2)
    SigmaF_prime(i)=sqrt(mean_dweight_sq*(((Sigma2_i_garch_mat(:,i)))));
end

for i=1:size(Sigma2_i_garch_mat,2)
    SigmaF_prime_prime(i)=sqrt((dweight(:,i+1)'.^2)*(Sigma2_i_garch_mat(:,i)));
end

%Compute baseline measure Sig_F for Annual data and Quarterly Interpolation
covstfpsv=cov((stfp(1:end,2:end)'));

for k=1:size(dweightalt,2)
    for i=1:size(dweightalt,1)
        sigfun(i,k)=0;
        sigfun(i,k)=((((covstfpsv(i,i))))*(dweightalt(i,k)*dweightalt(i,k)))+sigfun(i,k);
        sigfunx(i,k)=0;
        for j=1:size(dweightalt,1)
            sigfunx(i,k)=((covstfpsv(i,j))*(dweightalt(i,k)*dweightalt(j,k)))+sigfunx(i,k);
        end
    end
end

sigfun=sum(sigfun); %This is Sig_F^2 

%Quarterly version of Sigma_F, Sigma_F_Full
%Interpolate (Linearly) to get Quarterly version of Fundamental Vol. measures

xi=1960:0.25:2008.75;
xi=xi';
y=sigfun;
sigfunq = interp1(1960:2008,y,xi,'linear');


%% 3) CONSTRUCT MEASURES OF VOLATILITY IN GDP

%Load QGDP Growth for Sigma_Y_Inst measure
qgdp = xlsread('qgdp.xls');
qgdp=qgdp./100;
%AR(1) regression of growth rates; retrieve absolute values of residuals
whichstats = {'tstat','r'};
qgdpoutr=regstats(qgdp(2:size(sigfunq-3,1)),qgdp(1:size(sigfunq-3,1)-1), 'linear', whichstats);
absqr=abs(qgdpoutr.r);

%Load QGDP levels for Sigma_Y_Roll measure
load qgdpl.mat

%Construct Sigma_Y_RollQ: Quarterly rolling window volatility measure

%Deviations of log levels from HP filter, 1600 Smoothing Parameter for
%Quarterly data
qgdplhp=hpfilter(log(qgdpl),1600);
qgdpdev=log(qgdpl)-qgdplhp;
%Rolling Centered standard deviation over 41 quarters
for i=21:(max(size(qgdpdev))-20)
    stdr(i)=std(qgdpdev(i-20:i+20));
end
%Progressively more uncentered for end of sample 
for i=1:20
    j=max(size(qgdpdev))-20+i;
    stdruc(j)=std(qgdpdev(j-20:max(size(qgdpdev))));
end
stdruc(1:max(size(qgdpdev))-20)=stdr;

%Construct Sigma_Y_Roll_A: Annual rolling window volatility measure
%4-quarter average of quarterly measure

for i=0:4:(max(size(stdruc))-4)
    stdrucannual(i+1)=mean(stdruc(i+1:i+4));
end
stdrucannual5209=nonzeros(stdrucannual);

%Construct Sigma_Y_Inst_A: Annual Instantaneous volatility measure as
%defined in paper

for i=4:4:(max(size(absqr)))
    stdiannual(i)=mean(2*sqrt(pi/2)*absqr(i:i+3));
end
stdiannual(1)=mean(2*sqrt(pi/2)*absqr(1:4));
stdiannual6008=nonzeros(stdiannual);

%% 4) REGRESSIONS OF BUSINESS CYCLE VOLATILITY ON ALTERVATIVE SigmaF's

SigmaY_Roll_SigmaF_prime=regstats(stdrucannual5209(10:end-4), SigmaF_prime);
SigmaY_Roll_SigmaF_prime.rsquare
SigmaY_Inst_SigmaF_prime=regstats((stdiannual6008(2:end-3)), SigmaF_prime);
SigmaY_Inst_SigmaF_prime.rsquare

SigmaY_Roll_SigmaF_prime_prime=regstats(stdrucannual5209(10:end-4), SigmaF_prime_prime);
SigmaY_Roll_SigmaF_prime_prime.rsquare
SigmaY_Inst_SigmaF_prime_prime=regstats((stdiannual6008(2:end-3)), SigmaF_prime_prime);
SigmaY_Inst_SigmaF_prime_prime.rsquare
