C     Last change:  SRD  4 Apr 2007 8:12 am
      SUBROUTINE prothd(Begtst,Endtst,Ltstao,Ltstls,Ltsttc,Ladd1,Critvl)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Print outlier identification header
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'error.cmn'
c     ------------------------------------------------------------------
      LOGICAL F
      PARAMETER(F=.false.)
c     ------------------------------------------------------------------
      LOGICAL Ladd1,Ltstao,Ltstls,Ltsttc
      INTEGER Begtst,Endtst,idate,itmp,itmp2
      DOUBLE PRECISION Critvl
      DIMENSION Begtst(2),Endtst(2),idate(2),Critvl(POTLR)
c     ------------------------------------------------------------------
      CHARACTER OTTDIC*61,outstr*15
      INTEGER ottind,ottptr,POTT,nstr
      PARAMETER(POTT=7)
      DIMENSION ottptr(0:POTT)
      PARAMETER(OTTDIC='AO onlyLS onlyAO and LSTC onlyAO and TCLS and TC
     &AO, LS and TC')
      DATA ottptr/1,8,15,24,31,40,49,62/
c     ------------------------------------------------------------------
      CALL dfdate(Begtst,Begspn,Sp,itmp)
      itmp=max(itmp,0)
      CALL addate(Begspn,Sp,itmp,idate)
      CALL dfdate(Endtst,idate,Sp,itmp2)
      IF(Ltstao)itmp2=itmp2+1
      itmp=min(itmp2,Nspobs-itmp)
      CALL prtshd('OUTLIER DETECTION',idate,Sp,itmp,F)
      IF(Lfatal)RETURN
c     ------------------------------------------------------------------
      IF(itmp.le.1)Ltstls=F
      IF(itmp.le.0)THEN
       Ltstao=F
       Ltsttc=F
      END IF
c     ------------------------------------------------------------------
      ottind=0
      IF(Ltstao)ottind=ottind+1
      IF(Ltstls)ottind=ottind+2
      IF(Ltsttc)ottind=ottind+4
      CALL getstr(OTTDIC,ottptr,POTT,ottind,outstr,nstr)
      WRITE(Mt1,1010)outstr(1:nstr)
 1010 FORMAT('  Types           ',a)
c     ------------------------------------------------------------------
      IF(Ladd1)THEN
       WRITE(Mt1,1020)'add one'
 1020  FORMAT('  Method            ',a)
      ELSE
       WRITE(Mt1,1020)'add all'
      END IF
c     ------------------------------------------------------------------
      IF(Ltstao)WRITE(Mt1,1030)'AO',Critvl(AO)
      IF(Ltstls)WRITE(Mt1,1030)'LS',Critvl(LS)
      IF(Ltsttc)WRITE(Mt1,1030)'TC',Critvl(TC)
 1030 FORMAT('  Critical |t| for ',a,' outliers   ',f12.2)
c     ------------------------------------------------------------------
      RETURN
      END
