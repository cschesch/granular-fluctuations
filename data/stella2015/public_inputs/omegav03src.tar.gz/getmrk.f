C     Last change:  BCM  5 Sep 2006 12:57 pm
      SUBROUTINE getmrk(Tblptr,Llogfl,Tbcode,Ntcode)
      IMPLICIT NONE
c     ------------------------------------------------------------------
c     Get table code from data dictionary
c     ------------------------------------------------------------------
      INCLUDE 'brkdsp.prm'
      INCLUDE 'tbllog.prm'
      INCLUDE 'acode.prm'
      INCLUDE 'aclog.prm'
      INCLUDE 'acode.var'
      INCLUDE 'aclog.var'
c-----------------------------------------------------------------------
      CHARACTER Tbcode*(*)
      INTEGER Tblptr,Ntcode
      LOGICAL Llogfl
c-----------------------------------------------------------------------
c     Get table code from data dictionary, depending on whether the
c     program is writing to the log file or the output file
c-----------------------------------------------------------------------
      IF(Llogfl)THEN
       CALL getstr(ACLDIC,aclptr,PACL,Tblptr,Tbcode,Ntcode)
      ELSE
       IF(Tblptr.le.BRKDSP)THEN
        CALL getstr(AC1DIC,ac1ptr,PAC1,Tblptr,Tbcode,Ntcode)
       ELSE IF(Tblptr.le.BRKDS2)THEN
        CALL getstr(AC2DIC,ac2ptr,PAC2,Tblptr-PAC1,Tbcode,Ntcode)
       ELSE
        CALL getstr(AC3DIC,ac3ptr,PAC3,Tblptr-PAC1-PAC2,Tbcode,Ntcode)
       END IF
      END IF
c-----------------------------------------------------------------------
      RETURN
      END
      
