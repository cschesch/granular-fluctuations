C     Last change:  SRD  16 Sep 2009 11:32 am
      SUBROUTINE arima(Hvmdl,Extok,Lx11,Lgraf)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Estimates regression models with ARIMA errors
c-----------------------------------------------------------------------
c Name  Type Description
c-----------------------------------------------------------------------
c a       d  Pa/na long of innovation errors
c-----------------------------------------------------------------------
c     Variable typing and initialization
c-----------------------------------------------------------------------
      LOGICAL T,F
      DOUBLE PRECISION ZERO,ONE
      INTEGER BADITR
      PARAMETER(T=.true.,F=.false.,ZERO=0D0,ONE=1D0,BADITR=500)
c-----------------------------------------------------------------------
      INCLUDE 'stdio.i'
      INCLUDE 'notset.prm'
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'lkhd.cmn'
      INCLUDE 'lzero.cmn'
      INCLUDE 'adj.cmn'
      INCLUDE 'x11log.cmn'
      INCLUDE 'x11ptr.cmn'
      INCLUDE 'extend.cmn'
      INCLUDE 'hiddn.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'error.cmn'
      INCLUDE 'title.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
      INCLUDE 'fxreg.cmn'
      INCLUDE 'arima.cmn'
      INCLUDE 'rev.prm'
      INCLUDE 'rev.cmn'
      INCLUDE 'prior.prm'
      INCLUDE 'prior.cmn'
      INCLUDE 'priadj.cmn'
      INCLUDE 'prittl.cmn'
      INCLUDE 'priusr.cmn'
      INCLUDE 'missng.cmn'
      INCLUDE 'x11opt.cmn'
      INCLUDE 'tbllog.i'
      INCLUDE 'mdltbl.i'
      INCLUDE 'usrreg.cmn'
      INCLUDE 'svllog.prm'
      INCLUDE 'svllog.cmn'
      INCLUDE 'mdlsvl.i'
      INCLUDE 'inpt.cmn'
      INCLUDE 'mq3.cmn'
      INCLUDE 'orisrs.cmn'
c     ------------------------------------------------------------------
      INTEGER PA
      PARAMETER(PA=PLEN+2*PORDER)
c     ------------------------------------------------------------------
      REAL ticks
      CHARACTER tdstr*(25),cfcst*(3)
      DOUBLE PRECISION a,trnsrs,orix,orixmv,ftd,fao,fls,ftc,fusr,fmv,
     &                 fhol,fsea,mape,dvec,cv,Temp,fcstx,bcstx,untfct,
     &                 untbct,cvbak
      LOGICAL Finhol,Finao,Finls,Fintc,Finusr,lester,Extok,Lx11,litr,
     &        Hvmdl,lidotl,fctok,Lgraf,gudrun,ldiag,ltmp,lauto,ltdlom,
     &        svllkh
      INTEGER i,frstry,idate,na,nefobs,n,nbeg,nf2,tdreg,Tdtbl,iaic,Tday,
     &        nend,Nusrrg,NAO,NLS,Nhol,Adjsea,Adjtd,Adjhol,Adjao,Adjls,
     &        Adjtc,Adjusr,NTC,NRamp,Nln,Nlp,nlagbl,Nflwtd,i1,i2,hvstar,
     &        begopr,endopr,itmp,nobtst,ntdchr,outdec,iao,ils,itc,iramp,
     &        iauto,iuser
      DIMENSION a(PA),idate(2),trnsrs(PLEN),orix(PLEN),orixmv(PLEN),
     &          ftd(PLEN),fao(PLEN),fls(PLEN),ftc(PLEN),fusr(PLEN),
     &          fmv(PLEN),fhol(PLEN),Tday(PLEN),mape(4),dvec(1),
     &          fsea(PLEN),Temp(PLEN),fcstx(PFCST),bcstx(PFCST),
     &          cvbak(3),untfct(PFCST),untbct(PLEN)
c     ------------------------------------------------------------------
c-----------------------------------------------------------------------
      INTEGER PR
      PARAMETER (PR=PLEN/4)
      INCLUDE 'autoq.cmn'
c-----------------------------------------------------------------------
c      INTEGER iticks
      LOGICAL istrue,dpeq
      INTEGER strinx,nblank
      DOUBLE PRECISION setcv,setcvl
      EXTERNAL strinx,istrue,dpeq,setcv,nblank,setcvl
c     ------------------------------------------------------------------
      COMMON /work  / Temp
      COMMON /tdtyp / Tdtbl,Tday
      COMMON /numotl/ Nusrrg,NAO,NLS,NTC,NRamp,Nhol,Nln,Nlp,Nflwtd
      COMMON /x11adj/ Adjtd,Adjhol,AdjAO,AdjLS,AdjTC,Adjsea,Adjusr,
     &                Finhol,FinAO,FinLS,FinTC,Finusr
c-----------------------------------------------------------------------
      CHARACTER num*(2),cdef*(1)
      DIMENSION num(4)
c-----------------------------------------------------------------------
      DATA num/'st','nd','rd','th'/
c-----------------------------------------------------------------------
C      num_imv=1
Cc-----------------------------------------------------------------------
c     Input series, regression variables, model, options
c-----------------------------------------------------------------------
      itmp=0
      na=0
      lester=F
      fctok=T
      lidotl=Ltstao.or.Ltstls.or.Ltsttc
      Natotl=0
      lauto=Lautom.or.Lautox
      gudrun=Issap.LT.2.AND.Irev.lt.4
      ltdlom=Kfulsm.eq.2
      CALL setdp(ZERO,PXPX,Chlxpx)
c-----------------------------------------------------------------------
c     Change Begspn and Endspn to match the model span, if necessary.
c-----------------------------------------------------------------------
      nbeg=0
      nend=0
      IF(Ldestm)THEN
       CALL dfdate(Begmdl,Begspn,Sp,nbeg)
       CALL dfdate(Endspn,Endmdl,Sp,nend)
       IF(nbeg.gt.0)CALL cpyint(Begmdl,2,1,Begspn)
       IF(nend.gt.0)CALL cpyint(Endmdl,2,1,Endspn)
      END IF
c-----------------------------------------------------------------------
c     Process the series
c-----------------------------------------------------------------------
      CALL dfdate(Endspn,Begspn,Sp,Nspobs)
      Nspobs=Nspobs+1
      IF(nbeg.gt.0.or.nend.gt.0.or.Issap.eq.2)THEN
       CALL dfdate(Begspn,Begsrs,Sp,Frstsy)
       Frstsy=Frstsy+1
       Nomnfy=Nobs-Frstsy+1
       Nobspf=min(Nspobs+Nfdrp,Nomnfy)
       CALL dfdate(Begspn,Begadj,Sp,Adj1st)
       Adj1st=Adj1st+1
      END IF
      CALL setdp(ZERO,PLEN,trnsrs)
      CALL copy(Sto(Pos1ob+nbeg),Nobspf,-1,trnsrs)
c----------------------------------------------------------------------
c     IF critical value not set, replace with value based on length of
c     series
c----------------------------------------------------------------------
      cv=DNOTST
      IF((Ltstao.and.dpeq(Critvl(AO),DNOTST)).or.
     &   (Ltstls.and.dpeq(Critvl(LS),DNOTST)).or.
     &   (Ltsttc.and.dpeq(Critvl(TC),DNOTST)))THEN
       CALL dfdate(Endtst,Begtst,Sp,nobtst)
       nobtst=nobtst+1
       IF(Cvtype)THEN
        cv=setcvl(nobtst,Cvalfa)
       ELSE
        cv=setcv(nobtst,Cvalfa)
       END IF
       IF(dpeq(cv,DNOTST))THEN
        CALL abend()
        RETURN
       END IF
       IF(Ltstao.and.dpeq(Critvl(AO),DNOTST))Critvl(AO)=cv
       IF(Ltstls.and.dpeq(Critvl(LS),DNOTST))Critvl(LS)=cv
       IF(Ltsttc.and.dpeq(Critvl(TC),DNOTST))Critvl(TC)=cv
      END IF
c-----------------------------------------------------------------------
c     Write out model span and outlier testing span into diagnostics 
c     summary file, if requested
c-----------------------------------------------------------------------
      IF(Lsumm.gt.0.and.gudrun)THEN
       i1=Begmdl(MO)
       IF(i1.gt.4)i1=4
       i2=Endmdl(MO)
       IF(i2.gt.4)i2=4
       IF(Sp.eq.12.or.Sp.eq.4)THEN
        WRITE(Nform,1000)'modelspan: ',Begmdl(MO),num(i1),
     &                   Moqu(1:nblank(Moqu)),Begmdl(YR),Endmdl(MO),
     &                   num(i2),Moqu(1:nblank(Moqu)),Endmdl(YR)
       ELSE IF(Sp.eq.1)THEN
        WRITE(Nform,1001)'modelspan: ',Begmdl(YR),Endmdl(YR)
       ELSE
        WRITE(Nform,1000)'modelspan: ',Begmdl(MO),num(i1),
     &                   'period',Begmdl(YR),Endmdl(MO),num(i2),
     &                   'period',Endmdl(YR)
       END IF
       IF(lidotl)THEN
        i1=Begtst(MO)
        IF(i1.gt.4)i1=4
        i2=Endtst(MO)
        IF(i2.gt.4)i2=4
        IF(Sp.eq.12.or.Sp.eq.4)THEN
         WRITE(Nform,1000)'outlierspan: ',Begtst(MO),num(i1),
     &                    Moqu(1:nblank(Moqu)),Begtst(YR),Endtst(MO),
     &                    num(i2),Moqu(1:nblank(Moqu)),Endtst(YR)
        ELSE IF(Sp.eq.1)THEN
         WRITE(Nform,1001)'outlierspan: ',Begtst(YR),Endtst(YR)
        ELSE
         WRITE(Nform,1000)'outlierspan: ',Begtst(MO),num(i1),
     &                    'period',Begtst(YR),Endtst(MO),num(i2),
     &                    'period',Endtst(YR)
        END IF
       END IF
      END IF
c-----------------------------------------------------------------------
c     BoxCox transform the (prior adjusted, if requested) data.
c Lam=1 means no transformation, Lam=0 is the log transform,
c this is all part of the Box-Cox transformation.
c-----------------------------------------------------------------------
      IF(Lmvaft.or.Ln0aft)THEN
       CALL trnfcn(trnsrs,Nspobs,Fcntyp,Lam,trnsrs)
      ELSE
       CALL trnfcn(trnsrs,Nobspf,Fcntyp,Lam,trnsrs)
      END IF
      IF(Lfatal)RETURN
c     ------------------------------------------------------------------
c      IF((.not.dpeq(Lam,ONE)).and.Prttab(LTRNDT))THEN
      IF(Prttab(LTRNDT))THEN
       IF(Laccss)CALL insmrk(Mt1,LTRNDT,T,F)
       CALL prtshd(
     &        'Transformed (prior-adjusted) data for regARIMA modeling',
     &             Begspn,Sp,Nspobs,T)
       IF(Lfatal)RETURN
       outdec=Kdec
       IF((.not.dpeq(Lam,ONE)).and.outdec.lt.3)outdec=3
       CALL prttbl(Begspn,Sp,trnsrs,Nspobs,'Data',outdec)
       IF(Laccss)CALL insmrk(Mt1,LTRNDT,F,F)
      END IF
c-----------------------------------------------------------------------
      IF(Savtab(LTRNDT))THEN
       CALL savtbl(LTRNDT,Begspn,1,Nspobs,Sp,trnsrs,Serno,Nser,F)
       IF(Lfatal)RETURN
      END IF
c-----------------------------------------------------------------------
c     Set up the regression matrix
c-----------------------------------------------------------------------
      CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
     &            Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
      IF((.not.Lfatal).and.Iregfx.ge.2)THEN
       CALL rmfix(trnsrs,Nbcst,Nrxy,1)
       IF(.not.Lfatal)
     &    CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
     &                Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
      END IF
      IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Identify the differencing in the model
c-----------------------------------------------------------------------
      IF(Niddf.gt.0.or.Nidsdf.gt.0)THEN
       CALL prprad(Adjttl,Nadjcr,Nustad,Nuspad,Priadj,Reglom)
       IF(Priadj.gt.0.or.Nustad.gt.0.or.Nuspad.gt.0)WRITE(Mt1,'()')
       IF(.not.Lhiddn)CALL prtnfn(Fcntyp,Lam,0)
c-----------------------------------------------------------------------
       IF(.not.Lhiddn)THEN
        IF(.not.Lcmpaq)WRITE(Mt1,'()')
        IF(Laccss)CALL insacd(Mt1,'h3',T)
        IF(Nb.gt.0)THEN
         WRITE(Mt1,1030)
        ELSE
         WRITE(Mt1,1040)
        END IF
        IF(Laccss)CALL insacd(Mt1,'h3',F)
       END IF
c-----------------------------------------------------------------------
       IF(Ngrp.gt.0)
     &    CALL desreg('Regression Model',Ngrp,Grpttl,Grpptr,Ngrptl)
       IF(Ngrpfx.gt.0)
     &    CALL desreg('Regression Model (fixed)',Ngrpfx,Gfxttl,Gfxptr,
     &                Ngfxtl)
       IF(.not.Lfatal)CALL idmdl(Dflist,Niddf,Nidsdf,mxidlg,Lgraf)
       IF(Lfatal)RETURN
       IF(Niddf.gt.0)Niddf=0
       IF(Nidsdf.gt.0)Nidsdf=0
      END IF
c-----------------------------------------------------------------------
c     Everything beyond, outlier identification, model checking, and
c forecasting all require estimation so the program does not continue
c unless estimation/evaluation is done.
c-----------------------------------------------------------------------
      IF(Ldestm)THEN
c-----------------------------------------------------------------------
c     If automatic modelling option selected, select a model.
c-----------------------------------------------------------------------
       IF(lauto)THEN
        IF(Lautom)THEN
         IF(Lsumm.gt.0.and.gudrun)
     &      WRITE(Nform,1060)'automodeltype: ','automdl'
         IF(lidotl)THEN
          DO i=1,3
           cvbak(i)=Critvl(i)
          END DO
         END IF
C-----------------------------------------------------------------------
         IF(Lsumm.gt.0)THEN
          CALL cpu_time(ticks)
          WRITE(Nform,9000) 'bautomd:',ticks
         END IF
C-----------------------------------------------------------------------
         CALL automd(trnsrs,frstry,nefobs,a,na,Lsumm,lidotl,LSLADF,Lx11,
     &               Ltdlom,fctok,Lhiddn,Lnoprt)
         IF((.not.Lautom).or.Lfatal)RETURN
         Hvmdl=T
C-----------------------------------------------------------------------
         IF(Lsumm.gt.0)THEN
          CALL cpu_time(ticks)
          WRITE(Nform,9000) 'eautomd:',ticks
         END IF
C-----------------------------------------------------------------------
c     If rejectfcst = yes, test forecast error to see if forecast
c     extension should be rejected  (BCM July 2007)
C-----------------------------------------------------------------------
         IF(Lrejfc)THEN
          cfcst='no '
          CALL amdfct(trnsrs,mape,Nobspf,Nfcst,F,fctok,F)
          IF(Lfatal)RETURN
          IF(mape(4).gt.Fctlm2)THEN
           CALL nofcst(trnsrs,frstry,Lx11)
           IF(Lfatal)RETURN
           IF(Laccss)CALL insacd(Mt1,'p',T)
           WRITE(Mt1,1160)mape(4),Fctlm2
           IF(Laccss)CALL insacd(Mt1,'p',F)
           cfcst='yes'
          END IF
          IF(Lsumm.gt.0.and.gudrun)THEN
           WRITE(Nform,1060)'rejectfcst: ','yes'
           WRITE(Nform,1200)'fcstlim: ',fctlm2
           WRITE(Nform,1200)'mape3yr: ',mape(4)
           WRITE(Nform,1060)'fcstrejected: ',cfcst
          END IF
         END IF
C-----------------------------------------------------------------------
         IF(Lsumm.gt.0.and.gudrun)THEN
          IF(lidotl)THEN
           IF(Ltstao)THEN
            cdef=' '
            IF(dpeq(Critvl(AO),cv))cdef='*'
            IF(.not.dpeq(Critvl(AO),cvbak(AO)))cdef='-'
            WRITE(Nform,1010)'aocrit: ',Critvl(AO),cdef
           END IF
           IF(Ltstls)THEN
            cdef=' '
            IF(dpeq(Critvl(LS),cv))cdef='*'
            IF(.not.dpeq(Critvl(LS),cvbak(LS)))cdef='-'
            WRITE(Nform,1010)'lscrit: ',Critvl(LS),cdef
           END IF
           IF(Ltsttc)THEN
            cdef=' '
            IF(dpeq(Critvl(TC),cv))cdef='*'
            IF(.not.dpeq(Critvl(TC),cvbak(TC)))cdef='-'
            WRITE(Nform,1010)'tccrit: ',Critvl(TC),cdef
           END IF
           WRITE(Nform,1020)'reducecv: ',Predcv
          END IF
          WRITE(Nform,1060)'automdl: ',Bstdsn(1:Nbstds)
          WRITE(Nform,1050)Bstdsn(1:Nbstds)
          WRITE(Nform,1061)'maxiter: ',Mxiter
          WRITE(Nform,1021)'tol: ',Tol
         END IF 
         IF(Svltab(LSLAMD))THEN
          IF(Laccss)CALL insmrk(Ng,LSLAMD,T,T)
          WRITE(Ng,1080)Bstdsn(1:Nbstds)
          IF(Laccss)CALL insmrk(Ng,LSLAMD,F,T)
         END IF
        ELSE 
         hvstar=0
         IF(Lsumm.gt.0.and.gudrun)
     &      WRITE(Nform,1060)'automodeltype: ','pickmdl'
         CALL automx(trnsrs,frstry,nefobs,a,na,Hvmdl,hvstar,Lx11,lidotl,
     &               ltdlom,fctok,Lhiddn,Lsumm)
         IF(Lfatal)RETURN
         IF(Lsumm.gt.0.and.gudrun)THEN
          IF(lidotl)THEN
           IF(Ltstao)THEN
            cdef=' '
            IF(dpeq(Critvl(AO),cv))cdef='*'
            WRITE(Nform,1010)'aocrit: ',Critvl(AO),cdef
           END IF
           IF(Ltstls)THEN
            cdef=' '
            IF(dpeq(Critvl(LS),cv))cdef='*'
            WRITE(Nform,1010)'lscrit: ',Critvl(LS),cdef
           END IF
           IF(Ltsttc)THEN
            cdef=' '
            IF(dpeq(Critvl(TC),cv))cdef='*'
            WRITE(Nform,1010)'tccrit: ',Critvl(TC),cdef
           END IF
          END IF
          IF(hvstar.eq.2)THEN
           WRITE(Nform,1060)'automdl(default): ',Bstdsn(1:Nbstds)
          ELSE
           WRITE(Nform,1060)'automdl: ',Bstdsn(1:Nbstds)
          END IF
          WRITE(Nform,1050)Bstdsn(1:Nbstds)
          WRITE(Nform,1061)'maxiter: ',Mxiter
          WRITE(Nform,1021)'tol: ',Tol
         END IF
         IF(Svltab(LSLAMX))THEN
          IF(Laccss)CALL insmrk(Ng,LSLAMX,T,T)
          IF(hvstar.eq.2)THEN
           WRITE(Ng,1070)Bstdsn(1:Nbstds)
          ELSE
           WRITE(Ng,1080)Bstdsn(1:Nbstds)
          END IF
          IF(Laccss)CALL insmrk(Ng,LSLAMX,F,T)
         END IF
        END IF
c-----------------------------------------------------------------------
c     Save aictest information in log file, if AIC tests performed.
c-----------------------------------------------------------------------
        IF(Svltab(LSLTST).or.(Lsumm.gt.0.and.gudrun))THEN
         IF(Itdtst.gt.0)THEN
          IF(Lsumm.gt.0)THEN
           CALL mktdlb(tdstr,ntdchr,Itdtst,Aicstk,Aicrgm,Tdzero,Sp)
           IF(Lfatal)RETURN
           WRITE(Nform,1060)'aictest.td.reg: ',tdstr(1:ntdchr)
          END IF
          IF(Svltab(LSLTST).and.Laccss)
     &       CALL insacd(Ng,'regression.ats.automd',T)
          IF(Hvmdl)THEN
           iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Trading Day')
           IF(iaic.eq.0)iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                                  'Stock Trading Day')
           IF(iaic.gt.0)THEN
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICtd : accepted'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.td: yes'
           ELSE
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICtd : rejected'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.td: no'
           END IF
          ELSE
           IF(Svltab(LSLTST))
     &        WRITE(Ng,1060)'   AICtd : ARIMA model not selected'
           IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.td: nomodel'
          END IF
          IF(Svltab(LSLTST).and.Laccss)
     &       CALL insacd(Ng,'regression.ats.automd',F)
         END IF
         IF(Leastr)THEN
          IF(Hvmdl)THEN
           iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Easter')
           IF(iaic.eq.0)iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                              'StatCanEaster')
           IF(Svltab(LSLTST).and.Laccss)
     &        CALL insacd(Ng,'regression.ats.automd',T)
           IF(iaic.gt.0)THEN
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICeaster : accepted'
            IF(Lsumm.gt.0)THEN
             WRITE(Nform,1060)'aictest.e: yes'
             WRITE(Nform,1061)'aictest.e.window: ',Aicind
            END IF
           ELSE
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICeaster : rejected'
            IF(Lsumm.gt.0)THEN
             WRITE(Nform,1060)'aictest.e: no'
             WRITE(Nform,1060)'aictest.e.window: 0'
            END IF
           END IF
          ELSE
           IF(Svltab(LSLTST))
     &        WRITE(Ng,1060)'   AICeaster : ARIMA model not selected'
           IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.e: nomodel'
          END IF
          IF(Svltab(LSLTST).and.Laccss)
     &       CALL insacd(Ng,'regression.ats.automd',F)
         END IF
         IF(Luser)THEN
          IF(Svltab(LSLTST).and.Laccss)
     &       CALL insacd(Ng,'regression.ats.automd',T)
          IF(Hvmdl)THEN
           iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,'User-defined')
           IF(iaic.gt.0)THEN
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICuser : accepted'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.u: yes'
           ELSE
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICuser : rejected'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.u: no'
           END IF
          ELSE
           IF(Svltab(LSLTST))
     &        WRITE(Ng,1060)'   AICuser : ARIMA model not selected'
           IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.u: nomodel'
          END IF
          IF(Svltab(LSLTST).and.Laccss)
     &       CALL insacd(Ng,'regression.ats.automd',F)
         END IF
        END IF
        IF(Itdtst.gt.0)Itdtst=0
        IF(Leastr)Leastr=F
        IF(Luser)Luser=F
c-----------------------------------------------------------------------
c     If a model is not selected, turn off prior adjustment by regARIMA
c     factors.
c-----------------------------------------------------------------------
        IF(Hvmdl)THEN
         CALL ssprep(T,F,F)
        ELSE
         IF(Adjtd.eq.1)Adjtd=0
         IF(Adjhol.eq.1)Adjhol=0
         IF(Adjao.eq.1)Adjao=0
         IF(Adjls.eq.1)Adjls=0
         IF(Adjtc.eq.1)Adjtc=0
         IF(Adjusr.eq.1)Adjusr=0
         IF(Adjsea.eq.1)Adjsea=0
         IF((.NOT.(Axrghl.or.Axruhl.or.Khol.ge.1)).and.Finhol)Finhol=F
         IF(Finao)Finao=F
         IF(Finls)Finls=F
         IF(Fintc)Fintc=F
         IF(Finusr)Finusr=F
         IF(Nfcst.gt.0)THEN
          Posffc=Posfob
          IF(Nfdrp.gt.0)Nfdrp=0
         END IF
         IF(nbeg.gt.0.or.nend.gt.0)
     &      CALL setspn(Sp,nend,nbeg,Begspn,Endspn,Begmdl,Endmdl,Nspobs,
     &                  Frstsy,Nobspf,Begsrs,Nobs,Nfcst,Fctdrp,Nomnfy,
     &                  Begadj,Adj1st)
         IF(Itdtst.gt.0)Itdtst=0
         IF(Leastr)Leastr=F
         IF(Luser)Luser=F
         IF(Irev.gt.0)THEN
          IF(Lrvfct)Lrvfct=F
          IF(Lrvaic)Lrvaic=F
          IF(Lx11)THEN
           IF(.not.(Lrvsa.or.Lrvsf.or.Lrvch.or.Lrvtrn.or.Lrvtch))Irev=0
          ELSE
           Irev=0
          END IF
         END IF
         IF(Missng.and.Lx11)THEN
          Lx11=F
          CALL writln('ERROR: Cannot perform seasonal adjustment if the
     &automatic model',STDERR,Mt2,T)
          CALL writln('       selection procedure cannot select an ARIMA
     & model and missing',STDERR,Mt2,F)
          CALL writln('       value regressors are part of the model.',
     &                STDERR,Mt2,T)
         END IF
         IF(.not.Convrg)CALL abend()
         RETURN
        END IF
       ELSE
        IF(Lsumm.gt.0.and.gudrun)
     &     WRITE(Nform,1060)'automodeltype: ','none'
c-----------------------------------------------------------------------
c     Print the BoxCox transformation parameter
c-----------------------------------------------------------------------
        IF(Prttab(LESTMD))THEN
         IF(Laccss)CALL insacd(Mt1,'h3',T)
         IF(.not.Lcmpaq)WRITE(Mt1,'()')
         WRITE(Mt1,1090)
         IF(Laccss)CALL insacd(Mt1,'h3',F)
         CALL prprad(Adjttl,Nadjcr,Nustad,Nuspad,Priadj,Reglom)
         IF(Priadj.gt.0)WRITE(Mt1,'()')
         CALL prtnfn(Fcntyp,Lam,0)
c-----------------------------------------------------------------------
c     Short description of the regression and ARIMA parts of the model
c-----------------------------------------------------------------------
         IF(Laccss)CALL insmrk(Mt1,LESTMD,T,F)
         IF(Ngrp.gt.0)
     &      CALL desreg('Regression Model',Ngrp,Grpttl,Grpptr,Ngrptl)
         IF(Ngrpfx.gt.0)
     &      CALL desreg('Regression Model (fixed)',Ngrpfx,Gfxttl,Gfxptr,
     &                  Ngfxtl)
         IF(Lfatal)RETURN
         CALL dsarma(Lcmpaq)
         CALL prtmsp(Begmdl,Endmdl,Sp,F)
         IF(Lfatal)RETURN
         IF(Laccss)CALL insmrk(Mt1,LESTMD,F,F)
        END IF
c     ------------------------------------------------------------------
        IF(Lsumm.gt.0.and.gudrun)THEN
         IF(Nmdl.gt.0)THEN
          WRITE(Nform,1050)Mdldsn(1:Nmddcr)
         ELSE
          WRITE(Nform,1050)'(0 0 0)'
         END IF
         WRITE(Nform,1061)'maxiter: ',Mxiter
         WRITE(Nform,1021)'tol: ',Tol
        END IF
c     ------------------------------------------------------------------
        IF(.not.Lhiddn.and.istrue(Prttab,LESTOP,LESTRS))THEN
         IF(Laccss)THEN
          IF(Prttab(LESTOP))THEN
           CALL insmrk(Mt1,LESTOP,T,F)
          ELSE
           CALL insacd(Mt1,'h3',T)
          END IF
         END IF
         WRITE(Mt1,1100)
         IF((.not.Prttab(LESTOP)).and.Laccss)CALL insacd(Mt1,'h3',F)
        END IF
        IF(Prttab(LESTOP))THEN
         CALL prtopt(Lestim,Mxiter,Mxnlit)
         IF(Laccss)CALL insmrk(Mt1,LESTOP,F,F)
        END IF
c-----------------------------------------------------------------------
c     Estimate the regression and ARMA parameters and print the results.
c-----------------------------------------------------------------------
        IF(Leastr.or.(Luser.and.Ncusrx.gt.0).or.Itdtst.gt.0)THEN
         litr=Prttab(LESTIT).or.Savtab(LESTIT)
         IF(Itdtst.gt.0)THEN
          CALL tdaic(trnsrs,a,nefobs,na,frstry,lester,iaic,ltdlom,litr,
     &               LRGATS,LESTFM,LSLTST,Lsumm,Lhiddn)
          IF(Lfatal)RETURN
          IF(lester)THEN
           CALL writln('ERROR: An model estimation error has occurred du
     &ring the AIC testing of',STDERR,Mt2,T)
           CALL writln('       trading day regressor(s).  The error mess
     &age appears below.',STDERR,Mt2,F)
           IF(Laccss)CALL insacd(Mt1,'zero',T)
           CALL prterr(nefobs,lauto)
           IF(Lfatal)RETURN
           IF(Laccss)CALL insacd(Mt1,'zero',F)
          END IF
c-----------------------------------------------------------------------
c     If different trading day chosen, resave regARIMA model variables
c     for sliding spans analysis
c-----------------------------------------------------------------------
          IF(iaic.ge.1)CALL ssprep(T,F,F)
          IF(Svltab(LSLTST).or.(Lsumm.gt.0.and.gudrun))THEN
           IF(Svltab(LSLTST).and.Laccss)CALL insmrk(Ng,LSLTST,T,T)
           iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Trading Day')
           IF(iaic.eq.0)iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                              'Stock Trading Day')
           IF(Lsumm.gt.0)THEN
            CALL mktdlb(tdstr,ntdchr,Itdtst,Aicstk,Aicrgm,Tdzero,Sp)
            IF(Lfatal)RETURN
            WRITE(Nform,1060)'aictest.td.reg: ',tdstr(1:ntdchr)
           END IF
           IF(iaic.gt.0)THEN
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICtd : accepted'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.td: yes'
           ELSE
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICtd : rejected'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.td: no'
           END IF
           IF(Svltab(LSLTST).and.Laccss)CALL insmrk(Ng,LSLTST,F,T)
          END IF
         END IF
         IF(.not.lester.and.Leastr)THEN
          CALL easaic(trnsrs,a,nefobs,na,frstry,lester,litr,
     &                LRGATS,LESTFM,LSLTST,Lsumm,Lhiddn)
          IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Resave regARIMA model variables for sliding spans analysis
c-----------------------------------------------------------------------
          IF(lester)THEN
           CALL writln('ERROR: An model estimation error has occurred du
     &ring the AIC testing of',STDERR,Mt2,T)
           CALL writln('       an Easter regressor.  The error message a
     &ppears below.',STDERR,Mt2,F)
           CALL prterr(nefobs,lauto)
           IF(Lfatal)RETURN
          END IF
          CALL ssprep(T,F,F)
          IF(Svltab(LSLTST).or.(Lsumm.gt.0.and.gudrun))THEN
           IF(Svltab(LSLTST).and.Laccss)CALL insmrk(Ng,LSLTST,T,T)
           iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Easter')
           IF(iaic.eq.0)iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                              'StatCanEaster')
           IF(iaic.gt.0)THEN
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICeaster : accepted'
            IF(Lsumm.gt.0)THEN
             WRITE(Nform,1060)'aictest.e: yes'
             WRITE(Nform,1061)'aictest.e.window: ',Aicind
            END IF
           ELSE
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICeaster : rejected'
            IF(Lsumm.gt.0)THEN
             WRITE(Nform,1060)'aictest.e: no'
             WRITE(Nform,1060)'aictest.e.window: 0'
            END IF
           END IF
           IF(Svltab(LSLTST).and.Laccss)CALL insmrk(Ng,LSLTST,F,T)
          END IF
         END IF
         IF(.not.lester.and.(Luser.and.Ncusrx.gt.0))THEN
          CALL usraic(trnsrs,a,nefobs,na,frstry,lester,litr,
     &                LRGATS,LESTFM,LSLTST,Lsumm,Lhiddn)
          IF(Lfatal)RETURN
          IF(lester)THEN
           CALL writln('ERROR: An model estimation error has occurred du
     &ring the AIC testing of',STDERR,Mt2,T)
           CALL writln('       user defined regressor(s).  The error mes
     &sage appears below.',STDERR,Mt2,F)
           CALL prterr(nefobs,lauto)
           IF(Lfatal)RETURN
          END IF
          CALL ssprep(T,F,F)
          IF(Svltab(LSLTST).or.(Lsumm.gt.0.and.gudrun))THEN
           IF(Svltab(LSLTST).and.Laccss)CALL insmrk(Ng,LSLTST,T,T)
           iaic=strinx(T,Grpttl,Grpptr,1,Ngrptl,'User-defined')
           IF(iaic.gt.0)THEN
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICuser : accepted'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.u: yes'
           ELSE
            IF(Svltab(LSLTST))WRITE(Ng,1060)'   AICuser : rejected'
            IF(Lsumm.gt.0)WRITE(Nform,1060)'aictest.u: no'
           END IF
           IF(Svltab(LSLTST).and.Laccss)CALL insmrk(Ng,LSLTST,F,T)
          END IF
         END IF
c-----------------------------------------------------------------------
c     Turn off AIC test options
c-----------------------------------------------------------------------
         IF(Itdtst.gt.0)Itdtst=0
         IF(Leastr)Leastr=F
         IF(Luser)Luser=F
c         IF(Laccss.and.Prttab(LRGATS))CALL insmrk(Mt1,LRGATS,F,F)
        ELSE
c-----------------------------------------------------------------------
c     Estimate the regression and ARMA parameters and print the results.
c-----------------------------------------------------------------------
         ltmp=F
         IF(Laccss.and.Prttab(LESTIT))CALL insmrk(Mt1,LESTIT,T,F)
         CALL rgarma(Lestim,Mxiter,Mxnlit,(Prttab(LESTIT).or.
     &               Savtab(LESTIT)),a,na,nefobs,ltmp)
c-----------------------------------------------------------------------
c     check to see if there are estimation errors in previous model
c     estimation
c-----------------------------------------------------------------------
         IF(.not.Lfatal)THEN
          IF(Laccss.and.Prttab(LESTIT))CALL insmrk(Mt1,LESTIT,F,F)
          IF(Laccss.and.(.not.Lhiddn))CALL insacd(Mt1,'zero',T)
          CALL prterr(nefobs,lauto)
          IF(Laccss.and.(.not.Lhiddn))CALL insacd(Mt1,'zero',F)
         END IF
         IF(Lfatal)RETURN
c------------------------------------------------------------------------
c     If model estimation saves the estimation iterations, turn this off
c     for the rest of the run
c------------------------------------------------------------------------
         IF(Savtab(LESTIT))Savtab(LESTIT)=F
        END IF
        Hvmdl=T
c-----------------------------------------------------------------------
c     Outlier identification
c-----------------------------------------------------------------------
        IF(.not.lester.and.lidotl)THEN
c-----------------------------------------------------------------------
         IF(Prttab(LOTLHD))THEN
          IF(Laccss)CALL insmrk(Mt1,LOTLHD,T,F)
          CALL prothd(Begtst,Endtst,Ltstao,Ltstls,Ltsttc,Ladd1,Critvl)
          IF(Lfatal)RETURN
          IF(Laccss)CALL insmrk(Mt1,LOTLHD,F,F)
         END IF
c-----------------------------------------------------------------------
         IF(Prttab(LOTLIT))THEN
          IF(Prttab(LESAFC).and.Var.gt.ZERO)THEN
           CALL amdfct(trnsrs,mape,Nobspf,Nfcst,F,fctok,F)
           IF(Lfatal)RETURN
           IF(fctok)THEN
            IF(Laccss)CALL insmrk(Mt1,LESAFC,T,F)
            CALL prafce(Mt1,mape,Outfct,T)
            IF((.not.Lfatal).and.Laccss)CALL insmrk(Mt1,LESAFC,F,F)
           END IF
          END IF
          IF(Lfatal)RETURN
          CALL prtmdl(Lestim,LESTES,Lcalcm,0,F,F,LESTCM,0,LESTES,itmp,
     &                LESTES,0,LESTIT)
c-----------------------------------------------------------------------
          IF(.not.Lfatal)CALL prlkhd(Y(Frstsy),Adj(Adj1st),Adjmod,
     &                               Fcntyp,Lam,0,0,0)
          IF(Lfatal)RETURN
         END IF
c-----------------------------------------------------------------------
c         CALL timer(iticks)
c         WRITE(Ng,*)  '  timer(3) = ', iticks, ' (time up to idotlr)'
c         IF(Laccss)CALL insmrk(Mt1,LOTLTS,T,F)
         CALL idotlr(Ltstao,Ltstls,Ltsttc,Ladd1,Critvl,Cvrduc,Begtst,
     &               Endtst,nefobs,Lestim,Mxiter,Mxnlit,lester,a,trnsrs,
     &               Nobspf,Nfcst,Outfct,fctok,F,0,0,LOTLTS,LOTLIT,
     &               LOTLFT,Lgraf,Lsumm.gt.0.and.gudrun)
c        CALL timer(iticks)
c         WRITE(Ng,*)  '  timer(4) = ', iticks, ' (time after idotlr)'
c-----------------------------------------------------------------------
         IF(.not.Lfatal)THEN
c          IF(Laccss)CALL insmrk(Mt1,LOTLTS,F,F)
          IF(.not.Convrg)THEN
           IF(Laccss.and.(.not.Lhiddn))CALL insacd(Mt1,'zero',T)
           CALL prterr(Nefobs,lauto)
           IF((.not.Lfatal).and.Laccss.and.(.not.Lhiddn))
     &        CALL insacd(Mt1,'zero',F)
          END IF
         ENDIF
         IF(.not.Lfatal)
     &      CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,
     &                  Nrusrx,Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
         IF(Lfatal)RETURN
         CALL ssprep(T,F,F)
         IF(Lsumm.gt.0.and.gudrun)THEN
          IF(Ltstao)THEN
           cdef=' '
           IF(dpeq(Critvl(AO),cv))cdef='*'
           WRITE(Nform,1010)'aocrit: ',Critvl(AO),cdef
          END IF
          IF(Ltstls)THEN
           cdef=' '
           IF(dpeq(Critvl(LS),cv))cdef='*'
           WRITE(Nform,1010)'lscrit: ',Critvl(LS),cdef
          END IF
          IF(Ltsttc)THEN
           cdef=' '
           IF(dpeq(Critvl(TC),cv))cdef='*'
           WRITE(Nform,1010)'tccrit: ',Critvl(TC),cdef
          END IF
         END IF
        END IF
       END IF
c-----------------------------------------------------------------------
c     Compute and print out average forecast error from original 
c     X-11-ARIMA
c-----------------------------------------------------------------------
       IF(Var.gt.ZERO)THEN
        ldiag=Lsumm.gt.0.and.gudrun
        IF(Prttab(LESAFC).or.Svltab(LSLAFC).or.ldiag)
     &     CALL amdfct(trnsrs,mape,Nobspf,Nfcst,F,fctok,F)
        IF(Lfatal)RETURN
        IF(fctok.and.Prttab(LESAFC))THEN
         IF(Laccss)CALL insmrk(Mt1,LESAFC,T,F)
         CALL prafce(Mt1,mape,Outfct,T)
         IF(Laccss)CALL insmrk(Mt1,LESAFC,F,F)
        END IF
c-----------------------------------------------------------------------
c     Print out entry for log
c-----------------------------------------------------------------------
        IF(fctok.and.Svltab(LSLAFC))THEN
         IF(Laccss)CALL insmrk(Ng,LSLAFC,T,T)
         IF(Outfct)THEN
          WRITE(Ng,1210)'out-of-sample forecasts'
         ELSE
          WRITE(Ng,1210)'within-sample forecasts'
         END IF
         WRITE(Ng,1220)(mape(i),i=1,4)
         IF(Laccss)CALL insmrk(Ng,LSLAFC,F,T)
        END IF
        IF(fctok.and.ldiag)THEN
         IF(Outfct)THEN
          WRITE(Nform,'(a)')'aape.mode: outofsample'
         ELSE
          WRITE(Nform,'(a)')'aape.mode: withinsample'
         END IF
         WRITE(Nform,1200)'aape.0: ',mape(4)
         WRITE(Nform,1200)'aape.1: ',mape(1)
         WRITE(Nform,1200)'aape.2: ',mape(2)
         WRITE(Nform,1200)'aape.3: ',mape(3)
        END IF
       ELSE
        fctok=F
       END IF
       IF(.not.fctok)THEN
        IF(Svltab(LSLAFC))THEN
         IF(Laccss)CALL insmrk(Ng,LSLAFC,T,T)
         WRITE(Ng,1210)'none'
         IF(Laccss)CALL insmrk(Ng,LSLAFC,F,T)
        END IF
        IF(ldiag)WRITE(Nform,'(a)')'aape.mode: none'
       END IF
       IF(Lsumm.gt.0.and.gudrun)THEN
        iauto=0
        iao=0
        ils=0
        itc=0
        iramp=0
        iuser=0
        IF(Nb.gt.0)THEN
         DO i1=1,Nb
          IF(Rgvrtp(i1).eq.PRGTAA.or.Rgvrtp(i1).eq.PRGTAL.or.
     &       Rgvrtp(i1).eq.PRGTAT)iauto=iauto+1
          IF(Rgvrtp(i1).eq.PRGTAA.or.Rgvrtp(i1).eq.PRGTAO)iao=iao+1
          IF(Rgvrtp(i1).eq.PRGTAL.or.Rgvrtp(i1).eq.PRGTLS)ils=ils+1
          IF(Rgvrtp(i1).eq.PRGTAT.or.Rgvrtp(i1).eq.PRGTTC)itc=itc+1
          IF(Rgvrtp(i1).eq.PRGTRP)iramp=iramp+1
         END DO
        END IF
        IF(Ncusrx.gt.0)THEN
         DO i1=1,Nb
          IF(Usrtyp(i1).eq.PRGTAO.or.Usrtyp(i1).eq.PRGTLS.or.
     &       Usrtyp(i1).eq.PRGTTC.or.Usrtyp(i1).eq.PRGTRP)iuser=iuser+1
         END DO
        END IF
        WRITE(Nform,1190)'outlier.ao: ',iao
        WRITE(Nform,1190)'outlier.ls: ',ils
        WRITE(Nform,1190)'outlier.tc: ',itc
        WRITE(Nform,1190)'outlier.rp: ',iramp
        IF(Ncusrx.gt.0)WRITE(Nform,1190)'outlier.user: ',iuser
        WRITE(Nform,1190)'outlier.total: ',iao+ils+itc+iramp+iuser
        IF(lidotl)WRITE(Nform,1190)'autoout: ',iauto
       END IF
c-----------------------------------------------------------------------
c     Print out the final model
c-----------------------------------------------------------------------
       IF(Iregfx.ge.2)THEN
        CALL addfix(trnsrs,Nbcst,0,1)
        IF(.not.Lfatal)
     &     CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
     &                 Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
        IF(Lfatal)RETURN
       END IF
       ldiag=Lsumm.gt.0.and.gudrun
       CALL prtmdl(Lestim,LESTES,Lcalcm,LESTES,Lgraf,ldiag,LESTCM,
     &             LESTCM,LESTES,Lsrun,LESTES,LOTLTL,LESTIT)
c-----------------------------------------------------------------------
       IF(Convrg.and.Lestim.and.gudrun.and.Nliter.gt.BADITR)THEN
        IF(.not.Lquiet)WRITE(STDERR,1101)BADITR
        IF(Prttab(LESTIT).or.Prttab(LESTES))WRITE(Mt1,1101)BADITR
        WRITE(Mt2,1101)
 1101   FORMAT(/,' WARNING: Convergence of the coefficient estimation ',
     &          'procedure required',/,
     &         '          more than ',i3,' iterations. This often ',
     &         'indicates some inadequacy',/
     &         '          in the model being estimated.',/)
       END IF
c-----------------------------------------------------------------------
       IF(Lestim.and.Prttab(LESTES).and.gudrun)THEN
        begopr=Opr(Mdl(AR-1)-1)
        endopr=Opr(Mdl(MA)-1)-1
        IF(Laccss)CALL insacd(Mt1,'zero',T)
        IF(istrue(Arimaf,begopr,endopr))THEN
         CALL writln(' NOTE: Fixed values have been assigned to some reg
     &ression and ARIMA model',Mt1,Mt2,T)
         CALL writln('       coefficients.  If these values are estimate
     &s calculated by '//PRGNAM//',',Mt1,Mt2,F)
         CALL writln('       then the model comparison statistics (AIC, 
     &AICC, Hannan Quinn, and BIC)',Mt1,Mt2,F)
         CALL writln('       and the P-values of the Q''s of the sample 
     &autocorrelations of the',Mt1,Mt2,F)
         CALL writln('       residuals below are invalid and should not 
     &be used.',Mt1,Mt2,F)
        ELSE IF(istrue(Regfx,1,Nb))THEN
         CALL writln(' NOTE: Fixed values have been assigned to some reg
     &ression coefficients.',Mt1,Mt2,T)
         CALL writln(
     &     '       If these values are estimates calculated by '//
     &     PRGNAM//', then the',Mt1,Mt2,F)
         CALL writln('       model comparison statistics (AIC, AICC, Han
     &nan Quinn and BIC)',Mt1,Mt2,F)
         CALL writln(
     &     '       below are invalid and should not be used.',Mt1,Mt2,F)
        END IF
        IF(Laccss)CALL insacd(Mt1,'zero',F)
       END IF
c-----------------------------------------------------------------------
       IF(.not.Lfatal.and.Prttab(LESTAM).and.Lcalcm)THEN
        IF(Laccss)CALL insmrk(Mt1,LESTAM,T,F)
        CALL armacr
        IF(Laccss)CALL insmrk(Mt1,LESTAM,F,F)
       END IF
       IF(.not.Lfatal.and.Savtab(LESTAM).and.Lcalcm)CALL svamcm
       IF(Lfatal)RETURN
       ldiag=Lsumm.gt.0.and.gudrun
       IF(Prttab(LESTST).or.Savtab(LESTST).or.Prttab(LESTFM).or.
     &    Irev.eq.4.or.ldiag)THEN
        CALL prlkhd(Y(Frstsy),Adj(Adj1st),Adjmod,Fcntyp,Lam,LESTST,
     &              LESTST,LESTFM)
        IF(Lfatal)RETURN
       END IF
       IF(ldiag.and.(.not.dpeq(Lnlkhd,DNOTST)))THEN
        WRITE(Nform,1200)'loglikelihood: ',Lnlkhd
        WRITE(Nform,1200)'aic: ',Aic
        WRITE(Nform,1200)'aicc: ',Aicc
        WRITE(Nform,1200)'bic: ',Bic
        WRITE(Nform,1200)'hq: ',Hnquin
       END IF
c-----------------------------------------------------------------------
c     check to see if one of the likelihood statistics will be stored
c     in the log
c-----------------------------------------------------------------------
       svllkh=Svltab(LSLAIC).and.(.not.dpeq(Aic,DNOTST)).or.
     &    Svltab(LSLACC).and.(.not.dpeq(Aicc,DNOTST)).or.
     &    Svltab(LSLBIC).and.(.not.dpeq(Bic,DNOTST)).or.
     &    Svltab(LSLHQ).and.(.not.dpeq(Hnquin,DNOTST))
       IF(svllkh.and.Laccss)CALL insmrk(Ng,LSLAIC,T,T)    
       IF(Svltab(LSLAIC).and.(.not.dpeq(Aic,DNOTST)))
     &    WRITE(Ng,1200)'   AIC  : ',Aic
       IF(Svltab(LSLACC).and.(.not.dpeq(Aicc,DNOTST)))
     &    WRITE(Ng,1200)'   AICC : ',Aicc
       IF(Svltab(LSLBIC).and.(.not.dpeq(Bic,DNOTST)))
     &    WRITE(Ng,1200)'   BIC  : ',Bic
       IF(Svltab(LSLHQ).and.(.not.dpeq(Hnquin,DNOTST)))
     &    WRITE(Ng,1200)'   Hannan-Quinn  : ',Hnquin
       IF(svllkh.and.Laccss)CALL insmrk(Ng,LSLAIC,F,T)    
c-----------------------------------------------------------------------
c     Print out the roots of the AR and MA polynomials
c-----------------------------------------------------------------------
       IF(Prttab(LESTRT).or.Savtab(LESTRT))THEN
        IF(Laccss)CALL insmrk(Mt1,LESTRT,T,F)
        CALL prtrts(Prttab(LESTRT),Savtab(LESTRT))
        IF(Lfatal)RETURN
        IF(Laccss)CALL insmrk(Mt1,LESTRT,F,F)
       END IF
      END IF
c-----------------------------------------------------------------------
c     Print out the regression matrix with the added outliers
c-----------------------------------------------------------------------
      IF(Prttab(LREGDT).and.Nb.gt.0)THEN
       IF(Laccss)CALL insmrk(Mt1,LREGDT,T,F)
       CALL prtshd('Regression Matrix',Begxy,Sp,Nrxy,T)
       IF(.not.Lfatal)CALL prtmtx(Begxy,Sp,Xy,Nrxy,Ncxy,Colttl,Colptr,
     &                            Ncoltl)
       IF(Lfatal)RETURN
       IF(Laccss)CALL insmrk(Mt1,LREGDT,F,F)
      END IF
c-----------------------------------------------------------------------
      IF(Savtab(LREGDT))THEN
       CALL savmtx(LREGDT,Begxy,Sp,Xy,Nrxy,Ncxy,Colttl,Colptr,Ncoltl)
       IF(Lfatal)RETURN
      END IF
c-----------------------------------------------------------------------
      IF(.not.Lfatal.and.Prttab(LRGTDW).and.Lcalcm)THEN
       IF(Laccss)CALL insmrk(Mt1,LRGTDW,T,F)
       CALL prtdwr()
       IF(Laccss)CALL insmrk(Mt1,LRGTDW,F,F)
      END IF
c-----------------------------------------------------------------------
      IF(Ldestm)THEN
       IF(Savtab(LESTMD))THEN
        CALL savmdl(Begxy,Nrxy,Elong)
        IF(Lfatal)RETURN
       END IF
c-----------------------------------------------------------------------
c     Print out the residuals
c-----------------------------------------------------------------------
       IF(Prttab(LESTRS).or.Savtab(LESTRS))THEN
        CALL addate(Begspn,Sp,Nspobs-na,idate)
c-----------------------------------------------------------------------
        IF(Prttab(LESTRS))THEN
         outdec=Kdec
         IF(outdec.lt.3)outdec=3
         IF(Laccss)CALL insmrk(Mt1,LESTRS,T,F)
         CALL prtshd('Model Residuals',idate,Sp,na,T)
         IF(Lfatal)RETURN
         CALL prttbl(idate,Sp,a,na,'Data',outdec)
         IF(Laccss)CALL insmrk(Mt1,LESTRS,F,F)
        END IF
c-----------------------------------------------------------------------
        IF(Savtab(LESTRS))THEN
         CALL savtbl(LESTRS,idate,1,na,Sp,a,Serno,Nser,F)
         IF(Lfatal)RETURN
        END IF
       END IF
c-----------------------------------------------------------------------
c     Calculate the ACF, ACF of squared residual, and residual histogram
c-----------------------------------------------------------------------
       IF(Convrg)THEN
        IF(Mxcklg.gt.0)THEN
         IF(.not.Lhiddn.and.istrue(Prttab,LCKACF,LCKNRM))THEN
          IF(Laccss)CALL insacd(Mt1,'h3',T)
          WRITE(Mt1,1110)
          IF(Laccss)CALL insacd(Mt1,'h3',F)
         END IF
         ldiag=Lsumm.gt.0.and.gudrun
         CALL prtacf(LSPCHK,nefobs,a,na,Mxcklg,Lgraf,ldiag,NOTSET,
     &               NOTSET)
         IF(Lfatal)RETURN
c-----------------------------------------------------------------------
         IF(gudrun)THEN
          nlagbl=MIN(Mxcklg,Sp*2)
          IF(ldiag.or.Svltab(LSLLBQ))
     &       CALL acfdgn(nefobs,a,na,Mxcklg,nlagbl,ldiag)
c-----------------------------------------------------------------------
          CALL pracf2(nefobs,a,na,Mxcklg,Lgraf)
          IF(Lfatal)RETURN
         END IF
c-----------------------------------------------------------------------
         IF(Prttab(LCKHST).and.Var.gt.ZERO)THEN
          IF(Laccss)CALL insmrk(Mt1,LCKHST,T,F)
          CALL hist(a(na-nefobs+1),Begspn,Sp,nefobs,Nobs-nefobs,LCKHST)
          IF(Lfatal)RETURN
         END IF
         IF((Prttab(LCKNRM).or.Savtab(LCKNRM).or.Svltab(LSLNRM)).and.
     &       Var.gt.ZERO.and.gudrun)THEN
          IF(Laccss)THEN
           IF(Prttab(LCKNRM))CALL insmrk(Mt1,LCKNRM,T,F)
           IF(Svltab(LSLNRM))CALL insmrk(Ng,LSLNRM,T,T)
          END IF
          IF(Prttab(LCKNRM))WRITE(Mt1,1180)
          CALL nrmtst(a(na-nefobs+1),nefobs,Prttab(LCKNRM),
     &                Savtab(LCKNRM),Svltab(LSLNRM))
          IF(Laccss)THEN
           IF(Prttab(LCKNRM))CALL insmrk(Mt1,LCKNRM,F,F)
           IF(Svltab(LSLNRM))CALL insmrk(Ng,LSLNRM,F,T)
          END IF
         END IF
         IF((Prttab(LCKSPR).or.Savtab(LCKSPR).or.Lgraf).and.
     &       Var.gt.ZERO.AND.(Sp.eq.12.or.Sp.eq.4).and.gudrun)THEN
          CALL addate(Begspn,Sp,Nspobs-na,idate)
c          CALL addate(idate,Sp,na-nefobs+1,idate)
          CALL spcrsd(a,na,idate,Sp,Endspn,LCKSPR,Lsumm,Lgraf)
c          CALL spcrsd(a(na-nefobs+1),nefobs,idate,Sp,Endspn,LCKSPR,
c     &                Lsumm,Lgraf)
          IF(Lfatal)RETURN
         END IF
        END IF
c-----------------------------------------------------------------------
c     Reset ending date of span for forecasting, if necessary.
c-----------------------------------------------------------------------
        IF(nend.gt.0)THEN
         CALL setspn(Sp,nend,0,Begspn,Endspn,Begmdl,Endmdl,Nspobs,
     &               Frstsy,Nobspf,Begsrs,Nobs,Nfcst,Fctdrp,Nomnfy,
     &               Begadj,Adj1st)
c-----------------------------------------------------------------------
c     Recopy the series into trnsrs, and redo the transformation
c-----------------------------------------------------------------------
         CALL copy(Sto(Pos1ob+nbeg),Nspobs,-1,trnsrs)
         CALL trnfcn(trnsrs,Nspobs,Fcntyp,Lam,trnsrs)
         IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Generate regression matrix
c-----------------------------------------------------------------------
         CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
     &               Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
         IF(Lfatal)RETURN
        END IF
c-----------------------------------------------------------------------
c     Forecasts
c-----------------------------------------------------------------------
        IF(Nfcst.gt.0)THEN
         CALL prtfct(Nobspf,Nrxy,Fcntyp,Lam,Fctdrp,Nfcst,Ciprob,fcstx,
     &               untfct,Kdec,Posfob,Lgraf,Lsumm.gt.0.and.gudrun,
     &               Khol,Kswv)
         IF(Lfatal)RETURN
        END IF
c-----------------------------------------------------------------------
c     Backcasts
c-----------------------------------------------------------------------
        IF(Nbcst.gt.0)THEN
         CALL mkback(trnsrs,Priadj,bcstx,untbct,Pos1bk,Kdec,Lgraf)
         IF(Lfatal)RETURN
        END IF
c-----------------------------------------------------------------------
c     Reset beginning dates of span, if necessary.
c-----------------------------------------------------------------------
        IF(nbeg.gt.0)THEN
         CALL setspn(Sp,nend,nbeg,Begspn,Endspn,Begmdl,Endmdl,Nspobs,
     &               Frstsy,Nobspf,Begsrs,Nobs,Nfcst,Fctdrp,Nomnfy,
     &               Begadj,Adj1st)
c-----------------------------------------------------------------------
c     Recopy the series into trnsrs, and redo the transformation
c-----------------------------------------------------------------------
         CALL copy(Sto(Pos1ob),Nspobs,-1,trnsrs)
         CALL trnfcn(trnsrs,Nspobs,Fcntyp,Lam,trnsrs)
         IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Generate regression matrix
c-----------------------------------------------------------------------
         CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,Nbcst,Userx,Bgusrx,
     &               Nrusrx,Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
         IF(Lfatal)RETURN
        END IF
c-----------------------------------------------------------------------
c     If estimation did not converge, exit with an error
c-----------------------------------------------------------------------
       ELSE
        CALL abend
        RETURN
       END IF
      END IF
c-----------------------------------------------------------------------
c     Extend Series with backcasts and forecasts
c-----------------------------------------------------------------------
      CALL setdp(ZERO,PLEN,orix)
      IF(Ldestm.and.((Nfcst.gt.0.and.Nfdrp.gt.0).or.Nbcst.gt.0))THEN
       CALL extend(trnsrs,Begxy,orix,Extok,Lam,fcstx,bcstx)
       IF(Lfatal)RETURN
      ELSE
       CALL copy(trnsrs,Nobspf,1,orix(Pos1ob))
      END IF
c-----------------------------------------------------------------------
c     initialize regression factors to zero
c-----------------------------------------------------------------------
      CALL setdp(ZERO,PLEN,ftd)
      CALL setdp(ZERO,PLEN,fhol)
      CALL setdp(ZERO,PLEN,fao)
      CALL setdp(ZERO,PLEN,fls)
      CALL setdp(ZERO,PLEN,ftc)
      CALL setdp(ZERO,PLEN,fusr)
      CALL setdp(ZERO,PLEN,fsea)
      CALL setdp(ZERO,PLEN,fmv)
c-----------------------------------------------------------------------
c     Print the header for the regression effects matrix, if necessary
c-----------------------------------------------------------------------
      nf2=NOTSET
      IF(Ldestm)THEN
       IF(Prttab(LESTRE))THEN
        IF(Laccss)CALL insmrk(Mt1,LESTRE,T,F)
        CALL prtshd('Regression Effects',Begxy,Sp,Nrxy,T)
        IF(Lfatal)RETURN
       END IF
c-----------------------------------------------------------------------
       CALL chkadj(tdreg,Khol,Lam)
       IF(Prttab(LESTRE).or.Savtab(LESTRE).or.Adjtd.eq.1.or.Adjhol.eq.1
     &    .or.Adjao.eq.1.or.Adjls.eq.1.or.Adjtc.eq.1.or.Adjsea.eq.1.or.
     &    Adjusr.eq.1.or.Finhol.or.Finao.or.Finls.or.Fintc.or.Finusr.or.
     &    Missng)THEN
c-----------------------------------------------------------------------
c     If number of forecasts is less that the length of the seasonal
c     period, redo the regression variables so that there are enough
c     regressors for one year of forecasts.
c-----------------------------------------------------------------------
c        IF(Nfcst.lt.Sp.and.(Adjtd.eq.1.or.Adjhol.eq.1.or.Adjao.eq.1.or.
c     &    Adjls.eq.1.or.Adjtc.eq.1.or.Adjsea.eq.1.or.Adjusr.eq.1.or.
c     &    Finhol.or.Finao.or.Finls.or.Fintc.or.Finusr.or.Missng).and.
c     &    Lx11)THEN
c         nf2=Nfcst
c         Nfcst=Sp
c         Nobspf=min(Nspobs+max(Nfcst-Fctdrp,0),Nomnfy)
c         CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,Nbcst,Userx,Bgusrx,
c     &               Nrusrx,Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
c         IF(Lfatal)RETURN
c        END IF
c-----------------------------------------------------------------------
c     Print out the regression effects with the added outliers for the
c     series extended by forecasts and backcasts
c-----------------------------------------------------------------------
        CALL prtref(Begxy,Nrxy,Prttab(LESTRE),Savtab(LESTRE),ftd,fhol,
     &              fao,fls,ftc,fusr,fsea,fmv,Nusrrg)
        IF(Lfatal)RETURN
        IF(Prttab(LESTRE).and.Laccss)CALL insmrk(Mt1,LESTRE,F,F)
c-----------------------------------------------------------------------
c     Check for improper adjustment mode in seasonal adjustment
c-----------------------------------------------------------------------
        IF(Lx11.and.(Adjtd.eq.1.or.Adjhol.eq.1.or.Adjao.eq.1.or.
     &     Adjls.eq.1.or.Adjtc.eq.1.or.Adjsea.eq.1.or.Adjusr.eq.1.or.
     &     Finao.or.(Finhol.and.Nhol.gt.0).or.Finls.or.Fintc.or.
     &     Finusr))THEN
         IF(Muladd.eq.1.AND.(.not.dpeq(Lam,ONE)))THEN
          CALL writln('ERROR: Additive seasonal adjustment will not be p
     &erformed when',STDERR,Mt2,T)
          CALL writln('       preadjustment factors are derived from a R
     &EGARIMA model ',STDERR,Mt2,F)
          CALL writln('       for transformed data.',STDERR,Mt2,F)
          CALL writln('       Check the values for the power or function 
     & arguments of the ',STDERR,Mt2,T)
          CALL writln('       transform spec and mode of the x11 spec.',
     &                STDERR,Mt2,F)
          CALL abend()
c-----------------------------------------------------------------------
         ELSE IF((Muladd.eq.0.or.Muladd.eq.2).AND.
     &           (.not.dpeq(Lam,ZERO)))THEN
          CALL writln('ERROR: Multiplicative or log additive seasonal ad
     &justment cannot be',STDERR,Mt2,T)
          CALL writln('       performed when preadjustment factors are d
     &erived from a regARIMA',STDERR,Mt2,F)
          CALL writln('       model for data which have not been log tra
     &nsformed.',STDERR,Mt2,F)
          CALL writln('       Check the values for the power or function 
     & arguments of the ',STDERR,Mt2,T)
          CALL writln('       transform spec and mode of the x11 spec.',
     &                STDERR,Mt2,F)
          CALL abend()
         END IF
         IF(Lfatal)RETURN
        END IF
       END IF
      END IF
c-----------------------------------------------------------------------
c     Generate adjustment factors for regression variables
c-----------------------------------------------------------------------
      CALL adjreg(orix,orixmv,Temp,ftd,fao,fls,ftc,fsea,fusr,fmv,fhol,
     &            Fcntyp,Lam,Nrxy,n)
c-----------------------------------------------------------------------
c     IF regression matrix was extended, restore variables to their 
c     original state
c-----------------------------------------------------------------------
c      IF(nf2.ne.NOTSET)THEN
c       Nfcst=nf2
c       Nobspf=min(Nspobs+max(Nfcst-Fctdrp,0),Nomnfy)
c       CALL regvar(trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
c     &             Priadj,Reglom,Nrxy,Begxy,frstry,T,Elong)
c       IF(Lfatal)RETURN
c      END IF
c-----------------------------------------------------------------------
c     Get regression trading day factors for type of month table
c-----------------------------------------------------------------------
      IF((Tdtbl.ge.2.and.Lx11.and.gudrun).and.Ldestm)THEN
       IF(tdreg.eq.0)THEN
        Tdtbl=Tdtbl-2
       ELSE IF(Irev.lt.4)THEN
        tdreg=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Trading Day')
        IF(tdreg.eq.0)tdreg=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                             'Stock Trading Day')
c        IF(tdreg.eq.0)tdreg=-strinx(F,Grpttl,Grpptr,1,Ngrptl,
c     &                              'User-defined')
        CALL getmtd(tdreg,Tdtbl,Tday,Begxy,Nrxy,Fcntyp,Lam)
        IF(Lfatal)RETURN
       END IF
      END IF
c-----------------------------------------------------------------------
c     If missing value codes are found in the series, replace values of
c     the original series with the missing value adjusted series.
c-----------------------------------------------------------------------
      IF(Missng.and.Ldestm)THEN
       DO i=Pos1ob,Posfob
        IF(.not.dpeq(Series(i),Orixmv(i)))THEN
         Series(i)=Orixmv(i)
         Orig(i)=Orixmv(i)
         Stoap(i)=Orixmv(i)
         Stopp(i)=Orixmv(i)
         IF(Nuspad.gt.0)THEN
          i2=Frstap+Lsp-1+(i-Pos1ob)
          IF(Muladd.eq.1)THEN
           Stoap(i)=Stoap(i)-Usrpad(i2)
           Stopp(i)=Stopp(i)-Usrpad(i2)
          ELSE
           Stoap(i)=Stoap(i)/Usrpad(i2)
           Stopp(i)=Stopp(i)/Usrpad(i2)
          END IF
         END IF
         IF(Nustad.gt.0)THEN
          i2=Frstat+Lsp-1+(i-Pos1ob)
          IF(Muladd.eq.1)THEN
           Stoap(i)=Stoap(i)-Usrtad(i2)
          ELSE
           Stoap(i)=Stoap(i)/Usrtad(i2)
          END IF
         END IF
        END IF
       END DO
c-----------------------------------------------------------------------
c     Print and/or save missing value adjusted series
c-----------------------------------------------------------------------
       IF(Prttab(LSRSMV))THEN
        IF(Ny.eq.12.or.Ny.eq.4)THEN
         CALL table(Series,Pos1ob,Posfob,1,1,2,dvec,LSRSMV)
        ELSE
         IF(Laccss)CALL insacd(Mt1,'series.mv.prttbl',T)
         CALL prttbl(Begspn,Sp,Series(Pos1ob),Posfob-Pos1ob+1,'Data',
     &               Kdec)
         IF(Laccss)CALL insacd(Mt1,'series.mv.prttbl',F)
        END IF
       END IF
       IF(.not.Lfatal.and.Savtab(LSRSMV))
     &    CALL punch(Series,Pos1ob,Posfob,LSRSMV,F,F)
       IF(.not.Lfatal.and.Lgraf)
     &    CALL punch(Series,Pos1ob,Posfob,LSRSMV,Lgraf,F)
       IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Delete missing value regressors
c-----------------------------------------------------------------------
       i=Nb
       DO WHILE (i.ge.1)
        IF(Rgvrtp(i).eq.PRGTMV)THEN
         CALL dlrgef(i,Nrxy,1)
         IF(Lfatal)RETURN
        END IF
        i=i-1
       END DO
      END IF
c-----------------------------------------------------------------------
c     Reset model parameters for sliding spans, revisions history
c-----------------------------------------------------------------------
      CALL ssprep(T,F,F)
c-----------------------------------------------------------------------
      IF(.not.gudrun)CALL copy(Orig,PLEN,1,Orig2)
      IF(Nfcst.gt.0)THEN
       DO i=Posfob+1,Posffc
        Orig2(i)=untfct(i-Posfob)
       END DO
      END IF
      IF(Nbcst.gt.0)THEN
       DO i=Pos1bk,Pos1ob-1
        Orig2(i)=untbct(i-Pos1bk+1)
       END DO
      END IF
c-----------------------------------------------------------------------
      IF(ldiag)THEN
       IF(Nb.gt.0)THEN
        CALL svfnrg('finalreg',Ngrp,Grpttl,Grpptr,Ngrptl)
       ELSE
        WRITE(Nform,1190)'nfinalreg:  ',1
        WRITE(Nform,1060)'finalreg01:',' none'
       END IF
      END IF
c-----------------------------------------------------------------------
 1000 FORMAT(a,i2,a2,1x,a,',',i4,' to ',i2,a2,1x,a,',',i4)
 1001 FORMAT(a,i4,' to ',i4)
 1010 FORMAT(a,f6.3,1x,a)
 1020 FORMAT(a,f10.6)
 1021 FORMAT(a,e12.6)
 1030 FORMAT(/,' MODEL IDENTIFICATION (Using regression residuals)')
 1040 FORMAT(/,' MODEL IDENTIFICATION')
 1050 FORMAT('arimamdl: ',a)
 1060 FORMAT(a:,a)
 1061 FORMAT(a,i6)
 1070 FORMAT(5x,'Default model used : ',a,' (no model selected)',/)
 1080 FORMAT(5x,'Automatic model chosen : ',a,/)
 1090 FORMAT(/,' MODEL DEFINITION')
 1100 FORMAT(//,' MODEL ESTIMATION/EVALUATION')
 1110 FORMAT(//,' DIAGNOSTIC CHECKING')
 1160 FORMAT(2x,'Number of forecasts/backcasts set to zero because ',
     &          'forecast error for the',/,
     &       2x,' model identified, ',F10.3,', is greater than ',f10.3,
     &          '.')
 1180 FORMAT(/,' Normality Statistics for regARIMA Model Residuals:')
 1190 FORMAT(a,i2)
 1200 FORMAT(a,f12.4)
 1210 FORMAT(' Average Absolute Percentage Error : ',a)
 1220 FORMAT('    AAPE(Last year)   : ',f16.2,/,
     &       '    AAPE(Last-1 year) : ',f16.2,/,
     &       '    AAPE(Last-2 year) : ',f16.2,/,
     &       '    AAPE(Last 3 years): ',f16.2)
 9000 FORMAT(a,e15.8)
c-----------------------------------------------------------------------
      RETURN
      END
