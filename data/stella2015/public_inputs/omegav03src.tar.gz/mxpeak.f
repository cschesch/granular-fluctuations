C     Last change:  BCM  24 Aug 2001 11:38 am
      SUBROUTINE mxpeak(Sxx,Pkidx,Domfqt,Domfqs,Maxsxx,Nform,Spclab)
      IMPLICIT NONE
c-----------------------------------------------------------------------
      INCLUDE 'notset.prm'
c-----------------------------------------------------------------------
      CHARACTER labvec*(2),domfrq*(2),Spclab*(*)
      DOUBLE PRECISION Sxx,Maxsxx
      INTEGER i,i2,Nform,Pkidx,Domfqt,Domfqs,frq1,pkvec,pkptr
      DIMENSION Sxx(61),pkvec(12),pkptr(0:4),labvec(12)
c-----------------------------------------------------------------------
      LOGICAL dpeq
      EXTERNAL dpeq
c-----------------------------------------------------------------------
      DATA pkvec/43,53,6,12,11,21,31,41,51,61,31,61/
      DATA labvec/'t1','t2','t1','t2','s1','s2','s3','s4','s5','s6',
     &            's1','s2'/
      DATA pkptr/1,3,5,11,13/
c-----------------------------------------------------------------------
      domfrq = 'no'
      i2 = Pkidx
      IF(Domfqt.eq.NOTSET.and.Domfqs.eq.NOTSET)THEN
       WRITE(Nform,1010)Spclab,domfrq
       RETURN
      ELSE IF(Domfqt.eq.NOTSET)THEN
       frq1=Domfqs
       i2=i2+2
      ELSE IF(Domfqs.eq.NOTSET)THEN
       frq1=Domfqt
      ELSE IF(Sxx(Domfqt).gt.Sxx(Domfqs))THEN
       frq1=Domfqt
      ELSE
       frq1=Domfqs
       i2=i2+2
      END IF
      IF(dpeq(Maxsxx,Sxx(frq1)))THEN
       i=pkptr(i2-1)
       DO WHILE (i.le.(pkptr(i2)-1))
        IF(pkvec(i).eq.frq1)THEN
         domfrq=labvec(i)
         i=pkptr(i2)
        ELSE
         i=i+1
        END IF
       END DO
      END IF
      WRITE(Nform,1010)Spclab,domfrq
c-----------------------------------------------------------------------
 1010 FORMAT(a,'.dom: ',a)
      RETURN
      END
