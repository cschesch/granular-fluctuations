C     Last change:  BCM  3 Feb 2003 7:01 am
      DOUBLE PRECISION FUNCTION setcvl(Nspobs,Cvalfa)
      IMPLICIT NONE
c     ------------------------------------------------------------------
      INCLUDE 'notset.prm'
      INCLUDE 'units.cmn'
      INCLUDE 'stdio.i'
c     ------------------------------------------------------------------
      LOGICAL F,T
      DOUBLE PRECISION PI,ONE,TWO,MINPT5
      PARAMETER(F=.false.,T=.true.,PI=3.141592654D0,ONE=1D0,TWO=2D0,
     &          MINPT5=-0.5D0)
c     ------------------------------------------------------------------
      INTEGER Nspobs
      DOUBLE PRECISION dnobs,acv,bcv,xcv,Cvalfa,pmod
c----------------------------------------------------------------------
c     Compute critical value based on length of series (see Ljung)
c----------------------------------------------------------------------
      IF(Nspobs.eq.1)THEN
       CALL writln('ERROR: Default outlier critical value cannot be deri
     &ved for an outlier',STDERR,Mt2,T)
       CALL writln('       span of one observation.  Either use the crit
     &ical argument to',STDERR,Mt2,F)
       CALL writln('       set the outlier critical value, or change the
     &setting of the',STDERR,Mt2,T)
       CALL writln('       defaultcritical argument.',STDERR,Mt2,T)
       Cvalfa=DNOTST
       setcvl=DNOTST
       RETURN
      END IF
c----------------------------------------------------------------------
      pmod=TWO-SQRT(ONE+Cvalfa)
      dnobs=DBLE(Nspobs)
      acv=SQRT(TWO * LOG(dnobs))
      bcv=acv-(LOG(LOG(dnobs))+LOG(TWO*TWO*PI))/(TWO*acv)
      xcv=-LOG(MINPT5 * LOG(pmod))
      setcvl=(xcv/acv) + bcv
c----------------------------------------------------------------------
      RETURN
      END
