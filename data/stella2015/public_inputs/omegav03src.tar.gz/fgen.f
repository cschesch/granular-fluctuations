C     Last change:  BCM  7 Nov 2006 3:47 pm
**==fgen.f    processed by SPAG 4.03F  at 11:18 on 14 Sep 1994
      SUBROUTINE fgen(Nw,Kfmt,Ptrf2,Ptrf3)
      IMPLICIT NONE
c-----------------------------------------------------------------------
C --- THIS SUBROUTINE GENERATES THE F2 AND F3 TABLES.
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'title.cmn'
      INCLUDE 'x11opt.cmn'
      INCLUDE 'mq3.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
c-----------------------------------------------------------------------
      LOGICAL T,F
      PARAMETER(T=.true.,F=.false.)
c-----------------------------------------------------------------------
      CHARACTER mqf2*(7),tbllbl*3
      INTEGER Kfmt,khcfm,Nw,Ptrf2,Ptrf3
c-----------------------------------------------------------------------
      INTEGER nblank
      EXTERNAL nblank
c-----------------------------------------------------------------------
      IF(Prttab(Ptrf2))THEN
       IF(Ny.eq.4)THEN
        mqf2=Moqu
       ELSE
        mqf2='  month'
       END IF
       khcfm=1
       IF(Kfmt.gt.0)khcfm=2
       IF(Lpage)THEN
        WRITE(Nw,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
       IF(Laccss)THEN
        CALL insmrk(Mt1,Ptrf2,T,F)
        tbllbl=' F2'
       ELSE
        tbllbl='F 2'
       END IF
       WRITE(Nw,1010)tbllbl
 1010  FORMAT(//,1x,a,'. Summary Measures')
       IF(Lwdprt)THEN
        CALL prtf2w(Nw,mqf2,khcfm,tbllbl)
       ELSE
        CALL prtf2(Nw,mqf2,khcfm,tbllbl)
       END IF
       IF(Laccss)CALL insmrk(Mt1,Ptrf2,F,F)
      END IF
      IF(Prttab(Ptrf3))THEN
       IF(Lpage)THEN
        WRITE(Nw,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
       IF(Laccss)THEN
        CALL insmrk(Mt1,Ptrf3,T,F)
        WRITE(Nw,1020)' F3'
       ELSE
        WRITE(Nw,1020)'F 3'
       END IF
 1020  FORMAT(//,1x,a,'. Monitoring and Quality Assessment Statistics')
       CALL f3gen(Nw,Ny,Kfulsm,Lwdprt,Lcmpaq)
       IF(Laccss)CALL insmrk(Mt1,Ptrf3,F,F)
      END IF
      RETURN
      END
