C     Last change:  BCM  11 Mar 2009 4:31 pm
      SUBROUTINE amdid(Irar,Irdf,Irma,Isar,Isdf,Isma,Trnsrs,Frstry,
     &                 Nefobs,A,Na,Lmu,Locok)
      IMPLICIT NONE
c     ------------------------------------------------------------------
c     Select ARIMA model via procedure in Gomez and Maravall (1998)
c     ------------------------------------------------------------------
      DOUBLE PRECISION THREE2,THREE3,PTOL
      INTEGER NMOD
      LOGICAL T,F
      PARAMETER(T=.true.,F=.FALSE.,THREE2=0.03D0,THREE3=0.003D0,NMOD=5,
     &          PTOL=1.0D-3)
c     ------------------------------------------------------------------
      INCLUDE 'stdio.i'
      INCLUDE 'prior.prm'
      INCLUDE 'prior.cmn'
      INCLUDE 'notset.prm'
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'arima.cmn'
      INCLUDE 'extend.cmn'
      INCLUDE 'title.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'error.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
      INCLUDE 'mdltbl.i'
      INCLUDE 'svllog.prm'
      INCLUDE 'svllog.cmn'
      INCLUDE 'mdlsvl.i'
c     ------------------------------------------------------------------
      CHARACTER tmpmdl*(132)
      DOUBLE PRECISION A,bstbic,tolbak,txy,Trnsrs,vc11,vc2,vc22,bic1,
     &                 bmax,dbic,xmu,nltbak
      LOGICAL inptok,lxar,lxma,Lmu,Locok
      INTEGER bstrar,bstrdf,bstrma,bstsar,bstsdf,bstsma,frstry,i,
     &        Isar,Isma,Irar,Irma,Isdf,Irdf,id,nelta,psar,Na,nefobs,
     &        ichk,ntmp,ir1,is1,irr1,iss1,ir2,is2,irr2,iss2,icon,ngood
      DIMENSION A(PLEN+2*PORDER),bstbic(5),bstrar(5),bstrdf(5),
     &          bstrma(5),bstsar(5),bstsdf(5),bstsma(5),txy(PLEN),
     &          Trnsrs(PLEN)
c     ------------------------------------------------------------------
      LOGICAL mdlmch,dpeq
      EXTERNAL mdlmch,dpeq
c     ------------------------------------------------------------------
c     Set up initial values
c     ------------------------------------------------------------------
      Irar=3
      Irma=0
      id=Diffam(1)+Diffam(2)
      CALL setdp(DNOTST,5,bstbic)
      CALL setint(0,5,bstrar)
      CALL setint(0,5,bstrdf)
      CALL setint(0,5,bstrma)
      CALL setint(0,5,bstsar)
      CALL setint(0,5,bstsdf)
      CALL setint(0,5,bstsma)
c     ------------------------------------------------------------------
c     Loosen tolerance for Exact likelihood model estimation
c     ------------------------------------------------------------------
      nltbak=NOTSET
      IF(Tol.lt.PTOL)THEN
       nltbak=Nltol
       tolbak=Tol
       Tol=PTOL
       Nltol=PTOL
       Nltol0=100D0*Tol
      END IF
c     ------------------------------------------------------------------
      lxar=Lextar
      lxma=Lextma
      Lextar=T
      Lextma=T
      Lar=Lextar.and.Mxarlg.gt.0
      Lma=Lextma.and.Mxmalg.gt.0
      IF(Lextar)THEN
       Nintvl=Mxdflg
       Nextvl=Mxarlg+Mxmalg
      ELSE
       Nintvl=Mxdflg+Mxarlg
       Nextvl=0
       IF(Lextma)Nextvl=Mxmalg
      END IF
c     ------------------------------------------------------------------
c       Difference data, if necessary
c     ------------------------------------------------------------------
      nelta=Nspobs
      CALL copy(Trnsrs,nelta,1,txy)
      IF(id.gt.0)
     &   CALL arflt(nelta,Arimap,Arimal,Opr,Mdl(DIFF-1),Mdl(DIFF)-1,txy,
     &              nelta)
      IF(Lmu)CALL smeadl(txy,1,nelta,nelta,xmu)
c-----------------------------------------------------------------------
      CALL regvar(Trnsrs,nspobs,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
     &            Priadj,Reglom,Nrxy,Begxy,frstry,T,F)
c-----------------------------------------------------------------------
      IF(Prttab(LAUMDL))THEN
       IF(Laccss)CALL insacd(Mt1,'automdl.amd.hdr',T)
       WRITE(Mt1,1010)
       IF(Laccss)CALL insacd(Mt1,'automdl.amd.hdr',F)
      END IF
c-----------------------------------------------------------------------
c     Determine the order of the seasonal parameters by fitting ARMA
c     models with a regular AR(3)
c-----------------------------------------------------------------------
      IF(Sp.eq.1)THEN
       Isar=0
       Isma=0
       psar=0
      ELSE
       ngood=0
       DO Isar=0,Maxord(2)
        DO Isma=0,Maxord(2)
         IF(Lmixmd.or.(Isar.eq.0.or.Isma.eq.0))THEN
          CALL amdid2(3,Irdf,0,Isar,Isdf,Isma,txy,nelta,Lmu,inptok)
          IF(Lfatal)RETURN
          IF(inptok)THEN
           CALL bestmd(3,Irdf,0,Isar,Isdf,Isma,bstrar,bstrdf,bstrma,
     &                 bstsar,bstsdf,bstsma,bstbic)
           ngood=ngood+1
          END IF
         END IF
        END DO
       END DO
       IF(ngood.gt.0)THEN
        Isar=bstsar(1)
        Isma=bstsma(1)
       ELSE
        WRITE(STDERR,1000)'seasonal'
        IF(Laccss)CALL insacd(Mt1,'zero',T)
        WRITE(Mt1,1000)'seasonal'
        IF(Laccss)CALL insacd(Mt1,'zero',F)
        WRITE(Mt2,1000)'seasonal'
        CALL abend
        RETURN
       END IF
       IF(Maxord(1).lt.3)THEN
        CALL setdp(DNOTST,5,bstbic)
        CALL setint(0,5,bstrar)
        CALL setint(0,5,bstrdf)
        CALL setint(0,5,bstrma)
        CALL setint(0,5,bstsar)
        CALL setint(0,5,bstsdf)
        CALL setint(0,5,bstsma)
       END IF
      END IF
c-----------------------------------------------------------------------
c     Using seasonal orders from before, identify regular ARMA orders.
c-----------------------------------------------------------------------
      ngood=0
      DO Irar=0,Maxord(1)
       DO Irma=0,Maxord(1)
        IF((Lmixmd.or.(Irar.eq.0.or.Irma.eq.0)).and.
     &    (.not.mdlmch(Irar,Irdf,Irma,Isar,Isdf,Isma,bstrar,bstrdf,
     &                 bstrma,bstsar,bstsdf,bstsma,bstbic)))THEN
         CALL amdid2(Irar,Irdf,Irma,Isar,Isdf,Isma,txy,nelta,Lmu,inptok)
         IF(Lfatal)RETURN
         IF(inptok)THEN
          CALL bestmd(Irar,Irdf,Irma,Isar,Isdf,Isma,bstrar,bstrdf,
     &                bstrma,bstsar,bstsdf,bstsma,bstbic)
          ngood=ngood+1
         END IF
        END IF
       END DO
      END DO
      IF(ngood.gt.0)THEN
       Irar=bstrar(1)
       Irma=bstrma(1)
      ELSE
       WRITE(STDERR,1000)'nonseasonal'
       IF(Laccss)CALL insacd(Mt1,'zero',T)
       WRITE(Mt1,1000)'nonseasonal'
       IF(Laccss)CALL insacd(Mt1,'zero',F)
       WRITE(Mt2,1000)'nonseasonal'
       CALL abend
       RETURN
      END IF
c-----------------------------------------------------------------------
c     If no MA or AR orders are identified, use the next model to get
c     regular AR & MA orders for the next stage.
c-----------------------------------------------------------------------
      IF((Isar+Isma+Irar+Irma).eq.0)THEN
       Irar=bstrar(2)
       Irma=bstrma(2)
      END IF
c-----------------------------------------------------------------------
c     Using regular orders from before, re-identify seasonal ARMA
c     orders.
c-----------------------------------------------------------------------
      psar=Maxord(2)
      IF(psar.lt.2.and.Isdf.eq.1)psar=0
      IF(Sp.gt.1)THEN
       ngood=0
       DO Isar=0,psar
        DO Isma=0,Maxord(2)
         IF((Lmixmd.or.(Isar.eq.0.or.Isma.eq.0)).and.
     &    (.not.mdlmch(Irar,Irdf,Irma,Isar,Isdf,Isma,bstrar,bstrdf,
     &             bstrma,bstsar,bstsdf,bstsma,bstbic)))THEN
          CALL amdid2(Irar,Irdf,Irma,Isar,Isdf,Isma,txy,nelta,Lmu,
     &                inptok)
          IF(Lfatal)RETURN
          IF(inptok)THEN
           CALL bestmd(Irar,Irdf,Irma,Isar,Isdf,Isma,bstrar,bstrdf,
     &                 bstrma,bstsar,bstsdf,bstsma,bstbic)
           ngood=ngood+1
          END IF
         END IF
        END DO
       END DO
       IF(ngood.gt.0)THEN
        Isar=bstsar(1)
        Isma=bstsma(1)
c       ELSE
c        WRITE(STDERR,1000)'seasonal'
c        WRITE(Mt1,1000)'seasonal'
c        WRITE(Mt2,1000)'seasonal'
c        CALL abend
c        RETURN
       END IF
      END IF
c-----------------------------------------------------------------------
c     Check for closeness of BIC, model balance.
c-----------------------------------------------------------------------
      bic1=bstbic(1)
      Irar=bstrar(1)
      Isar=bstsar(1)
      Irma=bstrma(1)
      Isma=bstsma(1)
      icon=1
      ir1=bstrar(1)+bstrma(1)
      is1=bstsar(1)+bstsma(1)
      irr1=IABS(bstrar(1)+Irdf-bstrma(1))
      iss1=IABS(bstsar(1)+Isdf-bstsma(1))
      bmax=DABS(bic1-bstbic(NMOD))
      IF (bmax.LT.THREE3) THEN
       bmax=.0625D0
      ELSE IF (bmax.LT.THREE2) THEN
       bmax=.25D0
      ELSE
       bmax=1.D0
      END IF
      vc11=.01D0*bmax
      vc2=.0025D0*bmax
      vc22=.0075D0*bmax
c-----------------------------------------------------------------------
c     Begin looping through models
c-----------------------------------------------------------------------
      DO i=2,NMOD
       ir2=bstrar(i)+bstrma(i)
       is2=bstsar(i)+bstsma(i)
       irr2=IABS(bstrar(i)+Irdf-bstrma(i))
       iss2=IABS(bstsar(i)+Isdf-bstsma(i))
       dbic=DABS(bstbic(i)-bstbic(icon))
c-----------------------------------------------------------------------
c     check for more parsimonious, more balanced models
c-----------------------------------------------------------------------
c       IF (((irr2.LT.irr1.OR.iss2.LT.iss1).AND.
c     &       ir1.EQ.ir2.AND.is1.EQ.is2.AND.dbic.LE.vc11.and.Lbalmd)
c     & .OR.(irr2.LT.irr1.AND.ir2.LE.ir1.AND.is2.EQ.is1.AND.
c     &      bstrar(i).GT.0.AND.bstrma(i).GT.0.AND.dbic.LE.vc2
c     &      .and.Lbalmd)
c     & .OR.(((irr2.EQ.0.AND.irr2.LT.irr1.AND.Irdf.GT.0).OR.
c     &       (iss2.EQ.0.AND.iss2.LT.iss1.AND.Isdf.GT.0)).AND.
c     &        ir1.EQ.ir2.AND.is1.EQ.is2.AND.dbic.LE.vc11.and.Lbalmd)
c     & .OR.(irr2.EQ.0.AND.iss2.EQ.0.AND.dbic.LT.vc2.and.Lbalmd)
c     & .OR.(ir2.GT.ir1.AND.irr2.EQ.0.AND.is2.EQ.is1.AND.dbic.LT.vc2
c     &      .and.Lbalmd)
c     & .OR.(is2.GT.is1.AND.iss2.EQ.0.AND.ir2.EQ.ir1.AND.dbic.LT.vc2
c     &      .and.Lbalmd)
c     & .OR.(is2.LT.is1.AND.is2.GT.0.AND.ir2.EQ.ir1.AND.iss2.EQ.0.AND.
c     &      dbic.LE.vc2.and.Lbalmd)
c     & .OR.(i.EQ.2.AND.ir1.EQ.0.AND.ir2.EQ.1.AND.is2.EQ.is1.AND.
c     &      dbic.LT.vc2)
c     & .OR.(ir2.LT.ir1.AND.ir2.GT.0.AND.is2.EQ.is1.AND.dbic.LT.vc2)
c     & .OR.(is2.LT.is1.AND.is2.GT.0.AND.ir2.EQ.ir1.AND.dbic.LT.vc2)
c     & .OR.(bstrar(i).LT.Irar.AND.bstrma(i).EQ.Irma.AND.ir2.GT.0
c     &      .AND.is2.EQ.is1.AND.dbic.LT.vc22))THEN
       ichk=0
       IF ((irr2.LT.irr1.OR.iss2.LT.iss1).AND.
     &       ir1.EQ.ir2.AND.is1.EQ.is2.AND.dbic.LE.vc11.and.Lbalmd)THEN
        ichk=1
       ELSE IF (irr2.LT.irr1.AND.ir2.LE.ir1.AND.is2.EQ.is1.AND.
     &      bstrar(i).GT.0.AND.bstrma(i).GT.0.AND.dbic.LE.vc2
     &      .and.Lbalmd)THEN
        ichk=2
       ELSE IF (((irr2.EQ.0.AND.irr2.LT.irr1.AND.Irdf.GT.0).OR.
     &       (iss2.EQ.0.AND.iss2.LT.iss1.AND.Isdf.GT.0)).AND.
     &        ir1.EQ.ir2.AND.is1.EQ.is2.AND.dbic.LE.vc11.and.Lbalmd)
     & THEN  
        ichk=3
       ELSE IF (irr2.EQ.0.AND.iss2.EQ.0.AND.dbic.LT.vc2.and.Lbalmd)THEN
        ichk=4
       ELSE IF (ir2.GT.ir1.AND.irr2.EQ.0.AND.is2.EQ.is1.AND.dbic.LT.vc2
     &      .and.Lbalmd)THEN
        ichk=5
       ELSE IF (is2.GT.is1.AND.iss2.EQ.0.AND.ir2.EQ.ir1.AND.dbic.LT.vc2
     &      .and.Lbalmd)THEN
        ichk=6
       ELSE IF(is2.LT.is1.AND.is2.GT.0.AND.ir2.EQ.ir1.AND.iss2.EQ.0.AND.
     &      dbic.LE.vc2.and.Lbalmd)THEN
        ichk=7
       ELSE IF (i.EQ.2.AND.ir1.EQ.0.AND.ir2.EQ.1.AND.is2.EQ.is1.AND.
     &      dbic.LT.vc2)THEN
        ichk=8
       ELSE IF(ir2.LT.ir1.AND.ir2.GT.0.AND.is2.EQ.is1.AND.dbic.LT.vc2)
     &  THEN
        ichk=9
       ELSE IF(is2.LT.is1.AND.is2.GT.0.AND.ir2.EQ.ir1.AND.dbic.LT.vc2)
     &  THEN
        ichk=10
       ELSE IF(bstrar(i).LT.Irar.AND.bstrma(i).EQ.Irma.AND.ir2.GT.0
     &      .AND.is2.EQ.is1.AND.dbic.LT.vc22)THEN
        ichk=11
       END IF
       IF(ichk.gt.0)THEN
        IF(Laccss)CALL insacd(Mt1,'zero',T)
c        WRITE(Mt1,2000)i,ichk
c 2000   FORMAT(' ichk (best model vrs. model ',i1,') = ',i3)
        WRITE(Mt1,1060)i,icon
        IF(Laccss)CALL insacd(Mt1,'zero',F)
c-----------------------------------------------------------------------
c     redo limits for bic with this model
c-----------------------------------------------------------------------
        vc11=vc11-DABS(bstbic(1)-bstbic(i))
        vc2=vc2-DABS(bstbic(1)-bstbic(i))
        vc22=vc22-DABS(bstbic(1)-bstbic(i))
c-----------------------------------------------------------------------
        ir1=ir2
        is1=is2
        irr1=irr2
        iss1=iss2
        icon=i
        bic1=bstbic(i)
        Irar=bstrar(i)
        Isar=bstsar(i)
        Irma=bstrma(i)
        Isma=bstsma(i)
c-----------------------------------------------------------------------
       END IF
      END DO
c-----------------------------------------------------------------------
c	Check to see if a model with no ARMA parameters is specified
c-----------------------------------------------------------------------
      IF(((Isar+Isma+Irar+Irma).eq.0).and.icon.lt.NMOD)THEN
       Irar=bstrar(icon+1)
       Irma=bstrma(icon+1)
       Isar=bstsar(icon+1)
       Isma=bstsma(icon+1)
      END IF
c-----------------------------------------------------------------------
      Lextar=lxar
      Lextma=lxma
      IF(nltbak.ne.NOTSET)THEN
       Tol=tolbak
       Nltol=nltbak
       Nltol0=Tol*100D0
      END IF
c-----------------------------------------------------------------------
      CALL mdlint()
      CALL mdlset(Irar,Irdf,Irma,Isar,Isdf,Isma,Locok)
      IF(.not.Lfatal)
     &   CALL rgarma(Lestim,Mxiter,Mxnlit,F,A,Na,nefobs,Lautom)
      IF(.not.Lautom)CALL abend()
      IF(Lfatal)RETURN
c-----------------------------------------------------------------------
      IF(.not.Convrg)THEN
       IF(Laccss)CALL insacd(Mt1,'zero',T)
       WRITE(Mt1,1070)Tol
       WRITE(Mt2,1070)Tol
       WRITE(Mt1,1080)MDLSEC,PRGNAM,DOCNAM
       WRITE(Mt2,1080)MDLSEC,PRGNAM,DOCNAM
       IF(Laccss)CALL insacd(Mt1,'zero',F)
       CALL abend()
       RETURN
      END IF
c-----------------------------------------------------------------------
      Bstdsn=Mdldsn
      Nbstds=Nmddcr
      IF(Prttab(LAUB5M).or.Svltab(LSLB5M))THEN
       IF(Laccss)THEN
        IF(Prttab(LAUB5M))CALL insmrk(Mt1,LAUB5M,T,F)
        IF(Svltab(LSLB5M))CALL insmrk(Ng,LSLB5M,T,T)
       END IF
       IF(Prttab(LAUB5M))WRITE(Mt1,1040)
       IF(Svltab(LSLB5M))WRITE(Ng,1040)
       DO i=1,NMOD
        CALL mkmdsn(bstrar(i),bstrdf(i),bstrma(i),bstsar(i),bstsdf(i),
     &              bstsma(i),tmpmdl,ntmp)
        IF(Lfatal)RETURN
        IF(Prttab(LAUB5M))WRITE(Mt1,1050)i,tmpmdl(1:ntmp),bstbic(i)
        IF(Svltab(LSLB5M))WRITE(Ng,1050)i,tmpmdl(1:ntmp),bstbic(i)
       END DO
       IF(Laccss)THEN
        IF(Prttab(LAUB5M))CALL insmrk(Mt1,LAUB5M,F,F)
        IF(Svltab(LSLB5M))CALL insmrk(Ng,LSLB5M,F,T)
       END IF
      END IF
      IF(Prttab(LAUMCH))THEN
       IF(Laccss)CALL insmrk(Mt1,LAUMCH,T,F)
       WRITE(Mt1,1030)Bstdsn(1:Nbstds)
       IF(Laccss)CALL insmrk(Mt1,LAUMCH,F,F)
      END IF
c-----------------------------------------------------------------------
      RETURN
c-----------------------------------------------------------------------
 1000 FORMAT(/,' ERROR: Cannot make a choice of ',a,' ARMA order due',
     &         ' to',
     &       /,'        model estimation errors within the automatic ',
     &         'model',/,'        selection procedure.')
 1010 FORMAT(//,'  ARIMA Estimates and Likelihood Values for ARMA ',
     &         'Order Identification',/)
c 1020 FORMAT(/,'  Estimation error found during unit root testing ',
c     &       /,'  procedure while fitting inital regARIMA model to the',
c     &         ' series.')
 1030 FORMAT(/,'  Automatic model choice : ',a)
 1040 FORMAT(//,'  Best Five ARIMA Models',/)
 1050 FORMAT('     Model # ',i2,' : ',a,t40,'(BIC = ',f10.3,')')
 1060 FORMAT('  Model ',i1,' preferred over Model ',i1,/)
 1070 FORMAT(/,' ERROR: Estimation failed to converge for ',
     &         'automatically identified model',
     &       /,'        when convergence tolerence reset to ',e12.6)
 1080 FORMAT(/,'        Rerun program trying one of the following:',/,
     &         10x,'(1) Allow more iterations (set a larger value of ',
     &         'maxiter).',
     &       /,10x,'(2) Try a different model or different modeling ',
     &         'options.',/,
     &       /,1x,'See ',a,' of the ',a,' ',a,' for more discussion.')
c-----------------------------------------------------------------------
      END
