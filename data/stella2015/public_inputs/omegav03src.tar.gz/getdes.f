C     Last change:  BCM  5 Sep 2006 11:54 am
      SUBROUTINE getdes(Itbl,Fildes,Ndescr,Label,Laccss)
      IMPLICIT NONE
c     ------------------------------------------------------------------
c     Subroutine to extract the description for table Itbl from the data
c     dictionaries into the character scalar Fildes
c     Since X-12-ARIMA has so many tables, the dictionary for the
c     table descriptions had to be divided into many parts so the length
c     of all of the data dictionaries was less than 2000 characters
c     ------------------------------------------------------------------
c     Written by BCM August 22 2006
c     ------------------------------------------------------------------
      LOGICAL F
      PARAMETER(F=.false.)
c     ------------------------------------------------------------------
      INCLUDE 'tbltitle.prm'
      INCLUDE 'dessrs.prm'
      INCLUDE 'desmdl.prm'
      INCLUDE 'desx11.prm'
      INCLUDE 'desfsa.prm'
      INCLUDE 'desdgn.prm'
      INCLUDE 'descmp.prm'
      INCLUDE 'descm2.prm'
      INCLUDE 'desadj.prm'
      INCLUDE 'desxrg.prm'
c     ------------------------------------------------------------------
      CHARACTER Fildes*(PTTLEN)
      INTEGER Itbl,Ndescr
      LOGICAL Label,Laccss
c     ------------------------------------------------------------------
      INCLUDE 'dessrs.var'
      INCLUDE 'desmdl.var'
      INCLUDE 'desx11.var'
      INCLUDE 'desfsa.var'
      INCLUDE 'desdgn.var'
      INCLUDE 'descmp.var'
      INCLUDE 'descm2.var'
      INCLUDE 'desadj.var'
      INCLUDE 'desxrg.var'
c     ------------------------------------------------------------------
      IF(Itbl.le.PDSR)THEN
       CALL makttl(DSRDIC,dsrptr,PDSR,Itbl,0,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM1)THEN
       CALL makttl(DSMDIC,dsmptr,PDSM,Itbl,PDSR,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM2)THEN
       CALL makttl(DSXDIC,dsxptr,PDSX,Itbl,PDSUM1,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM3)THEN
       CALL makttl(DSSDIC,dssptr,PDSS,Itbl,PDSUM2,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM4)THEN                
       CALL makttl(DSADIC,dsaptr,PDSA,Itbl,PDSUM3,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM5)THEN                
       CALL makttl(DSIDIC,dsiptr,PDSI,Itbl,PDSUM4,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM6)THEN                
       CALL makttl(DSDDIC,dsdptr,PDSD,Itbl,PDSUM5,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE IF(Itbl.le.PDSUM7)THEN                
       CALL makttl(DSCDIC,dscptr,PDSC,Itbl,PDSUM6,Fildes,Ndescr,Label,F,
     &             Laccss)
      ELSE
       CALL makttl(DC2DIC,dc2ptr,PDC2,Itbl,PDSUM7,Fildes,Ndescr,Label,F,
     &             Laccss)
      END IF
c     ------------------------------------------------------------------
      RETURN
      END
      
