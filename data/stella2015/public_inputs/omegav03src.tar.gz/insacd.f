C     Last change:  BCM  31 Aug 2006 3:14 pm
      SUBROUTINE insacd(Fh,Tbcode,Lbegin)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     THis subroutine inserts a character code (Tbcode) into the output
c     file that is used by the cnvOut2HTML utility to create an
c     accessible HTML file of the output or log file.
c     Author : BCM August 2006 
c-----------------------------------------------------------------------
      INTEGER Fh
      LOGICAL Lbegin
      CHARACTER*(*) Tbcode
c-----------------------------------------------------------------------
      IF(Lbegin)THEN
       WRITE(Fh,1010)':b.',Tbcode
      ELSE
       WRITE(Fh,1010)':e.',Tbcode
      END IF
 1010 FORMAT(a,a)
c-----------------------------------------------------------------------
      RETURN
      END
