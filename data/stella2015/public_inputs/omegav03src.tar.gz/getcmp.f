C     Last change:  BCM  10 Sep 2008 3:03 pm
      SUBROUTINE getcmp(Probs,Havesp,Sp,Y,Nobs,Start,Nspobs,Begspn,
     &                  Srsttl,Nttlcr,Srsnam,Nser,Itest,Bgspec,Kdec,
     &                  Begmdl,Endmdl,Spcdff,Spctyp,Svprec,Locok,Yr2000,
     &                  Spcsrs,Mxarsp,Spclim,Peakwd,Lindot,Spdfor,
     &                  Inptok)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Set options for final direct and indirect composite adjustment,
c including the number of observations, nobs, start date, start, and
c seasonal period, Sp.
c-----------------------------------------------------------------------
c     Variable typing and parameters initialization
c-----------------------------------------------------------------------
c    Add appendfcst and appendbcst arguments, october 2006, bcm
c-----------------------------------------------------------------------
      INCLUDE 'notset.prm'
      INCLUDE 'lex.i'
      INCLUDE 'tbllog.i'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
      INCLUDE 'svllog.i'
      INCLUDE 'stdio.i'
      INCLUDE 'error.cmn'
      INCLUDE 'units.cmn'
c-----------------------------------------------------------------------
      LOGICAL F,T
      INTEGER YR,MO
      DOUBLE PRECISION ZERO
      PARAMETER(F=.false.,T=.true.,YR=1,MO=2,ZERO=0D0)
c-----------------------------------------------------------------------
      CHARACTER Srsttl*(*),Srsnam*(64)
      LOGICAL argok,Locok,Inptok,Havesp,Yr2000,Spcdff,Lindot
      INTEGER Sp,nelt,Nobs,Nttlcr,Probs,Start,tmpptr,Itest,Bgspec,
     &        endspn,nspec,Kdec,Begspn,Begmdl,Endmdl,spnmdl,nobmdl,
     &        Nspobs,Nser,Spctyp,Svprec,Spcsrs,Mxarsp,ivec,Peakwd,Spdfor
      DOUBLE PRECISION Y,Spclim,dvec
      DIMENSION Start(2),tmpptr(0:1),Itest(5),Bgspec(2),endspn(2),
     &          Y(Probs),Begspn(2),Begmdl(2),Endmdl(2),spnmdl(2,2),
     &          ivec(1),dvec(1)
c-----------------------------------------------------------------------
      LOGICAL gtarg,chkcvr
      EXTERNAL chkcvr,gtarg
c-----------------------------------------------------------------------
      CHARACTER ARGDIC*171
      INTEGER arglog,argidx,argptr,PARG
      PARAMETER(PARG=19)
      DIMENSION argptr(0:PARG),arglog(2,PARG)
      PARAMETER(ARGDIC='nametitleprintsavespectrumstartdecimalsmodelspan
     &diffspectrumspectrumtypesaveprecisionsavelogyr2000spectrumseriesma
     &xspecarspectrumsigpeakwidthindoutlierappendfcstappendbcst')
c-----------------------------------------------------------------------
      CHARACTER YSNDIC*5
      INTEGER ysnptr,PYSN
      PARAMETER(PYSN=2)
      DIMENSION ysnptr(0:PYSN)
      PARAMETER(YSNDIC='yesno')
c     ------------------------------------------------------------------
      CHARACTER DFFDIC*10
      INTEGER dffptr,PDFF
      PARAMETER(PDFF=3)
      DIMENSION dffptr(0:PDFF)
      PARAMETER(DFFDIC='yesfirstno')
c     ------------------------------------------------------------------
      CHARACTER STPDIC*17
      INTEGER stpptr,PSTP
      PARAMETER(PSTP=2)
      DIMENSION stpptr(0:PSTP)
      PARAMETER(STPDIC='arspecperiodogram')
c-----------------------------------------------------------------------
c     series used in spectrum data dictionary
c-----------------------------------------------------------------------
      CHARACTER SPSDIC*57
      INTEGER spsptr,PSPS
      PARAMETER(PSPS=8)
      DIMENSION spsptr(0:PSPS)
      PARAMETER(SPSDIC='originaloutlieradjoriginaladjoriginalmodoriginal
     &a1a19b1e1')
c     ------------------------------------------------------------------
      DATA argptr / 1,5,10,15,19,32,40,49,61,73,86,93,99,113,122,133,
     &              142,152,162,172 /
      DATA ysnptr / 1,4,6 /
      DATA dffptr / 1,4,9,11 /
      DATA stpptr / 1,7,18 /
      DATA spsptr / 1,9,27,38,49,51,54,56,58 /
c-----------------------------------------------------------------------
c     Assume the input is OK and we don't have any of the arguments
c-----------------------------------------------------------------------
      Locok=T
      CALL setint(NOTSET,4,spnmdl)
      CALL setint(NOTSET,2*PARG,arglog)
c-----------------------------------------------------------------------
c     Argument get loop
c-----------------------------------------------------------------------
      DO WHILE (T)
       IF(gtarg(ARGDIC,argptr,PARG,argidx,arglog,Inptok))THEN
        IF(Lfatal)RETURN
        GO TO(10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,
     &        170,180,185),argidx
c-----------------------------------------------------------------------
c     Series name argument
c-----------------------------------------------------------------------
   10   CALL gtnmvc(LPAREN,T,1,Srsnam,tmpptr,nelt,argok,Locok)
        IF(Lfatal)RETURN
        IF(argok)CALL eltlen(1,tmpptr,nelt,Nser)
        GO TO 190
c-----------------------------------------------------------------------
c     Title argument
c-----------------------------------------------------------------------
   20   CALL getttl(LPAREN,T,1,Srsttl,tmpptr,nelt,argok,Locok)
        IF(Lfatal)RETURN
        IF(argok)CALL eltlen(1,tmpptr,nelt,Nttlcr)
        GO TO 190
c-----------------------------------------------------------------------
c     Print argument
c-----------------------------------------------------------------------
   30   CALL getprt(LSPCMP,NSPCMP,Locok)
        GO TO 190
c-----------------------------------------------------------------------
c     Save argument
c-----------------------------------------------------------------------
   40   CALL getsav(LSPCMP,NSPCMP,Locok)
        GO TO 190
c-----------------------------------------------------------------------
c     spectrumstart argument
c-----------------------------------------------------------------------
   50   CALL gtdtvc(Havesp,Sp,LPAREN,F,1,Bgspec,nelt,argok,Locok)
        IF(Lfatal)RETURN
        GO TO 190
c-----------------------------------------------------------------------
c     decimals argument
c-----------------------------------------------------------------------
   60   CALL getivc(LPAREN,T,1,ivec,nelt,argok,Locok)
        IF(Lfatal)RETURN
        IF(argok)THEN
         IF(ivec(1).lt.0.or.ivec(1).gt.5)THEN
          CALL inpter(PERROR,Errpos,
     &  'Number of output decimals must be between 0 and 5, inclusive.')
          Locok=F
         ELSE
          Kdec=ivec(1)
         END IF
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     Span for the model estimation.
c-----------------------------------------------------------------------
   70   CALL gtdtvc(Havesp,Sp,LPAREN,F,2,spnmdl,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(nelt.eq.1)THEN
         CALL inpter(PERROR,Errpos,'Need two dates for the model span or
     & use a comma as place holder.')
         Inptok=F
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     diffspectrum argument
c-----------------------------------------------------------------------
   80   CALL gtdcvc(LPAREN,T,1,DFFDIC,dffptr,PDFF,
     &              'Available options for difference are yes or no.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)THEN
         Spcdff=ivec(1).lt.3
         IF(ivec(1).eq.2)THEN
          Spdfor=1
         ELSE IF(ivec(1).eq.3)THEN
          Spdfor=0
         END IF
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     spectrumtype argument
c-----------------------------------------------------------------------
   90   CALL gtdcvc(LPAREN,T,1,STPDIC,stpptr,PSTP,
     &  'Available options for spectrumtype are periodogram or arspec.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)Spctyp=ivec(1)-1
        GO TO 190
c-----------------------------------------------------------------------
c     saveprecision argument
c-----------------------------------------------------------------------
  100   CALL getivc(LPAREN,T,1,ivec,nelt,argok,Locok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)THEN
         IF(ivec(1).le.0.and.ivec(1).gt.15)THEN
          CALL inpter(PERROR,Errpos,'Value of saveprecision must be grea
     &ter than zero and less than 15.')
          Inptok=F
         ELSE
          Svprec=ivec(1)
         END IF
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     Savelog argument
c-----------------------------------------------------------------------
  110   CALL getsvl(LSLCMP,NSLCMP,Locok)
        GO TO 190
c-----------------------------------------------------------------------
c     yr2000 argument
c-----------------------------------------------------------------------
  120   CALL gtdcvc(LPAREN,T,1,YSNDIC,ysnptr,PYSN,
     &              'Available options for yr2000 are yes or no.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)Yr2000=ivec(1).eq.1
        GO TO 190
c-----------------------------------------------------------------------
c     spectrumseries argument
c-----------------------------------------------------------------------
  130   CALL gtdcvc(LPAREN,T,1,SPSDIC,spsptr,PSPS,
     &          'Improper entry found for the spectrumseries argument.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(nelt.eq.0)THEN
         CALL writln('        Valid entries for spectrumseries are a1, a
     &19, b1, e1, original,',STDERR,Mt2,F)
         CALL writln('        outlieradjoriginal, adjoriginal, or modori
     &ginal.',STDERR,Mt2,F)
        ELSE IF(argok.and.nelt.gt.0)THEN
         Spcsrs=ivec(1)-1
         IF(Spcsrs.gt.3)Spcsrs=Spcsrs-4
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     maxspecar argument
c-----------------------------------------------------------------------
  140   CALL getivc(LPAREN,T,1,ivec,nelt,argok,locok)
        IF(Lfatal)RETURN
        IF(argok)THEN
         IF(ivec(1).lt.1.or.ivec(1).gt.30)THEN
          CALL inpter(PERROR,Errpos,
     &  'Max order for AR spectrum must be between 1 and 30, inclusive')
          locok=F
         ELSE
          Mxarsp=ivec(1)
         END IF
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     spectrumsig argument
c-----------------------------------------------------------------------
  150   CALL gtdpvc(LPAREN,T,1,dvec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok)THEN
         IF(dvec(1).gt.ZERO)THEN
          CALL inpter(PERROR,Errpos,
     &         'Visual signifcance criteria must be greater than zero.')
          locok=F
         ELSE
          Spclim=dvec(1)
         END IF
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     peakwidth argument
c-----------------------------------------------------------------------
  160   CALL getivc(LPAREN,T,1,ivec,nelt,argok,locok)
        IF(Lfatal)RETURN
        IF(argok)THEN
         IF(ivec(1).lt.1.or.ivec(1).gt.5)THEN
          CALL inpter(PERROR,Errpos,
     &        'Spectral peak width must be between 1 and 5, inclusive')
          locok=F
         ELSE
          Peakwd=ivec(1)
         END IF
        END IF
        GO TO 190
c-----------------------------------------------------------------------
c     indoutlier argument
c-----------------------------------------------------------------------
  170   CALL gtdcvc(LPAREN,T,1,YSNDIC,ysnptr,PYSN,
     &              'Available options for indoutlier are yes or no.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)Lindot=ivec(1).eq.1
        GO TO 190
c-----------------------------------------------------------------------
c     appendfcst argument
c-----------------------------------------------------------------------
  180   CALL gtdcvc(LPAREN,T,1,YSNDIC,ysnptr,PYSN,
     &       'Available options for appending forecasts are yes or no.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)Savfct=ivec(1).eq.1
        GO TO 190
c-----------------------------------------------------------------------
c     appendbcst argument
c-----------------------------------------------------------------------
  185   CALL gtdcvc(LPAREN,T,1,YSNDIC,ysnptr,PYSN,
     &       'Available options for appending backcasts are yes or no.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)Savbct=ivec(1).eq.1
        GO TO 190
       END IF
       IF(Lfatal)RETURN
c----------------------------------------------------------------------
c     Set starting date, seasonal period
c----------------------------------------------------------------------
       Start(YR)=Itest(4)
       Start(MO)=Itest(2)
       Begspn(YR)=Itest(4)
       Begspn(MO)=Itest(2)
       endspn(YR)=Itest(5)
       endspn(MO)=Itest(3)
       Sp=Itest(1)
       Havesp=T
       CALL dfdate(endspn,Begspn,Sp,Nspobs)
       Nspobs=Nspobs+1
       Nobs=Nspobs
c----------------------------------------------------------------------
c     If beginning or ending date in the model span is undefined, set 
c     equal to beginning date of the span.
c----------------------------------------------------------------------
       IF(spnmdl(YR,1).eq.NOTSET)THEN
        CALL cpyint(Begspn,2,1,Begmdl)
       ELSE
        CALL cpyint(spnmdl,2,1,Begmdl)
       END IF
       IF(spnmdl(YR,2).eq.NOTSET.or.spnmdl(YR,2).eq.0)THEN
        CALL addate(Begspn,Sp,Nspobs-1,Endmdl)
        IF(spnmdl(YR,2).eq.0)THEN
         Endmdl(MO)=spnmdl(MO,2)
         IF(Endmdl(MO).gt.Endspn(MO))Endmdl(YR)=Endmdl(YR)-1
        END IF
       ELSE
        CALL cpyint(spnmdl(1,2),2,1,Endmdl)
       END IF
c-----------------------------------------------------------------------
c     Check that the span is within the series
c-----------------------------------------------------------------------
       CALL dfdate(Endmdl,Begmdl,Sp,nobmdl)
       nobmdl=nobmdl+1
       IF(.not.chkcvr(Begspn,Nspobs,Begmdl,nobmdl,Sp))THEN
        CALL inpter(PERRNP,Errpos,
     &           'Model span is not within the span of available data.')
        CALL cvrerr('span',Begspn,Nspobs,'model span',Begmdl,nobmdl,Sp)
        IF(Lfatal)RETURN
        Inptok=F
       END IF
c-----------------------------------------------------------------------
c     If beginning date of spectral plot is undefined, set equal to 
c     beginning date of series.
c-----------------------------------------------------------------------
       IF(Bgspec(YR).eq.NOTSET)THEN
        IF(Sp.eq.12)THEN
         CALL addate(Endspn,Sp,-8*Sp,Bgspec)
         CALL dfdate(Bgspec,Begspn,Sp,nspec)
        ELSE
         nspec=-1
        END IF
        IF(nspec.lt.0)CALL cpyint(Start,2,1,Bgspec)
       ELSE
c-----------------------------------------------------------------------
c     Check that the span is within the series
c-----------------------------------------------------------------------
        CALL dfdate(Bgspec,Start,Sp,nspec)
        IF(nspec.lt.0)THEN
         CALL inpter(PERRNP,Errpos,
     &     'Starting date of spectral plots is before start of series.')
         Locok=F
        END IF
        CALL dfdate(Bgspec,endspn,Sp,nspec)
        IF(nspec.ge.0)THEN
         CALL inpter(PERRNP,Errpos,
     &        'Starting date of spectral plots is after end of series.')
         Locok=F
        END IF
       END IF
c     ------------------------------------------------------------------
c     Set Peakwd according to the seasonal period, if it is not already
c     set (BCM May 2007)
c     ------------------------------------------------------------------
       IF(Peakwd.eq.NOTSET)THEN
        Peakwd=1
        IF(Sp.eq.4)Peakwd=3
       END IF
c-----------------------------------------------------------------------
       IF(Locok)CALL agr1(Y,Nobs)
       Inptok=Inptok.and.Locok
c     ------------------------------------------------------------------
       RETURN
  190  CONTINUE
      END DO
c     ------------------------------------------------------------------
      END
