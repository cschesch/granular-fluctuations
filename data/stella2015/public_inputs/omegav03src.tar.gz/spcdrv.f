C     Last change:  BCM  14 Jan 2009 10:02 am
      SUBROUTINE spcdrv(Muladd,Iagr,Kswv,Ny,Lx11,Kfulsm,Lgraf,Lmodel)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Routine which computes the spectrum for the detrended original
c     series, detrended seasonally adjusted series, and the irregular
c     component modified for extreme values.  If there are peaks
c     detected at the trading day or seasonal frequencies, these are
c     noted.
c-----------------------------------------------------------------------
c     AR-Spectrum routines originally appeared in the BAYSEA program,
c     developed by H. Akaike and G. Kitagawa of the Institute for
c     Statistical Mathematics.
c-----------------------------------------------------------------------
      CHARACTER STTDIC*74
      INTEGER PSTT,IONE,SIXONE,IZERO,ITEN,NTDLIM
      DOUBLE PRECISION ZERO,ONE
      LOGICAL F,T
      PARAMETER(F=.false.,T=.true.,PSTT=4,IONE=1,SIXONE=61,IZERO=0,
     &          ZERO=0D0,ITEN=10,NTDLIM=60,ONE=1D0,
     &          STTDIC='differencedundifferenceddifferenced, transformed
     &undifferenced, transformed')
c-----------------------------------------------------------------------
      INCLUDE 'stdio.i'
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'notset.prm'
      INCLUDE 'tbltitle.prm'
      INCLUDE 'x11adj.cmn'
      INCLUDE 'x11fac.cmn'
      INCLUDE 'model.cmn'
      INCLUDE 'inpt.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
      INCLUDE 'hiddn.cmn'
      INCLUDE 'x11ptr.cmn'
      INCLUDE 'extend.cmn'
      INCLUDE 'error.cmn'
      INCLUDE 'title.cmn'
      INCLUDE 'rho.cmn'
      INCLUDE 'x11msc.cmn'
      INCLUDE 'x11srs.cmn'
      INCLUDE 'x11log.cmn'
      INCLUDE 'orisrs.cmn'
      INCLUDE 'adxser.cmn'
      INCLUDE 'mdltbl.i'
      INCLUDE 'x11tbl.i'
      INCLUDE 'cmptbl.i'
c-----------------------------------------------------------------------
      CHARACTER ttl*(PTTLEN),pkstr*(24),begstr*(10),cttl*(26),ctbl*(2),
     &          ctype*(19),endstr*(10),spcstr*(36)
      DOUBLE PRECISION Lam,Temp,orisxx,sasxx,irrsxx,Stime,Stmcd,
     &                 frq,srs,tmpsxx,pklim,star1,Stex
      INTEGER i,l1,l2,Ny,Muladd,Iagr,Kswv,ipk,ipos,Fcntyp,nchr1,nchr2,
     &        sttptr,nttl,ittl,ntype,numttl,mtspc,ltdori,ltdsa,
     &        ltdirr,lsori,lssa,lsirr,frqidx,icode,Endspn,Begxy,Nrxy,
     &        nplot,nspstr,nspst2,domfqs,domfqt,nobspc,Kfulsm,fhnote,
     &        itbls0,itbls1,itbls2
      LOGICAL goori,gosa,goirr,Lx11,prtori,prtsa,prtirr,Lgraf,ltdfrq,
     &        Lmodel
      DIMENSION orisxx(61),sasxx(61),irrsxx(61),frq(61),
     &          Temp(PLEN),Stmcd(PLEN),Stime(PLEN),sttptr(0:PSTT),
     &          numttl(2),ttl(2),srs(PLEN),Begxy(2),Endspn(2),
     &          tmpsxx(61),Stex(PLEN)
c-----------------------------------------------------------------------
      COMMON /work  / Temp
      COMMON /armalm/ Lam,Fcntyp
      COMMON /armaxy/ Endspn,Begxy,Nrxy
      COMMON /mq5a  / Stmcd,Stime
      COMMON /mq10  / Stex
c-----------------------------------------------------------------------
      LOGICAL dpeq,ispos
      INTEGER ispeak,smpeak
      EXTERNAL dpeq,ispeak,smpeak,ispos
c-----------------------------------------------------------------------
      DATA sttptr/1,12,25,49,75/
c-----------------------------------------------------------------------
c     Set logical variables for printing out spectra
c-----------------------------------------------------------------------
      prtsa=(Iagr.lt.4.and.Prttab(LX11S1)).or.
     &      (Iagr.eq.4.and.Prttab(LCMPS1))
      prtirr=(Iagr.lt.4.and.Prttab(LX11S2)).or.
     &       (Iagr.eq.4.and.Prttab(LCMPS2))
      prtori=(Iagr.lt.3.and.Prttab(LSRSS0)).or.
     &       (Iagr.eq.3.and.Prttab(LCMPS0))
c-----------------------------------------------------------------------
      fhnote=STDERR
      IF(Lquiet)fhnote=0
c-----------------------------------------------------------------------
c     Generate frequencies over which the spectrum will be computed
c-----------------------------------------------------------------------
      DO i=1,61
       frq(i)=dble(i-1)/120D0
      END DO
      IF(Ny.eq.12)THEN
c       frq(36)=.3036-frq(2)
c       frq(37)=.3036
c       frq(38)=.3036+frq(2)
       frq(42)=.3482D0-frq(2)
       frq(43)=.3482D0
       frq(44)=.3482D0+frq(2)
       frq(52)=.432D0-frq(2)
       frq(53)=.432D0
       frq(54)=.432D0+frq(2)
       frqidx=1
      ELSE
       frq(5)=.0446D0-frq(2)
       frq(6)=.0446D0
       frq(7)=.0446D0+frq(2)
       frq(11)=.0893D0-frq(2)
       frq(12)=.0893D0
       frq(13)=.0893D0+frq(2)
       frqidx=2
      END IF
c-----------------------------------------------------------------------
c     Initialize indicator variable for spectral plot title
c-----------------------------------------------------------------------
      ittl=2
      IF(Spcdff)THEN
       IF(Spdfor.eq.NOTSET)THEN
        IF(Lmodel)THEN
         Spdfor=max(Nnsedf+Nseadf-1,1)
        ELSE
         Spdfor=1
        END IF
       END IF
       IF(Spdfor.eq.0)THEN
        Spcdff=F
       ELSE
        ittl=1
       END IF
      END IF
      IF(Lsumm.gt.0)THEN
       IF(Spcdff)THEN
        WRITE(Nform,1000)'diffspec: ','yes'
        WRITE(Nform,1010)'diffspecorder: ',Spdfor
       ELSE
        WRITE(Nform,1000)'diffspec: ','no'
       END IF
      END IF
c-----------------------------------------------------------------------
c     Get relative position of starting point for spectrums
c-----------------------------------------------------------------------
c      CALL dfdate(Bgspec,Begbak,Ny,ipos)
      CALL dfdate(Bgspec,Begbk2,Ny,ipos)
      ipos=ipos+1
      l1=ipos
      IF(Spcdff)l1=ipos+Spdfor
      nobspc=Posfob-l1+1
      ltdfrq=nobspc.gt.NTDLIM
c-----------------------------------------------------------------------
c     Check to see if all observations are good for logged original 
c     series
c-----------------------------------------------------------------------
      goori=Iagr.le.3
      gosa=F
      goirr=F
      IF(goori)THEN
       IF(Spcsrs.ge.2)THEN
        CALL copy(Stcsi,PLEN,1,srs)
        IF(Lx11.and.(Spcsrs.eq.2))THEN
         IF(Psuadd)THEN
          DO i=Pos1ob,Posfob
           IF(Kfulsm.eq.2)THEN
            srs(i)=Stc(i)*Sti(i)
           ELSE
            srs(i)=Stc(i)*(Sts(i)+(Sti(i)-ONE))
           END IF
          END DO
         ELSE 
          CALL addmul(srs,srs,Stex,Pos1bk,Posffc)
         END IF
        END IF
       ELSE
        CALL copy(Series,PLEN,1,srs)
        IF(Spcsrs.eq.1)THEN
         IF(Adjls.eq.1)CALL divsub(srs,srs,Facls,ipos,Posfob)
         IF(Adjao.eq.1)CALL divsub(srs,srs,Facao,ipos,Posfob)
         IF(Adjtc.eq.1)CALL divsub(srs,srs,Factc,ipos,Posfob)
        END IF
       END IF
       IF(Muladd.eq.0)goori=ispos(srs,ipos,Posfob)
      END IF
      IF(goori)THEN
c-----------------------------------------------------------------------
c     Detrend original series before computing spectrum
c-----------------------------------------------------------------------
       IF(Lx11)THEN
        IF(Muladd.ne.1)ittl=ittl+2
        CALL gendff(srs,ipos,Posfob,Temp,l2,Muladd.ne.1,Spdfor)
       ELSE
        IF(dpeq(Lam,ZERO))THEN
         CALL gendff(srs,ipos,Posfob,Temp,l2,T,Spdfor)
         ittl=ittl+2
        ELSE
         CALL gendff(srs,ipos,Posfob,Temp,l2,F,Spdfor)
        END IF
       END IF
       IF(Spctyp.eq.0)THEN
c-----------------------------------------------------------------------
c     Compute the AR-spectrum for the detrended original series
c-----------------------------------------------------------------------
        CALL spgrh(Temp,orisxx,frq,Thtapr,l2,Posfob,Ny,Mxarsp,goori)
       ELSE
c-----------------------------------------------------------------------
c     Else, compute the periodogram for the detrended original series
c-----------------------------------------------------------------------
        CALL spgrh2(Temp,orisxx,frq,l2,Posfob)
       END IF
c-----------------------------------------------------------------------
c     Save spectrum of the detrended original series
c-----------------------------------------------------------------------
       IF(Iagr.lt.4)THEN
        itbls0=LSRSS0
        IF(Spcsrs.eq.0)THEN
         nspstr=12
         spcstr(1:nspstr)='Spectrum_Ori'
        ELSE IF(Spcsrs.eq.1)THEN
         nspstr=18
         spcstr(1:nspstr)='Spectrum_OtlAdjOri'
        ELSE IF(Spcsrs.eq.2)THEN
         nspstr=15
         spcstr(1:nspstr)='Spectrum_AdjOri'
        ELSE IF(Spcsrs.eq.3)THEN
         nspstr=15
         spcstr(1:nspstr)='Spectrum_ModOri'
        END IF
       ELSE
        itbls0=LCMPS0
        IF(Spcsrs.eq.0)THEN
         nspstr=13
         spcstr(1:nspstr)='Spectrum_Comp'
        ELSE IF(Spcsrs.eq.1)THEN
         nspstr=19
         spcstr(1:nspstr)='Spectrum_OtlAdjComp'
        ELSE IF(Spcsrs.eq.2)THEN
         nspstr=16
         spcstr(1:nspstr)='Spectrum_AdjComp'
        ELSE IF(Spcsrs.eq.3)THEN
         nspstr=16
         spcstr(1:nspstr)='Spectrum_ModComp'
        END IF
       END IF
       IF(Savtab(itbls0).and.goori)
     &    CALL savspp(itbls0,orisxx,frq,spcstr(1:nspstr),F)
       IF(.not.Lfatal.and.Lgraf.and.goori)
     &    CALL savspp(itbls0,orisxx,frq,spcstr(1:nspstr),Lgraf)
       IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Print out error message for spectral plot of logged original
c     series if data value is less than zero.
c-----------------------------------------------------------------------
      ELSE IF(Iagr.le.3)THEN
       CALL writln('ERROR: Spectral plot for the logged original series 
     &cannot be done for',STDERR,Mt2,T)
       CALL writln('       a series with values less than or equal to ze
     &ro.',STDERR,Mt2,F)
      END IF
      IF(Lx11.and.Kfulsm.eq.0)THEN
c-----------------------------------------------------------------------
c     Check to see if all observations are good for logged seasonally
c     adjusted series
c-----------------------------------------------------------------------
       gosa=T
       IF(Muladd.eq.0)THEN
        DO i=ipos,Posfob
         gosa=gosa.and.Stcime(i).gt.ZERO
        END DO
       END IF
       IF(gosa)THEN
        CALL copy(Stcime,PLEN,1,srs)
        IF(Adjls.eq.1)CALL divsub(srs,srs,Facls,ipos,Posfob)
c-----------------------------------------------------------------------
c     Detrend seasonally adjusted series before computing spectrum
c-----------------------------------------------------------------------
        CALL gendff(srs,ipos,Posfob,Temp,l2,Muladd.ne.1,Spdfor)
c-----------------------------------------------------------------------
c     Compute the AR-spectrum for the detrended seasonally adjusted
c     series
c-----------------------------------------------------------------------
        IF(Spctyp.eq.0)THEN
         CALL spgrh(Temp,sasxx,frq,Thtapr,l2,Posfob,Ny,Mxarsp,gosa)
        ELSE
c-----------------------------------------------------------------------
c     Else, compute the periodogram for the detrended seasonally 
c     adjusted series
c-----------------------------------------------------------------------
         CALL spgrh2(Temp,sasxx,frq,l2,Posfob)
        END IF
c-----------------------------------------------------------------------
c     Save spectrum of the detrended seasonally adjusted series
c-----------------------------------------------------------------------
        IF(Iagr.lt.4)THEN
         itbls1=LX11S1
         nspstr=11
         spcstr(1:nspstr)='Spectrum_SA'
        ELSE
         itbls1=LCMPS1
         nspstr=14
         spcstr(1:nspstr)='Spectrum_IndSA'
        END IF
        IF(Savtab(itbls1).and.gosa)
     &     CALL savspp(itbls1,sasxx,frq,spcstr(1:nspstr),F)
        IF(.not.Lfatal.and.Lgraf.and.gosa)
     &     CALL savspp(itbls1,sasxx,frq,spcstr(1:nspstr),Lgraf)
        IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Print out error message for spectral plot of logged original
c     series if data value is less than zero.
c-----------------------------------------------------------------------
       ELSE
        CALL writln('ERROR: Spectral plot for the logged seasonally adju
     &sted series cannot',STDERR,Mt2,T)
        CALL writln('       be done for a seasonal adjustment with value
     &s less than or equal',STDERR,Mt2,F)
        CALL writln('       to zero.',STDERR,Mt2,F)
       END IF
c-----------------------------------------------------------------------
c     Compute the AR-spectrum for the modified irregular component
c-----------------------------------------------------------------------
       DO i=ipos,Posfob
        IF(Muladd.eq.1)THEN
         Temp(i)=Stime(i)
        ELSE
         Temp(i)=Stime(i)-1D0
        END IF
       END DO
c-----------------------------------------------------------------------
       goirr=T
       IF(Spctyp.eq.0)THEN
        CALL spgrh(Temp,irrsxx,frq,Thtapr,ipos,Posfob,Ny,Mxarsp,goirr)
       ELSE
c-----------------------------------------------------------------------
c     Else, compute the periodogram for the modified irregular component
c-----------------------------------------------------------------------
        CALL spgrh2(Temp,irrsxx,frq,ipos,Posfob)
       END IF
c-----------------------------------------------------------------------
c     Save spectrum of the modified irregular component
c-----------------------------------------------------------------------
       IF(Iagr.lt.4)THEN
        itbls2=LX11S2
        nspstr=12
        spcstr(1:nspstr)='Spectrum_Irr'
       ELSE
        itbls2=LCMPS2
        nspstr=15
        spcstr(1:nspstr)='Spectrum_IndIrr'
       END IF
       IF(Savtab(itbls2).and.goirr)
     &    CALL savspp(itbls2,irrsxx,frq,spcstr(1:nspstr),F)
       IF(.not.Lfatal.and.Lgraf.and.goirr)
     &    CALL savspp(itbls2,irrsxx,frq,spcstr(1:nspstr),Lgraf)
       IF(Lfatal)RETURN
      END IF
c-----------------------------------------------------------------------
      IF(.not.(goori.or.gosa.or.goirr))RETURN
c-----------------------------------------------------------------------
c     Determine if there are peaks in the spectral plots.
c-----------------------------------------------------------------------
      ltdsa=0
      ltdirr=0
      lssa=0
      lsirr=0
      IF(Lx11.and.Kfulsm.eq.0)THEN
       IF(gosa)THEN
        CALL copy(sasxx,61,1,tmpsxx)
        CALL shlsrt(61,tmpsxx)
        pklim=(tmpsxx(61)-tmpsxx(1))*(Spclim/52D0)
        IF(ltdfrq)ltdsa=ispeak(sasxx,frqidx,pklim,tmpsxx(31),1)
        lssa=ispeak(sasxx,frqidx+2,pklim,tmpsxx(31),Peakwd)
        IF(Lsumm.gt.0)THEN
         IF(Iagr.lt.4)THEN
          nspstr=5
          spcstr(1:nspstr)='spcsa'
         ELSE
          nspstr=8
          spcstr(1:nspstr)='spcindsa'
         END IF
         star1=(tmpsxx(61)-tmpsxx(1))/52D0
         domfqt=NOTSET
         IF(ltdfrq)domfqt=smpeak(sasxx,frqidx,star1,tmpsxx(31),Nform,
     &                           spcstr(1:nspstr))
         domfqs=smpeak(sasxx,frqidx+2,star1,tmpsxx(31),Nform,
     &                 spcstr(1:nspstr))
         CALL mxpeak(sasxx,frqidx,domfqt,domfqs,tmpsxx(61),Nform,
     &               spcstr(1:nspstr))
        END IF
       END IF
       IF(goirr)THEN
        CALL copy(irrsxx,61,1,tmpsxx)
        CALL shlsrt(61,tmpsxx)
        pklim=(tmpsxx(61)-tmpsxx(1))*(Spclim/52D0)
        IF(ltdfrq)ltdirr=ispeak(irrsxx,frqidx,pklim,tmpsxx(31),1)
        lsirr=ispeak(irrsxx,frqidx+2,pklim,tmpsxx(31),Peakwd)
        IF(Lsumm.gt.0)THEN
         IF(Iagr.lt.4)THEN
          nspstr=6
          spcstr(1:nspstr)='spcirr'
         ELSE
          nspstr=9
          spcstr(1:nspstr)='spcindirr'
         END IF
         star1=(tmpsxx(61)-tmpsxx(1))/52D0
         domfqt=NOTSET
         IF(ltdfrq)domfqt=smpeak(irrsxx,frqidx,star1,tmpsxx(31),Nform,
     &                    spcstr(1:nspstr))
         domfqs=smpeak(irrsxx,frqidx+2,star1,tmpsxx(31),Nform,
     &                 spcstr(1:nspstr))
         CALL mxpeak(irrsxx,frqidx,domfqt,domfqs,tmpsxx(61),Nform,
     &               spcstr(1:nspstr))
        END IF
       END IF
      END IF
c-----------------------------------------------------------------------
c     If TD adjustment done, do not search for trading day peaks 
c     in the original series.  Search for seasonal peaks only when there
c     is no seasonal adjustment performed.
c-----------------------------------------------------------------------
      IF(prtsa)THEN
       prtsa=prtsa.and.gosa
      ELSE
       prtsa=(ltdsa.gt.0.or.lssa.gt.0).and.(.not.Lnoprt)
      END IF
      IF(prtirr)THEN
       prtirr=prtirr.and.goirr
      ELSE
       prtirr=(ltdirr.gt.0.or.lsirr.gt.0).and.(.not.Lnoprt)
      END IF
      ltdori=0
      lsori=0
      IF(goori)THEN
       CALL copy(orisxx,61,1,tmpsxx)
       CALL shlsrt(61,tmpsxx)
       pklim=(tmpsxx(61)-tmpsxx(1))*(Spclim/52D0)
       IF(ltdfrq)ltdori=ispeak(orisxx,frqidx,pklim,tmpsxx(31),1)
       lsori=ispeak(orisxx,frqidx+2,pklim,tmpsxx(31),Peakwd)
       IF(Axrgtd.OR.(Adjtd.eq.1).or.(Kswv.gt.0))ltdori=0
       IF(.not.prtori)
     &    prtori=(((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0).or.
     &              ltdori.gt.0).and.(.not.Lnoprt)
       IF(Lsumm.gt.0)THEN
        IF(Iagr.lt.4)THEN
         nspstr=6
         spcstr(1:nspstr)='spcori'
        ELSE
         nspstr=7
         spcstr(1:nspstr)='spccomp'
        END IF
        star1=(tmpsxx(61)-tmpsxx(1))/52D0
        domfqt=NOTSET
        IF(ltdfrq)domfqt=smpeak(orisxx,frqidx,star1,tmpsxx(31),Nform,
     &                          spcstr(1:nspstr))
        domfqs=smpeak(orisxx,frqidx+2,star1,tmpsxx(31),Nform,
     &                spcstr(1:nspstr))
        CALL mxpeak(orisxx,frqidx,domfqt,domfqs,tmpsxx(61),Nform,
     &              spcstr(1:nspstr))
       END IF
      END IF
c-----------------------------------------------------------------------
c     Get descriptor for spectral plot title
c-----------------------------------------------------------------------
      CALL getstr(STTDIC,STTPTR,PSTT,ittl,cttl,nttl)
      IF(.not.Lfatal)CALL wrtdat(Bgspec,Ny,begstr,nchr1)
      IF(.not.Lfatal)CALL wrtdat(Endspn,Ny,endstr,nchr2)
      IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Print a warning message if a peak is found in any of the spectral
c     plots.
c-----------------------------------------------------------------------
      IF((ltdori.gt.0.or.ltdsa.gt.0.or.ltdirr.gt.0).and.
     & (((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0).or.
     &    lssa.gt.0.or.lsirr.gt.0))THEN
       CALL writln('WARNING: Visually significant seasonal and trading d
     &ay peaks have ',fhnote,Mt2,T)
       CALL writln( 
     &'         been found in one or more of the estimated spectra.',
     &             fhnote,Mt2,F)
       pkstr='trading day and seasonal'
       ipk=24
      ELSE IF((ltdori.gt.0.or.ltdsa.gt.0.or.ltdirr.gt.0).or.
     &      (((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0).or.
     &         lssa.gt.0.or.lsirr.gt.0))THEN
       IF(ltdori.gt.0.or.ltdsa.gt.0.or.ltdirr.gt.0)THEN
        pkstr='trading day'
        ipk=11
       ELSE
        pkstr='seasonal'
        ipk=8
       END IF
       CALL writln('WARNING: At least one visually significant '//
     &             pkstr(1:ipk)//' peak has been',fhnote,Mt2,T)
       CALL writln(
     &  '         found in one or more of the estimated spectra.',
     &             fhnote,Mt2,F)
      END IF
c-----------------------------------------------------------------------
      mtspc=Mt1
      nplot=NOTSET
      IF(((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0).or.
     &   ltdori.gt.0.or.ltdsa.gt.0.or.ltdirr.gt.0.or.lssa.gt.0.or.
     &   lsirr.gt.0)THEN
       IF((.not.(prtori.or.prtsa.or.prtirr)).and.Lnoprt)THEN
        mtspc=Mt2
        WRITE(STDERR,1070)
       ELSE
        IF(Lpage)THEN
         WRITE(Mt1,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
         Kpage=Kpage+1
        END IF
       END IF
       IF(mtspc.eq.Mt1.and.Laccss)CALL insacd(Mt1,'peak.warning',T)
       nplot=0
       IF(ltdori.gt.0.or.((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0))
     &    nplot=nplot+1
       IF(ltdsa.gt.0.or.lssa.gt.0)nplot=nplot+1
       IF(ltdirr.gt.0.or.lsirr.gt.0)nplot=nplot+1
       IF(nplot.eq.1)THEN
        WRITE(mtspc,1020)pkstr(1:ipk),'plot',begstr(1:nchr1)
       ELSE
        WRITE(mtspc,1020)pkstr(1:ipk),'plots',begstr(1:nchr1)
       END IF
c-----------------------------------------------------------------------
c     Warning for detrended original
c-----------------------------------------------------------------------
       CALL mkspst(Spcsrs,spcstr,nspstr,nspst2,F)
       IF(((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0).and.
     &    ltdori.gt.0)THEN
        WRITE(mtspc,1040)cttl(1:nttl)//spcstr(1:nspstr),lsori,ltdori
       ELSE IF(ltdori.gt.0)THEN
        WRITE(mtspc,1030)cttl(1:nttl)//spcstr(1:nspstr),ltdori
       ELSE IF((.not.Lx11).and.lsori.gt.0)THEN
        WRITE(mtspc,1050)cttl(1:nttl)//spcstr(1:nspstr),lsori
       END IF
c-----------------------------------------------------------------------
c     Warning for detrended seasonally adjusted series
c-----------------------------------------------------------------------
       IF(ltdsa.gt.0.and.lssa.gt.0)THEN
        WRITE(mtspc,1040)
     &        cttl(1:nttl)//' seasonally adjusted series (Table E2)',
     &        lssa,ltdsa
       ELSE IF(ltdsa.gt.0)THEN
        WRITE(mtspc,1030)
     &        cttl(1:nttl)//' seasonally adjusted series (Table E2)',
     &        ltdsa
       ELSE IF(lssa.gt.0)THEN
        WRITE(mtspc,1050)
     &        cttl(1:nttl)//' seasonally adjusted series (Table E2)',
     &        lssa
       END IF
c-----------------------------------------------------------------------
c     Warning for modified irregular series
c-----------------------------------------------------------------------
       IF(ltdirr.gt.0.and.lsirr.gt.0)THEN
        WRITE(mtspc,1040)'Modified irregular component (Table E3)',
     &                   lsirr,ltdirr
       ELSE IF(ltdirr.gt.0)THEN
        WRITE(mtspc,1030)'Modified irregular component (Table E3)',
     &                   ltdirr
       ELSE IF(lsirr.gt.0)THEN
        WRITE(mtspc,1050)'Modified irregular component (Table E3)',lsirr
       END IF
       IF(mtspc.eq.Mt1.and.Laccss)CALL insacd(Mt1,'peak.warning',F)
      END IF
c-----------------------------------------------------------------------
c    Print warning message if no seasonal peaks is found in original
c    series and x11 spec present.
c    June 2006 - only print out warning message if seasonal adjustment
c    actually performed
c-----------------------------------------------------------------------
      IF((Lx11.and.Kfulsm.eq.0).and.lsori.eq.0.and.goori)THEN
       IF(Lnoprt.and.mtspc.eq.Mt1)mtspc=Mt2
       IF(mtspc.eq.Mt1.and.Laccss)THEN
        IF(nplot.eq.NOTSET)THEN
         CALL insacd(Mt1,'peak.warning.none.header',T)
        ELSE
         CALL insacd(Mt1,'peak.warning.none',T)
        END IF
       END IF
       CALL mkspst(Spcsrs,spcstr,nspstr,nspst2,F)
       IF(.not.Lquiet)WRITE(STDERR,1060)spcstr(1:nspstr)
       WRITE(mtspc,1060)spcstr(1:nspstr)
       IF(Iagr.lt.4)WRITE(mtspc,1061)
       IF(mtspc.eq.Mt1.and.Laccss)THEN
        IF(nplot.eq.NOTSET)THEN
         CALL insacd(Mt1,'peak.warning.none.header',F)
        ELSE
         CALL insacd(Mt1,'peak.warning.none',F)
        END IF
       END IF
      END IF
c-----------------------------------------------------------------------
      IF(Svpeak)THEN
       IF(ltdori.gt.0)THEN
        Ctpeak((Ntpeak+1):(Ntpeak+3))='ori'
        Ntpeak=Ntpeak+4
       END IF
       IF((.not.(Lx11.and.Kfulsm.eq.0)).and.lsori.gt.0)THEN
        Cspeak((Nspeak+1):(Nspeak+3))='ori'
        Nspeak=Nspeak+4
       END IF
       IF(ltdsa.gt.0)THEN
        IF(Iagr.le.3)THEN
         Ctpeak((Ntpeak+1):(Ntpeak+2))='sa'
         Ntpeak=Ntpeak+3
        ELSE
         Ctpeak((Ntpeak+1):(Ntpeak+5))='indsa'
         Ntpeak=Ntpeak+6
        END IF
       END IF
       IF(lssa.gt.0)THEN
        IF(Iagr.le.3)THEN
         Cspeak((Nspeak+1):(Nspeak+2))='sa'
         Nspeak=Nspeak+3
        ELSE
         Cspeak((Nspeak+1):(Nspeak+5))='indsa'
         Nspeak=Nspeak+6
        END IF
       END IF
       IF(ltdirr.gt.0)THEN
        IF(Iagr.le.3)THEN
         Ctpeak((Ntpeak+1):(Ntpeak+3))='irr'
         Ntpeak=Ntpeak+4
        ELSE
         Ctpeak((Ntpeak+1):(Ntpeak+6))='indirr'
         Ntpeak=Ntpeak+7
        END IF
       END IF
       IF(lsirr.gt.0)THEN
        IF(Iagr.le.3)THEN
         Cspeak((Nspeak+1):(Nspeak+3))='irr'
         Nspeak=Nspeak+4
        ELSE
         Cspeak((Nspeak+1):(Nspeak+6))='indirr'
         Nspeak=Nspeak+7
        END IF
       END IF
      END IF
c-----------------------------------------------------------------------
c     Print plots of spectrums.  If peaks are found, produce plots
c     even if they are not selected by the user.
c-----------------------------------------------------------------------
      IF(.not.(prtori.or.prtsa.or.prtirr).and.Lnoprt)RETURN
c-----------------------------------------------------------------------
c     Spectrum plot for detrended original series
c-----------------------------------------------------------------------
      icode=20
      IF(.not.ltdfrq)icode=21
      IF(Spctyp.eq.0)THEN
       ctype='10*LOG(SPECTRUM)'
       ntype=16
      ELSE
       ctype='10*LOG(PERIODOGRAM)'
       ntype=19
      END IF
      IF(goori.and.prtori)THEN
       IF(Lpage)THEN
        WRITE(Mt1,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
c-----------------------------------------------------------------------
       CALL mkspst(Spcsrs,spcstr,nspstr,nspst2,T)
       IF(Laccss)THEN
        ctbl=' G'
       ELSE
        ctbl='G '
       END IF
       IF(Lwdprt)THEN
        ttl(1)=ctbl//'0  '//ctype(1:ntype)//' of the '//cttl(1:nttl)//
     &         ' '//spcstr(1:nspstr)
        numttl(1)=ntype+nttl+nspstr+14
        ttl(2)='     Spectrum estimated from '//begstr(1:nchr1)//
     &         ' to '//endstr(1:nchr2)//'.'
        numttl(2)=34+nchr1+nchr2
       ELSE
        ttl(1)=ctbl//'0  '//ctype(1:ntype)//' of the '//cttl(1:nttl)//
     &         spcstr(1:nspst2) 
        numttl(1)=ntype+nttl+nspst2+13
        ttl(2)='    '//spcstr(nspst2+1:nspstr)//
     &         '.  Spectrum estimated from '//begstr(1:nchr1)//' to '//
     &         endstr(1:nchr2)//'.'
        numttl(2)=nspstr-nspst2+nchr1+nchr2+36
       END IF
c-----------------------------------------------------------------------
       IF((Lx11.and.Kfulsm.eq.0).and.prtori.and.prtsa.and.Axsame)THEN
        CALL grzlst(IONE,SIXONE,IZERO,orisxx,sasxx,SIXONE,ITEN,IZERO)
       ELSE
        CALL grzlst(IONE,SIXONE,IZERO,orisxx,orisxx,SIXONE,ITEN,IZERO)
       END IF
       IF(Laccss)CALL insmrk(Mt1,itbls0,T,F)
       CALL chrt(ttl,numttl,icode,1,120/Ny)
       IF(Lfatal)RETURN
       IF(Laccss)CALL insmrk(Mt1,itbls0,F,F)
      END IF
c-----------------------------------------------------------------------
      IF(.not.Lx11)RETURN
c-----------------------------------------------------------------------
c     Spectrum plot for detrended seasonally adjusted series
c-----------------------------------------------------------------------
      IF(prtsa)THEN
       IF(Lpage)THEN
        WRITE(Mt1,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
       IF(Lwdprt)THEN
        IF(Iagr.le.3)THEN
         ttl(1)=ctbl//'1  '//ctype(1:ntype)//' of the '//cttl(1:nttl)//
     &          ' Seasonally Adjusted Data (Table E2).'
         numttl(1)=ntype+nttl+50
        ELSE
         ttl(1)=ctbl//'1  '//ctype(1:ntype)//' of the '//cttl(1:nttl)//
     &          ' Indirect Seasonally Adjusted Data (Table E2).'
         numttl(1)=ntype+nttl+59
        END IF
        ttl(2)='     Spectrum estimated from '//begstr(1:nchr1)//
     &         ' to '//endstr(1:nchr2)//'.'
        numttl(2)=34+nchr1+nchr2
       ELSE
        IF(Iagr.le.3)THEN
         ttl(1)=ctbl//'1  '//ctype(1:ntype)//' of the '//cttl(1:nttl)//
     &          ' Seasonally Adjusted'
         numttl(1)=ntype+nttl+34
        ELSE
         ttl(1)=ctbl//'1  '//ctype(1:ntype)//' of the '//cttl(1:nttl)//
     &          ' Indirect Seasonally Adjusted'
         numttl(1)=ntype+nttl+43
        END IF
        ttl(2)='     Data (Table E2).  Spectrum estimated from '//
     &         begstr(1:nchr1)//' to '//endstr(1:nchr2)//'.'
        numttl(2)=52+nchr1+nchr2
       END IF
       IF(goori.and.prtori.and.prtsa.and.Axsame)THEN
        CALL grzlst(IONE,SIXONE,IZERO,sasxx,orisxx,SIXONE,ITEN,IZERO)
       ELSE
        CALL grzlst(IONE,SIXONE,IZERO,sasxx,sasxx,SIXONE,ITEN,IZERO)
       END IF
       IF(Laccss)CALL insmrk(Mt1,itbls1,T,F)
       CALL chrt(ttl,numttl,icode,1,120/Ny)
       IF(Lfatal)RETURN
       IF(Laccss)CALL insmrk(Mt1,itbls1,F,F)
      END IF
c-----------------------------------------------------------------------
c     Spectrum plot for modified irregular series
c-----------------------------------------------------------------------
      IF(prtirr)THEN
       IF(Lpage)THEN
        WRITE(Mt1,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
       IF(Iagr.le.3)THEN
        ttl(1)=ctbl//'2  '//ctype(1:ntype)//
     &         ' of the Modified Irregular (Table E3).'

        numttl(1)=ntype+45
       ELSE
        ttl(1)=ctbl//'2  '//ctype(1:ntype)//
     &         ' of the Indirect Modified Irregular (Table E3).'

        numttl(1)=ntype+54
       END IF
       ttl(2)='     Spectrum estimated from '//begstr(1:nchr1)//
     &        ' to '//endstr(1:nchr2)//'.'
       numttl(2)=34+nchr1+nchr2
       IF(Laccss)CALL insmrk(Mt1,itbls2,T,F)
       CALL grzlst(IONE,SIXONE,IZERO,irrsxx,irrsxx,SIXONE,ITEN,IZERO)
       CALL chrt(ttl,numttl,icode,1,120/Ny)
       IF(Lfatal)RETURN
       IF(Laccss)CALL insmrk(Mt1,itbls2,F,F)
      END IF
c-----------------------------------------------------------------------
      RETURN
c-----------------------------------------------------------------------
 1000 FORMAT(a,a)
 1010 FORMAT(a,i4)
 1020 FORMAT(//,'  Visually significant residual ',a,' peaks have been',
     &        /,'  found in the spectral ',a,' of the following series',
     &          ' starting in ',a,':',/)
 1030 FORMAT(10x,a,' (',i1,' Trading Day peak(s))',/)
 1040 FORMAT(10x,a,' (',i1,' Seasonal and ',i1,' Trading Day peaks)',/)
 1050 FORMAT(10x,a,' (',i1,' Seasonal peak(s))',/)
 1070 FORMAT(/,'          Rerun the input file without the output ',
     &         'suppression option',/,
     &         '          (-n flag) for more details.')
 1060 FORMAT(//,' WARNING: Series should not be a candidate for ',
     &          'seasonal adjustment',/,
     &          '          because the spectrum of the',a,/
     &          '          has no visually significant seasonal peaks.')
 1061 FORMAT(/,'          If this is a component series of an ',
     &         'indirectly adjusted',/,
     &         '          composite series, consider using type = ',
     &         'trend or type = summary',/,
     &         '          in the x11 spec.')
      END
