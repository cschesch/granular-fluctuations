C     Last change:  BCM  23 May 2007 10:19 am
**==spgrh.f    processed by SPAG 4.03F  at 10:39 on 20 Oct 1994
      SUBROUTINE spgrh(Yy,Sxx,Frq,Thtapr,N1,N2,Ny,Mxarsp,Good)
      IMPLICIT NONE
c-----------------------------------------------------------------------
C*** Start of declarations inserted by SPAG
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'notset.prm'
c-----------------------------------------------------------------------
      LOGICAL Good
      DOUBLE PRECISION Yy,Sxx,an,x,y,a,b,cxx,oaic,sgme2,Frq,Thtapr
      INTEGER h,h1,i,ifpl,ifpl1,k,l,lagh,lagh1,n,N1,N2,Ny,Mxarsp
c-----------------------------------------------------------------------
C*** End of declarations inserted by SPAG
c     replace dimension length for yy (BCM May 2007)
c-----------------------------------------------------------------------
      DIMENSION y(PLEN),Yy(*),x(PLEN),cxx(61),a(101),b(101),Sxx(61),
     &          Frq(61)
c-----------------------------------------------------------------------
      n=N2-N1+1
c-----------------------------------------------------------------------
      DO i=N1,N2
       y(i)=Yy(i)
      END DO
c-----------------------------------------------------------------------
      h=60
c-----------------------------------------------------------------------
      h1=h+1
c-----------------------------------------------------------------------
      DO i=N1,N2
       x(i)=y(i)
      END DO
c-----------------------------------------------------------------------
C     AUTO COVARIANCE COMPUTATION.
c-----------------------------------------------------------------------
      lagh=n-1
      lagh=min0(lagh,60)
      lagh1=lagh+1
      CALL sautco(x,cxx,N1,N2,n,lagh1,Thtapr,Good)
      IF(.not.Good)RETURN
      an=dble(n)
      ifpl=idint(3.0D-00*sqrt(an))
c-----------------------------------------------------------------------
      ifpl=min0(ifpl,50,lagh)
c-----------------------------------------------------------------------
C     ----- 5/15/80 -----
c-----------------------------------------------------------------------
      IF(Mxarsp.eq.NOTSET)THEN
       ifpl=30*Ny/12
c       ifpl=30
      ELSE
       ifpl=Mxarsp
      END IF
      ifpl=min0(ifpl,n-1)
c-----------------------------------------------------------------------
C     ----- 5/15/80 -----
c-----------------------------------------------------------------------
      ifpl1=ifpl+1
      CALL sicp2(cxx,ifpl1,N1,N2,a,l,sgme2,oaic)
      k=0
      CALL snrasp(a,b,Sxx,Frq,sgme2,l,k,h1)
c-----------------------------------------------------------------------
      RETURN
      END
