C     Last change:  BCM  5 Sep 2006 10:52 am
      SUBROUTINE insmrk(Fh,Tblptr,Lbegin,Llogfl)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     THis subroutine inserts a code into the output file corresponding
c     to an X-12-ARIMA output table that is used by the cnvOut2HTML
c     utility to create an accessible HTML file of the output or log
c     file.
c     Author : BCM  November 2005
c-----------------------------------------------------------------------
c     Revised by BCM August 2006 to print character code rather than
c     numeric index
c-----------------------------------------------------------------------
      CHARACTER*80 tbcode
      INTEGER Fh,Tblptr,ntcode
      LOGICAL Lbegin,Llogfl
c-----------------------------------------------------------------------
      CALL getmrk(Tblptr,Llogfl,Tbcode,Ntcode)
c-----------------------------------------------------------------------
      IF(Lbegin)THEN
       WRITE(Fh,1010)':b.',Tbcode(1:ntcode)
      ELSE
       WRITE(Fh,1010)':e.',Tbcode(1:ntcode)
      END IF
 1010 FORMAT(a,a)
c-----------------------------------------------------------------------
      RETURN
      END
