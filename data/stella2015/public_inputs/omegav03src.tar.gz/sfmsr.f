C     Last change:  BCM  9 May 2007 4:45 pm
**==sfmsr.f    processed by SPAG 4.03F  at 08:51 on 15 Sep 1994
      SUBROUTINE sfmsr(Sts,Stsi,Lfda,Llda,Lldaf,Lprt,Lsav)
      IMPLICIT NONE
c     ------------------------------------------------------------------
c     This subroutine implements the MSR seasonal filter selection
c     option from X-11-ARIMA/88
c     This implementation designed by BCM - January 1993
c     Added Sts, Stsi to calling arguments - July 2005
c     ------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'units.cmn'
      INCLUDE 'work2.cmn'
      INCLUDE 'x11opt.cmn'
c     ------------------------------------------------------------------
      CHARACTER*3 filter
      DOUBLE PRECISION Sts,Stsi
      LOGICAL Lprt,Lsav
      INTEGER Lfda,Llda,Lldaf,llda1,i
      DIMENSION filter(3),Sts(PLEN),Stsi(PLEN)
c     ------------------------------------------------------------------
      DATA filter/'3x3','3x5','3x9'/
c     ------------------------------------------------------------------
c     If MSR seasonal filter selection option is selected, calculate
c     a global MSR and try to select a seasonal filter length.
c     ------------------------------------------------------------------
      IF(Lterm.eq.6)THEN
       IF(Lmsr.eq.6)THEN
        IF(Lprt)WRITE(Mt1,1010)
c     ------------------------------------------------------------------
c     set llda1 to the end of the last whole year
c     ------------------------------------------------------------------
        llda1=Llda-mod(Llda,Ny)
        i=1
        DO WHILE (Lterm.eq.6)
c     ------------------------------------------------------------------
c     If span to be tested is less than 5 years long, use a 3x5
c     seasonal filter.
c     ------------------------------------------------------------------
         IF((llda1-Lfda+1).lt.(5*Ny))THEN
          Lterm=2
          IF(Lprt)WRITE(Mt1,1020)
         ELSE
          CALL vsfa(Stsi,Lfda,llda1,Ny)
          IF(Ratis.le.2.5D0)THEN
           Lterm=1
           IF(Lprt)WRITE(Mt1,1030)i,Ratis,filter(Lterm)
          ELSE IF(Ratis.ge.6.5D0)THEN
           Lterm=3
           IF(Lprt)WRITE(Mt1,1030)i,Ratis,filter(Lterm)
          ELSE IF(Ratis.ge.3.5D0.and.Ratis.le.5.5D0)THEN
           Lterm=2
           IF(Lprt)WRITE(Mt1,1030)i,Ratis,filter(Lterm)
           L3x5=.true.
          ELSE
c     ------------------------------------------------------------------
c     If Global MSR meets none of the criteria, drop a year from the
c     end of the series and try again.
c     ------------------------------------------------------------------
           llda1=llda1-Ny
           IF(Lprt)WRITE(Mt1,1040)i,Ratis
           i=i+1
          END IF
         END IF
        END DO
        DO i=1,Ny
         IF(Lter(i).eq.6)Lter(i)=Lterm
         IF(L3x5.and.(Lter(i).ne.0.and.Lter(i).ne.2))L3x5=.false.
        END DO
c     ------------------------------------------------------------------
c     Save seasonal filter length decision
c     ------------------------------------------------------------------
        IF(Lsav)WRITE(Nform,1050)filter(Lterm)
       ELSE
c     ------------------------------------------------------------------
c     If this is a sliding spans run, reset seasonal filter length to
c     the selection made for the entire series.
c     ------------------------------------------------------------------
        Lterm=Lmsr
        DO i=1,Ny
         IF(Lter(i).eq.6)Lter(i)=Lmsr
        END DO
       END IF
      END IF
c     ------------------------------------------------------------------
      CALL vsfa(Stsi,Lfda,Llda,Ny)
      CALL vsfb(Sts,Stsi,Lfda,Lldaf,Ny)
c     ------------------------------------------------------------------
      RETURN
c     ------------------------------------------------------------------
 1010 FORMAT('1       Final Seasonal Filter Selection via GLOBAL MSR',/)
 1020 FORMAT('  ***  Not enough data to continue, 3x5 seasonal filter ',
     &       'selected  ***')
 1030 FORMAT(' Pass No. ',i2,':  Global MSR = ',f6.2,', ',a3,
     &       ' seasonal filter selected.')
 1040 FORMAT(' Pass No. ',i2,':  Global MSR = ',f6.2)
 1050 FORMAT('sfmsr: ',a3)
c     ------------------------------------------------------------------
      END
