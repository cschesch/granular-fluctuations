C     Last change:  BCM  28 Aug 2007 1:57 pm
      SUBROUTINE insend(Fh,Tbcode)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     THis subroutine inserts an ending character code (Tbcode) into
c     the output file that is used by the cnvOut2HTML utility to
c     match a beginning code, then enter the end.table code to ensure
c     that the table is finished correctly in the output or log file.
c     Author : BCM August 2007 
c-----------------------------------------------------------------------
      INTEGER Fh
      CHARACTER*(*) Tbcode
c-----------------------------------------------------------------------
      WRITE(Fh,1010)Tbcode
 1010 FORMAT(':e.',a,/,':b.end.table',/':e.end.table')
c-----------------------------------------------------------------------
      RETURN
      END      
