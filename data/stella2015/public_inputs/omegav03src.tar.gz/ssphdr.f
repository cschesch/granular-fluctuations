C     Last change:  BCM  22 May 2007 12:05 pm
      SUBROUTINE ssphdr(Iagr,Ncol,Nlen,Ssfxrg,Nssfxr,Lyy,Lyy2,
     &                  Ssinit,Ssdiff,Lncset,Lnlset,Tblptr)
      IMPLICIT NONE
c-----------------------------------------------------------------------
C  *****  PRINTS HEADING THAT IDENTIFIES WHICH OPTIONS ARE BEING USED
C  *****  IN A GIVEN SLIDING SPANS ANALYSIS.
c-----------------------------------------------------------------------
      LOGICAL T,F
      INTEGER ZERO,MINUS1,MINUS2
      PARAMETER(ZERO=0,MINUS1=-1,MINUS2=-2,T=.true.,F=.false.)
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'ssap.prm'
      INCLUDE 'ssap.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'x11opt.cmn'
      INCLUDE 'force.cmn'
      INCLUDE 'title.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
c-----------------------------------------------------------------------
c     correct dimension length for Ssfxrg (BCM May 2007)
      CHARACTER setstr*(13)
      INTEGER Ssfxrg,Nssfxr,Ncol,Nlen,i,Iagr,Ssinit,Tblptr
      LOGICAL Lyy,Lyy2,lprt,lsav,Lncset,Lnlset,Ssdiff
      DIMENSION Ssfxrg(4)
c----------------------------------------------------------------------
      lprt = Prttab(Tblptr)
      lsav = Savtab(Tblptr)
c----------------------------------------------------------------------
c     Save sliding spans information for diagnostic program
c----------------------------------------------------------------------
      IF(lsav)THEN
       WRITE(Nform,1021)'sspans','yes'
       WRITE(Nform,1010)Ncol,Nlen,Im,Iyr
       WRITE(Nform,1020)(Cut(i,1),i=1,5)
       IF(Itd.eq.1)THEN
        WRITE(Nform,1021)'sstd','yes'
       ELSE
        WRITE(Nform,1021)'sstd','no'
       END IF
       IF(Ssdiff)THEN
        WRITE(Nform,1021)'ssdiff','yes'
       ELSE
        WRITE(Nform,1021)'ssdiff','no'
       END IF
      END IF
      IF(.not.lprt)RETURN
c-----------------------------------------------------------------------
      IF(Laccss)CALL insacd(Mt1,'p',T)
      IF(Iagr.eq.5)THEN
       WRITE(Mt1,1030)' : Direct seasonal adjustment'
      ELSE
       WRITE(Mt1,1030)' '
      END IF
      IF(Laccss)THEN
       CALL insacd(Mt1,'p',F)
       CALL insmrk(Mt1,Tblptr,T,F)
      END IF
      WRITE(Mt1,1040)
c----------------------------------------------------------------------
      IF(Lncset)THEN
       setstr = '(set by user)'
      ELSE
       setstr = '             '
      END IF
      WRITE(Mt1,1070)'Number',Ncol,setstr
      IF(Lnlset)THEN
       setstr = '(set by user)'
      ELSE
       setstr = '             '
      END IF
      WRITE(Mt1,1070)'Length',Nlen,setstr
c----------------------------------------------------------------------
      IF(Nsea.eq.12)THEN
       WRITE(Mt1,1080)Im,Iyr
       IF(Ic.gt.(Im+Nsea))WRITE(Mt1,1090)Icm,Icyr
      ELSE IF(Nsea.eq.4)THEN
       WRITE(Mt1,1100)Im,Iyr
       IF(Ic.gt.(Im+Nsea))WRITE(Mt1,1110)Icm,Icyr
      END IF
c-----------------------------------------------------------------------
      WRITE(Mt1,1120)Serno
c-----------------------------------------------------------------------
      IF(Itd.eq.1)WRITE(Mt1,1050)
      IF((Itd.eq.1.or.Ihol.eq.1.or.Muladd.eq.1).and.Iyrt.gt.0)
     &   WRITE(MT1,1060)
c-----------------------------------------------------------------------
      IF(Lyy.and.Lyy2)THEN
       WRITE(Mt1,1061)' for direct and indirect seasonal adjustments.'
      ELSE IF(Lyy2) THEN
       WRITE(Mt1,1061)' for indirect seasonal adjustments only.'
      ELSE IF(Lyy.and.Iagr.eq.5) THEN
       WRITE(Mt1,1061)' for direct seasonal adjustments only.'
      ELSE IF(Lyy) THEN
       WRITE(Mt1,1061)'.'
      END IF
c----------------------------------------------------------------------
      IF(Ssinit.eq.1)THEN
       WRITE(Mt1,1139)
      ELSE IF(Nssfxr.gt.0)THEN
       WRITE(Mt1,1140)
       DO i=1,Nssfxr
        IF(Ssfxrg(i).eq.1)THEN
         WRITE(Mt1,1141)'Trading Day'
        ELSE IF(Ssfxrg(i).eq.2)THEN
         WRITE(Mt1,1141)'Holiday'
        ELSE IF(Ssfxrg(i).eq.3)THEN
         WRITE(Mt1,1141)'User-defined regressors'
        ELSE IF(Ssfxrg(i).eq.4)THEN
         WRITE(Mt1,1141)'Outliers'
        END IF
       END DO
      END IF
c----------------------------------------------------------------------
      IF(Laccss)THEN
       CALL insmrk(Mt1,Tblptr,F,F)
       CALL insacd(Mt1,'p',T)
      END IF
      IF(Ncol.lt.4)THEN
       IF(Lncset)THEN
        WRITE(Mt1,1130)'By choice of the user'
       ELSE
        WRITE(Mt1,1130)'Due to the series length'
       END IF
      END IF
      IF(Itd.EQ.MINUS1.and.Ihol.le.ZERO)THEN
       WRITE(Mt1,2000)
       WRITE(Mt2,2000)
      ELSE IF(Ihol.EQ.MINUS1.and.Itd.le.ZERO)THEN
       WRITE(Mt1,2001)
       WRITE(Mt2,2001)
      END IF
      IF(Itd.eq.MINUS2.and.IHOL.eq.MINUS2)THEN
       WRITE(Mt1,2002)'trading day and holiday'
      ELSE IF(Itd.eq.MINUS2)THEN
       WRITE(Mt1,2002)'trading day'
      ELSE IF(Ihol.eq.MINUS2)THEN
       WRITE(Mt1,2002)'holiday'
      END IF
      IF(Laccss)CALL insacd(Mt1,'p',F)
c-----------------------------------------------------------------------
 1010 FORMAT('ssa: ',4I5)
 1020 FORMAT('sscut: ',5F7.2)
 1021 FORMAT(a,': ',a)
 1030 FORMAT(//,'  Sliding spans analysis',a,//)
 1040 FORMAT('  S 0.   Summary of options selected for this run',//)
 1050 FORMAT('  Trading day factors analyzed')
 1060 FORMAT('  Seasonally adjusted series with revised yearly totals',
     &       ' used in this analysis.')
 1061 FORMAT('  Year-to-year changes analyzed',a)
 1070 FORMAT('  ',a,' of spans : ',i5,3x,a)
 1080 FORMAT('  Month of first observation in first span : ',i5,/,
     &       '  Year  of first observation in first span : ',i5)
 1090 FORMAT('  Month of first observation used in sliding spans ',
     &       'comparison : ',i5,/,
     &       '  Year  of first observation used in sliding spans ',
     &       'comparison : ',i5)
 1100 FORMAT('  Quarter of first observation in first span : ',i5,/,
     &       '  Year    of first observation in first span : ',i5)
 1110 FORMAT('  Quarter of first observation used in sliding spans ',
     &       'comparison : ',i5,/,
     &       '  Year    of first observation used in sliding spans ',
     &       'comparison : ',i5)
 1120 FORMAT('  Name of series being adjusted : ',a8)
 1130 FORMAT(/,' WARNING: ',a,', fewer than four spans have been used',
     &       /,10x,'to compile the measures generated below.',//,
     &       10x,'In this situation, the threshold values used to ',
     &       'determine',/,
     &       10x,'adjustability (15%, 25%, 40%) which appear with ',
     &       'the summary',/,
     &       10x,'tables should be lowered.')
 1139 FORMAT('  regARIMA model coefficients held fixed during ',
     &       'sliding spans analysis.')
 1140 FORMAT('  Regressors held fixed during sliding spans analysis:')
 1141 FORMAT('    -  ',a)
 2000 FORMAT(/,' NOTE: Since the trading day coefficients are fixed ',
     &       'in the sliding spans',/,
     &       '       analysis, the trading day statistics of the ',
     &       'sliding spans analysis',/,'       are not printed.',
     &    //,'       In addition, the spans statistics for the ',
     &       'seasonally adjusted',/,
     &       '       series have the same values as the ',
     &       'corresponding statistics',/,
     &       '       for the seasonal factors.  In this case, the ',
     &       'statistics for the',/,
     &       '       seasonally adjusted series are not printed.',/)
 2001 FORMAT(/,' NOTE: Since the holiday coefficients are fixed in ',
     &       'the sliding spans analysis,',/,
     &       '       the spans statistics for the seasonally adjusted ',
     &       'series have',/,
     &       '       the same values as the corresponding statistics ',
     &       'for the seasonal',/,
     &       '       factors.  In this case, the statistics for the ',
     &       'seasonally adjusted',/,
     &       '       series are not printed.',/)
 2002 FORMAT(/,' ERROR: Length of sliding span is too short for ',
     &         a,' estimation.',
     &       /,'        At least five years of data are needed.')
      RETURN
      END
