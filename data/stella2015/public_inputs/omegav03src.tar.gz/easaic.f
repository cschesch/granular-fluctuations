C     Last change:  BCM  30 Jul 2008 4:04 pm
      SUBROUTINE easaic(Trnsrs,A,Nefobs,Na,Frstry,Lester,Lprtit,Ptrstp,
     &                  Ptrfm,Ptrsvl,Lsumm,Lhiddn)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Estimate a number of regARIMA model, each with either no easter
c     effect or an easter effect with length 1, 8, or 15.  This routine
c     chooses the model with the lowest value of AICC and prints out the
c     resulting model.
c-----------------------------------------------------------------------
      LOGICAL F,T
      PARAMETER(F=.false.,T=.true.)
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'arima.cmn'
      INCLUDE 'lkhd.cmn'
      INCLUDE 'extend.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'adj.cmn'
      INCLUDE 'title.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
      INCLUDE 'x11adj.cmn'
      INCLUDE 'prior.prm'
      INCLUDE 'prior.cmn'
      INCLUDE 'error.cmn'
      INCLUDE 'svllog.prm'
      INCLUDE 'svllog.cmn'
c-----------------------------------------------------------------------
      INTEGER PA
      PARAMETER(PA=PLEN+2*PORDER)
c-----------------------------------------------------------------------
      LOGICAL lprt,Lprtit,Lester,argok,lhide,Lsavlg,Lhiddn
      DOUBLE PRECISION A,aicbst,Trnsrs
      INTEGER Frstry,i,Na,Nefobs,begcol,ncol,easgrp,Lsumm,Ptrstp,Ptrfm,
     &        Ptrsvl,pptrfm
      DIMENSION A(PA),Trnsrs(PLEN)
c-----------------------------------------------------------------------
      INTEGER strinx
      EXTERNAL strinx
c-----------------------------------------------------------------------
c     Initialize variables
c-----------------------------------------------------------------------
      IF(Ptrstp.eq.0)THEN
       lprt=F
      ELSE
       lprt=Prttab(Ptrstp)
      END IF
      pptrfm=Ptrfm
      IF(Ptrstp.eq.0)pptrfm=0
      IF(Ptrsvl.eq.0)THEN
       lsavlg=F
      ELSE
       lsavlg=Svltab(Ptrsvl)
      END IF
      IF(.not.lprt)THEN
       lhide=Lhiddn
       Lhiddn=T
      END IF
c-----------------------------------------------------------------------
      IF(lsavlg.and.Laccss)CALL insacd(Ng,'regression.ats.lkhd',T)
c-----------------------------------------------------------------------
c     Start loop through model choices
c-----------------------------------------------------------------------
      DO i=1,Neasvc
c-----------------------------------------------------------------------
c     See if there is an easter effect in the model
c-----------------------------------------------------------------------
       easgrp=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Easter')
       IF(easgrp.eq.0)easgrp=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                              'StatCanEaster')
c-----------------------------------------------------------------------
c     If easter regressor in model, delete regressor from model
c-----------------------------------------------------------------------
       IF(easgrp.gt.0)THEN
        begcol=Grp(easgrp-1)
        ncol=Grp(easgrp)-begcol
        CALL dlrgef(begcol,Nrxy,ncol)
        IF(Lfatal)THEN
         IF(lsavlg.and.Laccss)CALL insend(Ng,'regression.ats.lkhd')
         RETURN
        END IF
       END IF
c-----------------------------------------------------------------------
c     If i > 1, add new easter regressor to model
c-----------------------------------------------------------------------
       IF(i.gt.1.or.easgrp.gt.0)THEN
        IF(i.gt.1)
     &     CALL addaic(Aicstk,Aicrgm,Tdzero,Easvec(i)+Easidx,Sp,0,T,
     &                 Easidx)
        IF(.not.Lfatal)
     &     CALL regvar(Trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,
     &                 Nrusrx,Priadj,Reglom,Nrxy,Begxy,Frstry,T,Elong)
        IF(Lfatal)THEN
         IF(lsavlg.and.Laccss)CALL insend(Ng,'regression.ats.lkhd')
         RETURN
        END IF
       END IF
c-----------------------------------------------------------------------
c     Estimate model
c-----------------------------------------------------------------------
       argok=Lautom.or.Lautox
       CALL rgarma(T,Mxiter,Mxnlit,F,A,Na,Nefobs,argok)
       IF((.not.Lfatal).and.(Lautom.or.Lautox).and.(.not.argok))
     &    CALL abend()
       IF(Lfatal)THEN
        IF(lsavlg.and.Laccss)CALL insend(Ng,'regression.ats.lkhd')
        RETURN
       END IF
c-----------------------------------------------------------------------
c     If an estimation error is found, discontinue the routine.
c-----------------------------------------------------------------------
       IF(Armaer.eq.PMXIER.or.Armaer.eq.PSNGER.or.Armaer.eq.PISNER.or.
     &    Armaer.eq.PNIFER.or.Armaer.eq.PNIMER.or.Armaer.eq.PCNTER.or.
     &    Armaer.lt.0.or.((Lautom.or.Lautox).and.(.not.argok)))THEN
        Lester=T
        IF(lsavlg.and.Laccss)CALL insacd(Ng,'regression.ats.lkhd',F)
        RETURN
c-----------------------------------------------------------------------
c     If only a warning message would be printed out, reset the error
c     indicator variable to zero.
c-----------------------------------------------------------------------
       ELSE IF(Armaer.ne.0)THEN
        Armaer=0
       END IF
c-----------------------------------------------------------------------
c     Compute the likelihood statistics and AICC for the model
c-----------------------------------------------------------------------
       IF(lprt)THEN
        IF(Laccss)CALL insacd(Mt1,'regression.ats.hdr',T)
        IF(i.eq.1)THEN
         WRITE(Mt1,1010)
        ELSE
         IF(Easidx.eq.0)THEN
          WRITE(Mt1,1020)'Easter',Easvec(i)
         ELSE
          WRITE(Mt1,1020)'StatCanEaster',Easvec(i)
         END IF
        END IF
        IF(Laccss)CALL insacd(Mt1,'regression.ats.hdr',F)
       END IF
       IF(i.eq.Neasvc)THEN
        CALL prlkhd(Y(Frstsy),Adj(Adj1st),Adjmod,Fcntyp,Lam,0,Ptrstp,
     &              pptrfm)
       ELSE
        CALL prlkhd(Y(Frstsy),Adj(Adj1st),Adjmod,Fcntyp,Lam,0,Ptrstp,0)
       END IF
       IF(Lfatal)THEN
        IF(lsavlg.and.Laccss)CALL insend(Ng,'regression.ats.lkhd')
        RETURN
       END IF
c-----------------------------------------------------------------------
c     See if this AICC is the smallest.  If so, update value and index
c     of best AICC.
c-----------------------------------------------------------------------
       IF(i.eq.1)THEN
        aicbst=Aicc
        Aicind=0
        IF(Lsavlg)WRITE(Ng,1011)Aicc
        IF(Lsumm.gt.0)WRITE(Nform,1013)'noeaster',Aicc
       ELSE
        IF(Easidx.eq.0)THEN
         IF(Lsavlg)WRITE(Ng,1012)'easter',Easvec(i),Aicc
         IF(Lsumm.gt.0)WRITE(Nform,1014)'easter',Easvec(i),Aicc
        ELSE
         IF(Lsavlg)WRITE(Ng,1012)'sceaster',Easvec(i),Aicc
         IF(Lsumm.gt.0)WRITE(Nform,1014)'sceaster',Easvec(i),Aicc
        END IF
        IF((Aicind.eq.0.AND.(Aicc+Rgaicd).lt.aicbst).OR.
     &     (Aicind.gt.0.AND.Aicc.lt.aicbst))THEN
         aicbst=Aicc
         Aicind=Easvec(i)
        END IF
       END IF
      END DO
      IF(.not.lprt)Lhiddn=lhide
c-----------------------------------------------------------------------
c     Show Easter effect that aic prefers
c-----------------------------------------------------------------------
      IF(lprt)THEN
       IF(Laccss)CALL insacd(Mt1,'regression.ats.lkf',T)
       IF(Aicind.eq.0)THEN
        WRITE(Mt1,1030)Rgaicd
        IF(Finhol)Finhol=F
       ELSE
        IF(Easidx.eq.0)THEN
         WRITE(Mt1,1040)Rgaicd,'Easter',Aicind
        ELSE
         WRITE(Mt1,1040)Rgaicd,'Statistics Canada Easter',Aicind
        END IF
       END IF
       IF(Laccss)CALL insacd(Mt1,'regression.ats.lkf',F)
      END IF
c-----------------------------------------------------------------------
c     If model with best AICC wasn't the last one estimated, redo model
c     estimation so the best model is returned.
c-----------------------------------------------------------------------
      IF(aicind.lt.Easvec(Neasvc))THEN
       easgrp=strinx(T,Grpttl,Grpptr,1,Ngrptl,'Easter')
       IF(easgrp.eq.0)easgrp=strinx(T,Grpttl,Grpptr,1,Ngrptl,
     &                              'StatCanEaster')
       begcol=Grp(easgrp-1)
       ncol=Grp(easgrp)-begcol
       CALL dlrgef(begcol,Nrxy,ncol)
c-----------------------------------------------------------------------
c     Add new Easter variable, if necessary
c-----------------------------------------------------------------------
       IF(.not.Lfatal.and.aicind.gt.0)
     &    CALL addaic(Aicstk,Aicrgm,Tdzero,aicind+Easidx,Sp,0,T,Easidx)
c-----------------------------------------------------------------------
c     Estimate model
c-----------------------------------------------------------------------
       IF(.not.Lfatal)
     &    CALL regvar(Trnsrs,Nobspf,Fctdrp,Nfcst,0,Userx,Bgusrx,Nrusrx,
     &                Priadj,Reglom,Nrxy,Begxy,Frstry,T,Elong)
       IF(.not.Lfatal)
     &    CALL rgarma(T,Mxiter,Mxnlit,Lprtit,A,Na,Nefobs,argok)
       IF((.not.Lfatal).and.(Lautom.or.Lautox).and.(.not.argok))
     &    Lester=T
      END IF
c-----------------------------------------------------------------------
      IF(lsavlg.and.Laccss)CALL insacd(Ng,'regression.ats.lkhd',F)
c-----------------------------------------------------------------------
 1010 FORMAT(//,' Likelihood statistics for model without Easter')
 1011 FORMAT(' AICC(no easter)  : ',f15.4)
 1012 FORMAT(' AICC(',a,'[',i2,']) : ',f15.4)
 1013 FORMAT('aictest.e.aicc.',a,': ',e29.15)
 1014 FORMAT('aictest.e.aicc.',a,i2.2,': ',e29.15)
 1020 FORMAT(//,' Likelihood statistics for model with ',a,'[',i2,']')
 1030 FORMAT(//,'   *****   AICC (with aicdiff=',F5.2,
     &          ') prefers model without Easter   *****')
 1040 FORMAT(//,'   *****   AICC (with aicdiff=',F5.2,
     &          ') prefers model with ',a,'[',i2,']   *****')
c-----------------------------------------------------------------------
      RETURN
      END

