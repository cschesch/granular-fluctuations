C     Last change:  BCM  18 Oct 2004 12:18 pm
      SUBROUTINE prtchi(Lprchi,Lprhdr,Tbwdth,Lsvchi,Baselt,Grpstr,Nchr,
     &                  Info,Df,Chi2vl,Pv)
      IMPLICIT NONE
c-----------------------------------------------------------------------
      LOGICAL F
      PARAMETER(F=.false.)
c     ------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'notset.prm'
      INCLUDE 'title.cmn'
      INCLUDE 'units.cmn'
c-----------------------------------------------------------------------
      CHARACTER Grpstr*(PGRPCR)
      LOGICAL Lprchi,Lprhdr,Lsvchi
      INTEGER Tbwdth,Baselt,Nchr,Info,Df,i
      DOUBLE PRECISION Chi2vl,Pv
c-----------------------------------------------------------------------
      IF(Lprhdr)THEN
       IF(.not.Lcmpaq)WRITE(Mt1,'()')
       WRITE(Mt1,1010)
       WRITE(Mt1,1020)('-',i=1,tbwdth)
       WRITE(Mt1,1030)
       WRITE(Mt1,1020)('-',i=1,tbwdth)
       Lprhdr=F
      END IF
c-----------------------------------------------------------------------
      IF(Lsvchi.and.baselt.ne.NOTSET)
     &   WRITE(Nform,1040)Grpstr(1:Nchr),Df,Chi2vl,Pv
c-----------------------------------------------------------------------
      IF(Lprchi)THEN
       IF(Info.eq.0)THEN
        IF(Baselt.eq.NOTSET)THEN
         WRITE(Mt1,1080)Grpstr(1:Nchr)
        ELSE
         IF(Nchr.gt.34)THEN
          WRITE(Mt1,1050)Grpstr(1:Nchr),Df,Chi2vl,Pv
         ELSE
          WRITE(Mt1,1060)Grpstr(1:Nchr),Df,Chi2vl,Pv
         END IF
        END IF
c-----------------------------------------------------------------------
       ELSE
        WRITE(Mt1,1070)Grpstr(1:Nchr)
       END IF
      END IF
c-----------------------------------------------------------------------
      RETURN
c-----------------------------------------------------------------------
 1010 FORMAT(/,' Chi-squared Tests for Groups of Regressors')
 1020 FORMAT(' ',120(a))
 1030 FORMAT(' Regression Effect',t37,'df',t45,'Chi-Square',t61,
     &        'P-Value')
 1040 FORMAT('chi$',a,': ',i4,2(1x,e22.15))
 1050 FORMAT(' ',a,/,t35,i4,f16.2,f13.2)
 1060 FORMAT(' ',a,t35,i4,f16.2,f13.2)
 1070 FORMAT(' ',a,t52,'Not tested')
 1080 FORMAT(' ',a,t41,'All coefficients fixed')
c-----------------------------------------------------------------------
	  END
