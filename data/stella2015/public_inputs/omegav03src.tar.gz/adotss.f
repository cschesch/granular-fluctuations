C     Last change:  BCM  18 Oct 2004 12:18 pm
      SUBROUTINE adotss(Botr,Otrptr,Notrtl,Fixotr,Otrttl,Lastsy,Otlfix)
      IMPLICIT NONE
c-----------------------------------------------------------------------
      LOGICAL T,F
      PARAMETER(T=.true.,F=.false.)
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'arima.cmn'
      INCLUDE 'error.cmn'
c-----------------------------------------------------------------------
      CHARACTER Otrttl*(PCOLCR*PB),str*(PCOLCR)
      LOGICAL Fixotr,locok,Otlfix,fx,lastLS
      DOUBLE PRECISION Botr
      INTEGER Otrptr,Notrtl,icol,nch,endcol,otltyp,begotl,endotl,rtype,
     &        Lastsy,otypvc,otlind,nlast
      DIMENSION Otrptr(0:PB),Botr(PB),Fixotr(PB),otypvc(POTLR+1)
c-----------------------------------------------------------------------
      INTEGER strinx
      EXTERNAL strinx
c-----------------------------------------------------------------------
      DATA otypvc/PRGTAO,PRGTLS,PRGTTC,PRGTRP/
c-----------------------------------------------------------------------
      endcol=Notrtl
      icol=1
      nlast=0
      lastLS=F
      DO WHILE(icol.le.endcol)
       CALL getstr(Otrttl,Otrptr,Notrtl,icol,str,nch)
       IF(Lfatal)RETURN
       otlind=strinx(T,Grpttl,Grpptr,1,Ngrptl,str(1:nch))
       IF(otlind.eq.0)THEN
        CALL rdotlr(str(1:nch),Begsrs,Sp,otltyp,begotl,endotl,locok)
c-----------------------------------------------------------------------
c     Check to see if outlier is defined. If so, then add outlier
c     to regression.
c-----------------------------------------------------------------------
        IF((otltyp.eq.RP.and.(begotl.ge.Frstsy.and.endotl.le.Lastsy))
     &     .or.
     &     (otltyp.ne.RP.and.(begotl.ge.Frstsy.and.begotl.le.Lastsy)))
     &     THEN
         fx=Fixotr(icol).or.Otlfix
         CALL adrgef(Botr(icol),str(1:nch),str(1:nch),otypvc(otltyp),
     &               fx,F)
         IF(Iregfx.eq.3.and.(.not.fx))Iregfx=2
         IF(otltyp.ne.RP.and.(begotl.eq.Lastsy))THEN
          nlast=nlast+1
          IF(.not.lastLS)lastLS=otltyp.eq.LS
         END IF
        END IF
        IF(Lfatal)RETURN
       END IF
       icol=icol+1
      END DO
c-----------------------------------------------------------------------
c   if more than one outlier appears on the final observation, delete
c   outliers that will cause singularities in the regression matrix.
c-----------------------------------------------------------------------
      IF(nlast.gt.1)THEN
       icol=Nb
       DO WHILE(icol.ge.1)
        rtype=Rgvrtp(icol)
        IF(rtype.eq.PRGTAO.or.rtype.eq.PRGTAA.or.rtype.eq.PRGTLS.or.
     &     rtype.eq.PRGTAL.or.rtype.eq.PRGTTC.or.rtype.eq.PRGTAT)THEN
         CALL getstr(Colttl,Colptr,Nb,icol,str,nch)
         IF(Lfatal)RETURN
         CALL rdotlr(str(1:nch),Begsrs,Sp,otltyp,begotl,endotl,locok)
         IF(otltyp.ne.RP.and.begotl.eq.Lastsy)THEN
          IF((otltyp.eq.TC.and.((.not.lastLS).or.nlast.eq.3)).or.
     &       otltyp.eq.LS)THEN
           CALL dlrgef(icol,Nrxy,1)
           IF(Lfatal)RETURN
          END IF
         END IF
        END IF
        icol=icol-1
       END DO
      END IF
c-----------------------------------------------------------------------
      RETURN
      END
