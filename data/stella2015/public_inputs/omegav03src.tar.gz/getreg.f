C     Last change:  BCM  30 Jul 2008 4:04 pm
      SUBROUTINE getreg(Begsrs,Nobs,Havsrs,Havesp,Userx,Nrusrx,Bgusrx,
     &                  Itdtst,Leastr,Luser,Elong,Adjtd,Adjao,Adjls,
     &                  Adjtc,Adjhol,Adjsea,Adjusr,Nusrrg,Havtca,
     &                  Rgaicd,Lam,Fcntyp,Havhol,Inptok)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     getreg.f, Release 1, Subroutine Version 1.6, Modified 03 Feb 1995.
c-----------------------------------------------------------------------
c     Specify the regression and time series parts of the model
c-----------------------------------------------------------------------
c     Code added to incorporate automatic TD selection
c     BCM - January 1994
c-----------------------------------------------------------------------
      INCLUDE 'stdio.i'
      INCLUDE 'lex.i'
      INCLUDE 'notset.prm'
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'tbllog.i'
      INCLUDE 'svllog.i'
      INCLUDE 'usrreg.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'error.cmn'
c     ------------------------------------------------------------------
      DOUBLE PRECISION ONE,ZERO
      LOGICAL F,T
      PARAMETER(ONE=1D0,ZERO=0D0,F=.false.,T=.true.)
c     ------------------------------------------------------------------
      CHARACTER effttl*(PCOLCR),rgfile*(PFILCR),rgfmt*(PFILCR)
      LOGICAL argok,Havesp,havfmt,Havsrs,haveux,hvfile,hvstrt,hvuttl,
     &        Inptok,Leastr,Elong,havtd,Havhol,havln,havlp,Luser,Havtca,
     &        lumean,luseas,fixvec
      INTEGER Bgusrx,Begsrs,i,j,k,idisp,itmpvc,nchr,nelt,nflchr,nfmtch,
     &        neltux,Nobs,Nrusrx,peltux,Itdtst,ivec,igrp,i2,n2,k2,ispn,
     &        Adjtd,Adjao,Adjls,Adjtc,Adjhol,Adjsea,Adjusr,Nusrrg,nbvec,
     &        icol,ic1,Fcntyp,begcol,endcol
      DOUBLE PRECISION Userx,dvec,Rgaicd,urmean,urnum,bvec,Lam
      DIMENSION Bgusrx(2),Begsrs(2),itmpvc(0:1),Userx(*),ivec(1),
     &          dvec(1),urmean(PB),urnum(PB),ispn(2),fixvec(PB),bvec(PB)
c-----------------------------------------------------------------------
      INTEGER strinx
      LOGICAL chkcvr,gtarg,dpeq,istrue
      EXTERNAL strinx,chkcvr,gtarg,dpeq,istrue
c-----------------------------------------------------------------------
c     The spec dictionary was made with this command
c  ../../dictionary/strary < ../../dictionary/regression.dic
c-----------------------------------------------------------------------
      CHARACTER ARGDIC*105
      INTEGER argidx,argptr,PARG,arglog
      PARAMETER(PARG=17)
      DIMENSION argptr(0:PARG),arglog(2,PARG)
      PARAMETER(ARGDIC='variablesuserdatastartfileformatbprintsaveaictes
     &teastermeansnoapplyusertypetcrateaicdiffsavelogcenteruser')
c-----------------------------------------------------------------------
      CHARACTER YSNDIC*5
      INTEGER ysnptr,PYSN
      PARAMETER(PYSN=2)
      DIMENSION ysnptr(0:PYSN)
      PARAMETER(YSNDIC='yesno')
c     ------------------------------------------------------------------
      CHARACTER AICDIC*47
      INTEGER aicidx,aicptr,PAIC
      PARAMETER(PAIC=7)
      DIMENSION aicptr(0:PAIC),aicidx(3)
      PARAMETER(AICDIC='tdtdnolpyeartdstocktd1coeftd1nolpyeareasteruser'
     &          )
c-----------------------------------------------------------------------
      CHARACTER URGDIC*89
      INTEGER urgidx,urgptr,PURG
      PARAMETER(PURG=18)
      DIMENSION urgptr(0:PURG),urgidx(PUREG)
      PARAMETER(URGDIC='constantseasonaltdlomloqlpyeartdstocklomstockeas
     &terlaborthanksaolsrpholidaysceasterusertc')
c     ------------------------------------------------------------------
      CHARACTER MDLDIC*31
      INTEGER mdlind,mdlptr,PMODEL
      PARAMETER(PMODEL=7)
      DIMENSION mdlptr(0:PMODEL),mdlind(PMODEL)
      PARAMETER(MDLDIC='tdaolsholidayuserseasonalusertc')
c     ------------------------------------------------------------------
      CHARACTER URRDIC*12
      INTEGER urrptr,PURR
      PARAMETER(PURR=2)
      DIMENSION urrptr(0:PURR)
      PARAMETER(URRDIC='meanseasonal')
c     ------------------------------------------------------------------
      DATA argptr/1,10,14,18,23,27,33,34,39,43,50,61,68,76,82,89,96,106/
      DATA ysnptr/1,4,6/
      DATA aicptr/1,3,13,20,27,38,44,48/
      DATA urgptr/1,9,17,19,22,25,31,38,46,52,57,63,65,67,69,76,84,88,
     &            90/
      DATA mdlptr/1,3,5,7,14,26,30,32/
      DATA urrptr/1,5,13/
c-----------------------------------------------------------------------
c     Assume the input is OK and we don't have any of the arguments
c-----------------------------------------------------------------------
      peltux=PLEN*PUREG
      haveux=F
      hvuttl=F
      hvfile=F
      havfmt=F
      hvstrt=F
      nfmtch=1
      havtd=F
      Havhol=F
      havln=F
      havlp=F
      lumean=F
      luseas=F
      nbvec=NOTSET
      CALL setlg(F,PB,fixvec)
c-----------------------------------------------------------------------
      CALL setint(NOTSET,2*PARG,arglog)
      CALL setint(NOTSET,2,ispn)
c-----------------------------------------------------------------------
c     Initialize the format and file
c-----------------------------------------------------------------------
      CALL setchr(' ',PFILCR,rgfile)
      CALL setchr(' ',PFILCR,rgfmt)
c-----------------------------------------------------------------------
c     Argument get loop
c-----------------------------------------------------------------------
      DO WHILE (T)
       IF(gtarg(ARGDIC,argptr,PARG,argidx,arglog,Inptok))THEN
        IF(Lfatal)RETURN
        GO TO(10,20,30,40,50,60,70,80,90,100,110,120,130,150,160,170,
     &        140)argidx
c-----------------------------------------------------------------------
c     variables argument
c-----------------------------------------------------------------------
   10   CALL gtpdrg(Begsrs,Nobs,Havsrs,Havesp,F,havtd,Havhol,havln,
     &               havlp,argok,Inptok)
c        IF(.not.Lfatal.and.(Picktd.and.(Fcntyp.ne.4.and.
c     &    (.not.dpeq(Lam,1D0)))))
c     &    CALL rmlnvr(Priadj,Nobs)
        IF(Lfatal)RETURN
        GO TO 180
c-----------------------------------------------------------------------
c     Names and number of columns for the user regression variables
c-----------------------------------------------------------------------
   20   CALL gtnmvc(LPAREN,T,PUREG,Usrttl,Usrptr,Ncusrx,argok,Inptok)
        IF(Lfatal)RETURN
        hvuttl=argok.and.Ncusrx.gt.0
        GO TO 180
c-----------------------------------------------------------------------
c     Data argument
c-----------------------------------------------------------------------
   30   IF(hvfile)CALL inpter(PERROR,Errpos,'Getting data from a file')
c     ------------------------------------------------------------------
        CALL gtdpvc(LPAREN,T,peltux,Userx,neltux,argok,Inptok)
        IF(Lfatal)RETURN
        haveux=argok.and.neltux.gt.0
        GO TO 180
c-----------------------------------------------------------------------
c     Start argument
c-----------------------------------------------------------------------
   40   CALL gtdtvc(Havesp,Sp,LPAREN,F,1,Bgusrx,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        hvstrt=argok.and.nelt.gt.0
        GO TO 180
c-----------------------------------------------------------------------
c     File argument
c-----------------------------------------------------------------------
   50   IF(haveux)CALL inpter(PERROR,Errpos,
     &                        'Already have user regression')
        CALL gtnmvc(LPAREN,T,1,rgfile,itmpvc,neltux,argok,Inptok)
        IF(Lfatal)RETURN
c     ------------------------------------------------------------------
        IF(argok.and.neltux.gt.0)THEN
         CALL eltlen(1,itmpvc,neltux,nflchr)
         IF(Lfatal)RETURN
         hvfile=T
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     Format argument
c-----------------------------------------------------------------------
   60   CALL gtnmvc(LPAREN,T,1,rgfmt,itmpvc,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok)THEN
         nfmtch=itmpvc(1)-1
         havfmt=T
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     Initial values for the regression.  May want to change this
c later so that the betas only need take some initial values instead
c of all or none.
c-----------------------------------------------------------------------
   70   CALL gtrgvl(nbvec,fixvec,bvec,Inptok)
        IF(Lfatal)RETURN
        GO TO 180
c-----------------------------------------------------------------------
c     Print argument
c-----------------------------------------------------------------------
   80   CALL getprt(LSPREG,NSPREG,Inptok)
        GO TO 180
c-----------------------------------------------------------------------
c     Save argument
c-----------------------------------------------------------------------
   90   CALL getsav(LSPREG,NSPREG,Inptok)
        GO TO 180
c-----------------------------------------------------------------------
c     aictest argument
c-----------------------------------------------------------------------
  100   CALL gtdcvc(LPAREN,F,3,AICDIC,aicptr,PAIC,'Choices for aictest a
     &re td, tdnolpyear, tdstock, td1coef, td1nolpyear',
     &              aicidx,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(.not.argok)
     &     CALL writln('        user, and easter.',STDERR,Mt2,F)
        IF(argok)THEN
         DO i=1,nelt
          IF(aicidx(i).eq.6)THEN
           Leastr=T
c           Havhol=T
          ELSE IF(aicidx(i).eq.7)THEN
           Luser=T
          ELSE
           IF(Itdtst.eq.0)THEN
            Itdtst=aicidx(i)
c            havtd=T
           ELSE
            CALL inpter(PERROR,Errpos,
     &           'Can only specify one type of trading day in aictest.')
            Inptok=F
           END IF
          END IF
         END DO
         IF(Inptok)Iregfx=0
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     eastermeans argument
c-----------------------------------------------------------------------
  110   CALL gtdcvc(LPAREN,F,1,YSNDIC,ysnptr,PYSN,
     &              'Choices for eastermeans are yes and no.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)Elong=ivec(1).eq.1
        GO TO 180
c-----------------------------------------------------------------------
c     noapply argument
c-----------------------------------------------------------------------
  120   CALL gtdcvc(LPAREN,T,PMODEL,MDLDIC,mdlptr,PMODEL,'Choices for th
     &e noapply argument are td, ao, ls, holiday, or user.',
     &              mdlind,nelt,argok,Inptok)
        IF(Lfatal)RETURN
c     ------------------------------------------------------------------
        IF(argok.and.nelt.gt.0)THEN
         DO i=1,nelt
          IF(mdlind(i).eq.1)THEN
           Adjtd=-1
          ELSE IF(mdlind(i).eq.2)THEN
           Adjao=-1
          ELSE IF(mdlind(i).eq.3)THEN
           Adjls=-1
          ELSE IF(mdlind(i).eq.4)THEN
           Adjhol=-1
          ELSE IF(mdlind(i).eq.5)THEN
           Adjsea=-1
          ELSE IF(mdlind(i).eq.6)THEN
           Adjusr=-1
          ELSE IF(mdlind(i).eq.7)THEN
           Adjtc=-1
          END IF
         END DO
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     usertype argument
c-----------------------------------------------------------------------
  130   CALL gtdcvc(LPAREN,F,PUREG,URGDIC,urgptr,PURG,
     &              'Improper entry for usertype.  See '//SPCSEC//
     &              ' of '//DOCNAM//'.',urgidx,Nusrrg,argok,Inptok)
        IF(Lfatal)RETURN
c     ------------------------------------------------------------------
        IF(argok.and.Nusrrg.gt.0)THEN
         DO i=1,Nusrrg
          IF(urgidx(i).eq.1)THEN
           Usrtyp(i)=PRGTCN
          ELSE IF(urgidx(i).eq.2)THEN
           Usrtyp(i)=PRGTUS
          ELSE IF(urgidx(i).eq.3)THEN
           Usrtyp(i)=PRGTTD
           IF(.not.havtd)havtd=T
          ELSE IF(urgidx(i).eq.4)THEN
           Usrtyp(i)=PRGTLM
           IF(.not.havln)havln=T
          ELSE IF(urgidx(i).eq.5)THEN
           Usrtyp(i)=PRGTLQ
           IF(.not.havln)havln=T
          ELSE IF(urgidx(i).eq.6)THEN
           Usrtyp(i)=PRGTLY
           IF(.not.havlp)havlp=T
          ELSE IF(urgidx(i).eq.7)THEN
           Usrtyp(i)=PRGTST
           havtd=T
          ELSE IF(urgidx(i).eq.8)THEN
           Usrtyp(i)=PRGTSL
          ELSE IF(urgidx(i).eq.9)THEN
           Usrtyp(i)=PRGTEA
           Havhol=T
          ELSE IF(urgidx(i).eq.10)THEN
           Usrtyp(i)=PRGTLD
           Havhol=T
          ELSE IF(urgidx(i).eq.11)THEN
           Usrtyp(i)=PRGTTH
           Havhol=T
          ELSE IF(urgidx(i).eq.12)THEN
           Usrtyp(i)=PRGTAO
          ELSE IF(urgidx(i).eq.13)THEN
           Usrtyp(i)=PRGTLS
          ELSE IF(urgidx(i).eq.14)THEN
           Usrtyp(i)=PRGTRP
          ELSE IF(urgidx(i).eq.15)THEN
           Usrtyp(i)=PRGTUH
           Havhol=T
          ELSE IF(urgidx(i).eq.16)THEN
           Usrtyp(i)=PRGTES
           Havhol=T
          ELSE IF(urgidx(i).eq.17.or.urgidx(i).eq.NOTSET)THEN
           Usrtyp(i)=PRGTUD
          ELSE IF(urgidx(i).eq.18)THEN
           Usrtyp(i)=PRGTTC
          END IF
         END DO
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     centeruser argument
c-----------------------------------------------------------------------
  140   CALL gtdcvc(LPAREN,F,1,URRDIC,urrptr,PURR,
     &              'Choices for centeruser are mean and seasonal.',
     &              ivec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)THEN
         lumean=ivec(1).eq.1
         luseas=ivec(1).eq.2
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     tcrate - alpha value for all TC outliers
c-----------------------------------------------------------------------
  150   IF(Havtca)THEN
         CALL inpter(PERROR,Errpos,'Cannot specify tcrate in both the re
     &gression and outlier specs')
         Inptok=F
        ELSE
  	 CALL gtdpvc(LPAREN,T,1,dvec,nelt,argok,Inptok)
         IF(Lfatal)RETURN
         IF(argok.and.nelt.gt.0)THEN
          IF(dvec(1).le.ZERO.or.dvec(1).ge.ONE)THEN
           CALL inpter(PERROR,Errpos,
     &                 'Value of tcrate must be between 0 and 1.')
           Inptok=F
          ELSE
           Tcalfa=dvec(1)
           Havtca=T
          END IF
         END IF
        END IF
        GO TO 180
c-----------------------------------------------------------------------
c     AIC test difference for the regression-based AIC test
c-----------------------------------------------------------------------
  160   CALL gtdpvc(LPAREN,T,1,dvec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(nelt.gt.0.and.argok)Rgaicd=dvec(1)
        GO TO 180
c-----------------------------------------------------------------------
c     savelog  argument
c-----------------------------------------------------------------------
  170   CALL getsvl(LSLREG,NSLREG,Inptok)
        GO TO 180
       END IF
c-----------------------------------------------------------------------
       IF(nbvec.ne.NOTSET)THEN
c-----------------------------------------------------------------------
c     Insert value for Leap Year regressor that will be removed
c-----------------------------------------------------------------------
        IF(Picktd.and.(Fcntyp.ne.4.and.(.not.dpeq(Lam,1D0))))THEN
         ic1=1
         icol=strinx(T,Colttl,Colptr,ic1,Nb,'Leap Year')
         DO WHILE (icol.gt.0)
          IF(icol.le.nbvec)THEN
           DO i=nbvec,icol,-1
            bvec(i+1)=bvec(i)
            fixvec(i+1)=fixvec(i)
           END DO
          END IF
          Bvec(icol)=ONE
          nbvec=nbvec+1
          IF(icol.eq.Nb)THEN
           icol=0
          ELSE
           ic1=icol+1
           icol=strinx(T,Colttl,Colptr,ic1,Nb,'Leap Year')
          END IF
         END DO
        END IF       
        IF(nbvec.gt.0.and.nbvec.NE.(Nb+Ncusrx))THEN
         WRITE(STDERR,1000)
         WRITE(Mt2,1000)
 1000    FORMAT(' ERROR: Number of initial values is not the same as ',
     &          'the number of regression',/,'        variables.')
        ELSE
         DO i=1,Nb+Ncusrx
          Regfx(i)=fixvec(i)
          B(i)=bvec(i)
         END DO
        END IF
       END IF
c     ------------------------------------------------------------------
c     If the data are from the file get the data
c-----------------------------------------------------------------------
       IF(Inptok.and.hvfile.and..not.haveux)THEN
        IF(Ncusrx.gt.0)THEN
         CALL gtfldt(peltux,rgfile,nflchr,havfmt,rgfmt(1:nfmtch),2,
     &               Userx,neltux,Havesp,Sp,F,' ',0,F,' ',0,0,hvstrt,
     &               Bgusrx,Ncusrx,ispn,ispn,T,haveux,Inptok)
        ELSE
         WRITE(STDERR,1010)
         WRITE(Mt2,1010)
        END IF
       END IF
c-----------------------------------------------------------------------
c     Check for the required arguments
c-----------------------------------------------------------------------
       IF(Inptok.and.(hvuttl.or.haveux))THEN
        IF(.not.(hvuttl.eqv.haveux))THEN
         WRITE(STDERR,1010)
         WRITE(Mt2,1010)
 1010    FORMAT(/,' ERROR: Need to specify both user-defined ',
     &            'regression variables (with user',/,
     &            '        argument) and X matrix (with file or data ',
     &            'argument).')
         Inptok=F
c     ------------------------------------------------------------------
        ELSE IF(mod(neltux,Ncusrx).ne.0)THEN
         WRITE(STDERR,1020)neltux,Ncusrx
         WRITE(Mt2,1020)neltux,Ncusrx
 1020    FORMAT(/,' ERROR: Number of user-defined X elements=',i4,
     &          /,'        not equal to a multiple of the number of ',
     &            'columns=',i3,'.',/)
         Inptok=F
c     ------------------------------------------------------------------
        ELSE
         IF(.not.hvstrt)CALL cpyint(Begsrs,2,1,Bgusrx)
         Nrusrx=neltux/Ncusrx
         IF(.not.chkcvr(Bgusrx,Nrusrx,Begspn,Nspobs,Sp))THEN
          CALL cvrerr('user-defined regression variables',Bgusrx,Nrusrx,
     &                'span of the data',Begspn,Nspobs,Sp)
          IF(Lfatal)RETURN
          Inptok=F
c     ------------------------------------------------------------------
         ELSE
          idisp=Grp(Ngrp)-1
          DO i=1,Ncusrx
           idisp=idisp+1
           CALL getstr(Usrttl,Usrptr,Ncusrx,i,effttl,nchr)
           IF(.not.Lfatal)
     &        CALL adrgef(B(idisp),effttl(1:nchr),'User-defined',PRGTUD,
     &                    Regfx(idisp),T)
           IF(Lfatal)RETURN
          END DO
c     ------------------------------------------------------------------
c     estimate and Remove either regressor mean or seasonal mean
c     ------------------------------------------------------------------
          IF(lumean)THEN
           CALL setdp(ZERO,PB,urmean)
           DO i=1,neltux
            i2=MOD(i,Ncusrx)
            IF(i2.eq.0)i2=Ncusrx
            urmean(i2)=urmean(i2)+Userx(i)
           END DO
           DO i=1,Ncusrx
            urmean(i)=urmean(i)/DBLE(Nrusrx)
           END DO
           DO i=1,neltux
            i2=MOD(i,Ncusrx)
            IF(i2.eq.0)i2=Ncusrx
            Userx(i)=Userx(i)-urmean(i2)
           END DO
          ELSE IF(luseas)THEN
           n2=Sp*Ncusrx
           DO i=1,Sp
            CALL setdp(ZERO,PB,urmean)
            CALL setdp(ZERO,PB,urnum)
            i2=(i-1)*Ncusrx+1
            DO j=i2,neltux,n2
             DO k=j,Ncusrx+j-1
              k2=MOD(k,Ncusrx)
              IF(k2.eq.0)k2=Ncusrx
              urmean(k2)=urmean(k2)+Userx(k)
              urnum(k2)=urnum(k2)+ONE
             END DO
            END DO
            DO j=1,Ncusrx
             urmean(j)=urmean(j) / urnum(j)
            END DO
            DO j=i2,neltux,n2
             DO k=j,Ncusrx+j-1
              k2=MOD(k,Ncusrx)
              IF(k2.eq.0)k2=Ncusrx
              Userx(k)=Userx(k)-urmean(k2)
             END DO
            END DO
           END DO
          END IF
c     ------------------------------------------------------------------
         END IF
        END IF
       END IF
       IF(Lfatal)RETURN
       IF(Nb.gt.0)THEN
c-----------------------------------------------------------------------
c     check user-defined regression type selection.  First, check to 
c     see if user-defined regression variables are defined.
c-----------------------------------------------------------------------
        IF(Nusrrg.gt.0)THEN
         igrp=strinx(F,Grpttl,Grpptr,1,Ngrptl,'User-Defined')
         IF(igrp.eq.0)THEN
          WRITE(STDERR,1030)
          WRITE(Mt2,1030)
 1030     FORMAT(' ERROR: Cannot specify group types for ',
     &           'user-defined regression',/,
     &           '        variables if user-defined regression ',
     &           'variables are not',/,
     &           '        defined in the regression spec.')
          Inptok=F
         END IF
         CALL eltlen(igrp,Grp,Ngrp,Ncusrx)
         IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     If only one type given, use it for all user-defined regression 
c     variables.
c-----------------------------------------------------------------------
         IF(Nusrrg.eq.1)THEN
          DO i=2,Ncusrx
           Usrtyp(i)=Usrtyp(1)
          END DO
         END IF
        END IF
c-----------------------------------------------------------------------
c     Check if the regression model parameters are fixed.  Sets iregfx.
c-----------------------------------------------------------------------
        CALL regfix()
c     ------------------------------------------------------------------
c     set indicator variable for fixed user defined regressors.
c     ------------------------------------------------------------------
        Userfx=F
        IF(Ncusrx.gt.0.and.Iregfx.ge.2)THEN
         IF(Iregfx.eq.3)THEN
          Userfx=T
         ELSE
          igrp=strinx(F,Grpttl,Grpptr,1,Ngrptl,'User-Defined')
          begcol=Grp(igrp-1)
          endcol=Grp(igrp)-1
          Userfx=istrue(Regfx,begcol,endcol)
         END IF
        END IF
c-----------------------------------------------------------------------
c     sort outlier regressors specified by the user, if any.
c-----------------------------------------------------------------------
        CALL otsort()
       END IF
c-----------------------------------------------------------------------
       IF(Itdtst.gt.0.and.(.not.havtd))havtd=T
       IF(Leastr.and.(.not.Havhol))Havhol=T
       IF(Adjtd.eq.1.and.(.NOT.(havtd.or.havln.or.havlp)))Adjtd=0
       IF(Adjhol.eq.1.and.(.not.Havhol))Adjhol=0
c-----------------------------------------------------------------------
       RETURN
  180  CONTINUE
      END DO
c     -----------------------------------------------------------------
      END
