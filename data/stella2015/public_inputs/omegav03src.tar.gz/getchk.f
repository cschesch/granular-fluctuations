C     Last change:  BCM  28 Aug 2007 8:17 am
      SUBROUTINE getchk(Mxcklg,Acflim,Sp,Inptok)
c     ------------------------------------------------------------------
      IMPLICIT NONE
c     ------------------------------------------------------------------
      INCLUDE 'lex.i'
      INCLUDE 'notset.prm'
      INCLUDE 'tbllog.i'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
      INCLUDE 'svllog.i'
      INCLUDE 'mdltbl.i'
      INCLUDE 'hiddn.cmn'
      INCLUDE 'error.cmn'
c     ------------------------------------------------------------------
      LOGICAL F,T
      DOUBLE PRECISION ZERO
      PARAMETER(ZERO=0.0D0,F=.false.,T=.true.)
c     ------------------------------------------------------------------
      DOUBLE PRECISION Acflim,dvec
      LOGICAL argok,Inptok
      INTEGER Mxcklg,nelt,ivec,Sp
      DIMENSION dvec(1),ivec(1)
c-----------------------------------------------------------------------
      LOGICAL gtarg
      EXTERNAL gtarg
c-----------------------------------------------------------------------
c     Argument dictionary was made with the following command
c ../../dictionary/strary < ../../dictionary/check.dic
c-----------------------------------------------------------------------
      CHARACTER ARGDIC*30
      INTEGER arglog,argidx,argptr,PARG
      PARAMETER(PARG=5)
      DIMENSION argptr(0:PARG),arglog(2,PARG)
      PARAMETER(ARGDIC='maxlagprintsavesavelogacflimit')
c-----------------------------------------------------------------------
      DATA argptr/1,7,12,16,23,31/
c-----------------------------------------------------------------------
c     If Mxcklg is 0 if check{} is not specified and the acf's and
c pacf's are not printed out so Mxcklg is set to the default 36
c (for monthly; 12 for quarterly series)
c when check is specified.  Whether or not the histogram and
c summary statistics are printed out is controled by the prttab
c switch.  It is off in the default table set in gtinpt and is
c turned on by default here.
c-----------------------------------------------------------------------
      argok=T
      IF(.not.Lnoprt)THEN
       Prttab(LCKHST)=T
       Prttab(LCKNRM)=T
      END IF
      Mxcklg=Sp*2
      CALL setint(NOTSET,2*PARG,arglog)
c-----------------------------------------------------------------------
c     Argument get loop
c-----------------------------------------------------------------------
      DO WHILE (T)
       IF(gtarg(ARGDIC,argptr,PARG,argidx,arglog,argok))THEN
        IF(Lfatal)RETURN
        GO TO(10,20,30,40,50),argidx
c-----------------------------------------------------------------------
c     Number of acf and pacf lags to calculate and print out
c-----------------------------------------------------------------------
   10   CALL getivc(LPAREN,T,1,ivec,nelt,argok,Inptok)
        Mxcklg=ivec(1)
        IF(Lfatal)RETURN
        GO TO 60
c-----------------------------------------------------------------------
c     Print argument
c-----------------------------------------------------------------------
   20   CALL getprt(LSPCHK,NSPCHK,Inptok)
        GO TO 60
c-----------------------------------------------------------------------
c     Save argument
c-----------------------------------------------------------------------
   30   CALL getsav(LSPCHK,NSPCHK,Inptok)
        GO TO 60
c-----------------------------------------------------------------------
c     savelog  argument
c-----------------------------------------------------------------------
   40   CALL getsvl(LSLCHK,NSLCHK,Inptok)
        GO TO 60
c-----------------------------------------------------------------------
c     acflimit argument
c-----------------------------------------------------------------------
   50   CALL gtdpvc(LPAREN,T,1,dvec,nelt,argok,Inptok)
        IF(Lfatal)RETURN
        IF(argok.and.nelt.gt.0)THEN
         IF(dvec(1).le.ZERO)THEN
          CALL inpter(PERROR,Errpos,
     &                'Value of acflimit must be greater than 0.')
          Inptok=F
         ELSE
          Acflim=dvec(1)
         END IF
        END IF
        GO TO 60
       END IF
c     -----------------------------------------------------------------
       RETURN
   60  CONTINUE
      END DO
      END
