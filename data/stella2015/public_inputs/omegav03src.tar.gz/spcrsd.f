C     Last change:  BCM  28 Aug 2007 4:34 pm
      SUBROUTINE spcrsd(A,Na,Begrsd,Sp,Endspn,Tblptr,Lsumm,Lgraf)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Routine which computes the spectrum for the regARIMA model
c     residuals.  If there are peaks detected at the trading day or
c     seasonal frequencies, these are noted.
c-----------------------------------------------------------------------
c     AR-Spectrum routines originally appeared in the BAYSEA program,
c     developed by H. Akaike and G. Kitagawa of the Institute for
c     Statistical Mathematics.
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'notset.prm'
      INCLUDE 'tbltitle.prm'
      INCLUDE 'stdio.i'
      INCLUDE 'units.cmn'
      INCLUDE 'error.cmn'
      INCLUDE 'rho.cmn'
      INCLUDE 'title.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
c-----------------------------------------------------------------------
      INTEGER IONE,SIXONE,IZERO,ITEN,PA,NTDLIM
      LOGICAL F,T
      PARAMETER(F=.false.,T=.true.,IONE=1,SIXONE=61,IZERO=0,ITEN=10,
     &          NTDLIM=60,PA=PLEN+2*PORDER)
c-----------------------------------------------------------------------
      CHARACTER begstr*(10),ctype*(19),endstr*(10),ttl*(PTTLEN),
     &          pkstr*(24)
      DOUBLE PRECISION A,frq,Temp,rsdsxx,tmpsxx,pklim,star1
      INTEGER Begrsd,Endspn,frqidx,i,ipos,Na,ltdrsd,lsrsd,nchr1,nchr2,
     &        ntype,icode,numttl,Sp,ipk,Tblptr,Lsumm,domfqt,domfqs,
     &        fhnote
      LOGICAL gorsd,Lgraf,ltdfrq
      DIMENSION A(PA),Begrsd(2),frq(61),Temp(PA),rsdsxx(61),tmpsxx(61),
     &          Endspn(2),ttl(2),numttl(2)
c-----------------------------------------------------------------------
      LOGICAL dpeq
      INTEGER ispeak,smpeak
      EXTERNAL dpeq,ispeak,smpeak
c-----------------------------------------------------------------------
      fhnote=STDERR
      IF(Lquiet)fhnote=0
c-----------------------------------------------------------------------
      DO i=1,61
       frq(i)=dble(i-1)/120D0
      END DO
      IF(Sp.eq.12)THEN
c       frq(36)=.3036-frq(2)
c       frq(37)=.3036
c       frq(38)=.3036+frq(2)
       frq(42)=.3482D0-frq(2)
       frq(43)=.3482D0
       frq(44)=.3482D0+frq(2)
       frq(52)=.432D0-frq(2)
       frq(53)=.432D0
       frq(54)=.432D0+frq(2)
       frqidx=1
      ELSE IF(Sp.eq.4)THEN
       frq(5)=.0446D0-frq(2)
       frq(6)=.0446D0
       frq(7)=.0446D0+frq(2)
       frq(11)=.0893D0-frq(2)
       frq(12)=.0893D0
       frq(13)=.0893D0+frq(2)
       frqidx=2
      ELSE
       CALL writln('ERROR: Spectral plots currently can only be generate
     &d for monthly or',STDERR,Mt2,T)
       CALL writln('       quarterly time series.',STDERR,Mt2,F)
       RETURN
      END IF
c-----------------------------------------------------------------------
c     Get relative position of starting point for spectrums
c-----------------------------------------------------------------------
      CALL dfdate(Bgspec,Begrsd,Sp,ipos)
      IF(ipos.lt.0)THEN
       ipos=1
       CALL wrtdat(Begrsd,Sp,begstr,nchr1)
      ELSE
       ipos=ipos+1
       CALL wrtdat(Bgspec,Sp,begstr,nchr1)
      END IF
      IF(.not.Lfatal)CALL wrtdat(Endspn,Sp,endstr,nchr2)
      IF(Lfatal)RETURN
c-----------------------------------------------------------------------
      gorsd=T
      ltdfrq=(Na-ipos+1).gt.NTDLIM
      CALL copy(A,Na,-1,Temp)
      IF(Spctyp.eq.0)THEN
       CALL spgrh(Temp,rsdsxx,frq,Thtapr,ipos,Na,Sp,Mxarsp,gorsd)
      ELSE
c-----------------------------------------------------------------------
c     Else, compute the periodogram for the regARIMA model residuals
c-----------------------------------------------------------------------
       CALL spgrh2(Temp,rsdsxx,frq,ipos,Na)
      END IF
c-----------------------------------------------------------------------
c     Save spectrum of the regARIMA model residuals
c-----------------------------------------------------------------------
      IF(Savtab(Tblptr).and.gorsd)
     &   CALL savspp(Tblptr,rsdsxx,frq,'Spectrum_Rsd',F)
      IF(.not.Lfatal.and.Lgraf.and.gorsd)
     &   CALL savspp(Tblptr,rsdsxx,frq,'Spectrum_Rsd',Lgraf)
      IF(Lfatal)RETURN
c-----------------------------------------------------------------------
      IF(.not.gorsd)RETURN
c-----------------------------------------------------------------------
      ltdrsd=0
      lsrsd=0
      CALL copy(rsdsxx,61,1,tmpsxx)
      CALL shlsrt(61,tmpsxx)
      pklim=(tmpsxx(61)-tmpsxx(1))*(Spclim/52D0)
      IF(ltdfrq)ltdrsd=ispeak(rsdsxx,frqidx,pklim,tmpsxx(31),1)
      lsrsd=ispeak(rsdsxx,frqidx+2,pklim,tmpsxx(31),Peakwd)
      IF(Lsumm.gt.0)THEN
       star1=(tmpsxx(61)-tmpsxx(1))/52D0
       domfqt=NOTSET
       IF(ltdfrq)domfqt=smpeak(rsdsxx,frqidx,star1,tmpsxx(31),Nform,
     &                         'spcrsd')
       domfqs=smpeak(rsdsxx,frqidx+2,star1,tmpsxx(31),Nform,'spcrsd')
       CALL mxpeak(rsdsxx,frqidx,domfqt,domfqs,tmpsxx(61),Nform,
     &             'spcrsd')
      END IF
c-----------------------------------------------------------------------
      IF(ltdrsd.gt.0.and.lsrsd.gt.0.and.Prttab(Tblptr))THEN
       CALL writln('WARNING: Visually significant seasonal and trading d
     &ay peaks have ',fhnote,Mt2,T)
       CALL writln('         been found in the estimated spectrum of the
     & regARIMA residuals.',fhnote,Mt2,F)
       pkstr='trading day and seasonal'
       ipk=24
      ELSE IF(ltdrsd.gt.0.and.Prttab(Tblptr))THEN
       CALL writln('WARNING: At least one visually significant trading d
     &ay peak has been',fhnote,Mt2,T)
       CALL writln('         found in the estimated spectrum of the regA
     &RIMA residuals.',fhnote,Mt2,F)
       pkstr='trading day'
       ipk=11
      ELSE IF(lsrsd.gt.0.and.Prttab(Tblptr))THEN
       CALL writln('WARNING: At least one visually significant seasonal 
     &peak has been found',fhnote,Mt2,T)
       CALL writln('         in the estimated spectrum of the regARIMA r
     &esiduals.',fhnote,Mt2,F)
       pkstr='seasonal'
       ipk=8
      END IF
c-----------------------------------------------------------------------
      IF((lsrsd.gt.0.or.ltdrsd.gt.0))THEN
       IF(Prttab(Tblptr))THEN
        IF(Laccss)CALL insacd(Mt1,'peak.warning.residuals',T)
        IF(ltdrsd.gt.0.and.lsrsd.gt.0)THEN
         WRITE(Mt1,1020)'V',pkstr(1:ipk),'have',begstr(1:nchr1)
         WRITE(Mt1,1040)'regARIMA model residuals',lsrsd,ltdrsd
        ELSE
         WRITE(Mt1,1020)'At least one v',pkstr(1:ipk),'has',
     &                  begstr(1:nchr1)       
         IF(ltdrsd.gt.0)THEN
          WRITE(Mt1,1030)'regARIMA model residuals',ltdrsd
         ELSE IF(lsrsd.gt.0)THEN
          WRITE(Mt1,1050)'regARIMA model residuals',lsrsd
         END IF
        END IF
        IF(Laccss)CALL insacd(Mt1,'peak.warning.residuals',F)
       END IF
       IF(Svpeak)THEN
        IF(ltdrsd.gt.0)THEN
         Ctpeak((Ntpeak+1):(Ntpeak+3))='rsd'
         Ntpeak=Ntpeak+4
        END IF
        IF(lsrsd.gt.0)THEN
         Cspeak((Nspeak+1):(Nspeak+3))='rsd'
         Nspeak=Nspeak+4
        END IF
       END IF
      END IF
c-----------------------------------------------------------------------
c     Spectrum plot for detrended original series
c-----------------------------------------------------------------------
      IF(.not.Prttab(Tblptr))RETURN
      icode=20
      IF(.not.ltdfrq)icode=21
      IF(Spctyp.eq.0)THEN
       ctype='10*LOG(SPECTRUM)'
       ntype=16
      ELSE
       ctype='10*LOG(PERIODOGRAM)'
       ntype=19
      END IF
      IF((ltdrsd.gt.0.or.ltdrsd.gt.0).and.Prttab(Tblptr))
     &   WRITE(Mt1,'(//)')
      ttl(1)='G Rs '//ctype(1:ntype)//
     &       ' of the regARIMA model residuals.'
      numttl(1)=ntype+37
      ttl(2)='     Spectrum estimated from '//begstr(1:nchr1)//
     &       ' to '//endstr(1:nchr2)//'.'
      numttl(2)=34+nchr1+nchr2
      IF(Prttab(Tblptr).and.Laccss)CALL insmrk(Mt1,Tblptr,T,F)
      CALL grzlst(IONE,SIXONE,IZERO,rsdsxx,rsdsxx,SIXONE,ITEN,IZERO)
      CALL chrt(ttl,numttl,icode,1,120/Sp)
      IF(Prttab(Tblptr).and.Laccss)CALL insmrk(Mt1,Tblptr,F,F)
c-----------------------------------------------------------------------
 1020 FORMAT(//,2x,a,'isually significant residual ',a,' peaks ',a,
     &          ' been',
     &        /,'  found in the spectral plot of the following series',
     &          ' starting in ',a,':',/)
 1030 FORMAT(10x,a,' (',i1,' Trading Day peak(s))',/)
 1040 FORMAT(10x,a,' (',i1,' Seasonal and ',i1,' Trading Day peak(s))',
     &       /)
 1050 FORMAT(10x,a,' (',i1,' Seasonal peak(s))',/)
c 1070 FORMAT(/,'          Rerun the input file without the output ',
c     &         'suppression option',/,
c     &         '          (-n flag) for more details.')
c-----------------------------------------------------------------------
      RETURN
      END
