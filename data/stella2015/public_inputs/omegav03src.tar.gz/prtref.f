C     Last change:  BCM  18 Oct 2004 12:18 pm
      SUBROUTINE prtref(Begxy,Nrxy,Lprtre,Lsavre,Ftd,Fhol,Fao,Fls,Ftc,
     &                  Fusr,Fsea,Fmv,Nusrrg)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     prtref.f, Release 1, Subroutine Version 1.5, Modified 20 Oct 1994.
c-----------------------------------------------------------------------
c    Computes regression adjustments for the groups of regression
c variables and the regression residuals.  The groups are:  the
c constant, seasonal effects, trading day, holiday, ao outliers,
c ls's and ramps, and user-defined effects.  The adjustments
c are done on the prior-adjusted and transformed scale.
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'mdltbl.i'
      INCLUDE 'usrreg.cmn'
      INCLUDE 'error.cmn'
c     ------------------------------------------------------------------
      INTEGER PTTL
      PARAMETER(PTTL=13)
c     ------------------------------------------------------------------
      CHARACTER str*(PCOLCR),ttlstr*(120)
      DOUBLE PRECISION txy,Ftd,Fhol,Fao,Fls,Ftc,Fusr,Fmv,Fsea,dvec
      LOGICAL Finao,Finhol,Lprtre,Lsavre,Finls,Fintc,Finusr
      INTEGER Adjtd,Adjhol,Adjao,Adjls,Adjsea,Adjusr,begeff,Begxy,
     &        endeff,i,icol,ieff,irgeff,nchr,neff,Nrxy,nttl,regeff,
     &        rgefpt,rgeftp,ttlptr,rtype,iusr,Nusrrg,Adjtc
      DIMENSION Begxy(2),regeff(9),rgefpt(0:11),rgeftp(42),Ftd(PLEN),
     &          Fao(PLEN),Fls(PLEN),Ftc(PLEN),Fusr(PLEN),Fhol(PLEN),
     &          Fmv(PLEN),ttlptr(0:PTTL),txy(PLEN*PTTL),Fsea(PLEN),
     &          dvec(1)
c-----------------------------------------------------------------------
      COMMON /x11adj/ Adjtd,Adjhol,Adjao,Adjls,Adjtc,Adjsea,Adjusr,
     &                Finhol,Finao,Finls,Fintc,Finusr
c-----------------------------------------------------------------------
c     Get the names from
c  ../dictionary/strary REF <../dictionary/effects.dic
c-----------------------------------------------------------------------
      CHARACTER REFDIC*107
      INTEGER refptr,PREF
      PARAMETER(PREF=11)
      DIMENSION refptr(0:PREF)
      PARAMETER(REFDIC='SeasonalTrading DayLength-of-MonthLength-of-Quar
     &terLeap YearHolidayAOLS and RampTCUser-DefinedMissing Value')
      DATA refptr / 1,9,20,35,52,61,68,70,81,83,95,108 /
c-----------------------------------------------------------------------
c*x12      DATA rgefpt/1,3,7,8,9,12,14,17,18/
c****      DATA rgefpt/1,3,6,8,9,12,14,17,18/
      DATA rgefpt/1,8,17,23,26,29,34,36,39,41,42,43/
      DATA rgeftp/PRGTSE,PRGTTS,PRGTUS,PRRTSE,PRRTTS,PRATSE,PRATTS,
     &            PRGTTD,PRGTST,PRRTTD,PRRTST,PRATTD,PRATST,PRG1TD,
     &            PRR1TD,PRA1TD,PRGTSL,PRRTSL,PRATSL,PRGTLM,PRRTLM,
     &            PRATLM,PRGTLQ,PRRTLQ,PRATLQ,PRGTLY,PRRTLY,PRATLY,
     &            PRGTEA,PRGTES,PRGTLD,PRGTTH,PRGTUH,PRGTAO,PRGTAA,
     &            PRGTLS,PRGTRP,PRGTAL,PRGTTC,PRGTAT,PRGTUD,PRGTMV/
c-----------------------------------------------------------------------
c     Initialize the titles
c-----------------------------------------------------------------------
      CALL intlst(PTTL,ttlptr,nttl)
c-----------------------------------------------------------------------
c     Find which regression effects there are.
c-----------------------------------------------------------------------
      DO irgeff=1,PREF
       begeff=rgefpt(irgeff-1)
       endeff=rgefpt(irgeff)-1
       DO icol=1,Nb
        DO ieff=begeff,endeff
         IF(Rgvrtp(icol).eq.rgeftp(ieff))THEN
          CALL getstr(REFDIC,refptr,PREF,irgeff,str,nchr)
          IF(.not.Lfatal)CALL insstr(str(1:nchr),nttl+1,PTTL,ttlstr,
     &                               ttlptr,nttl)
          IF(Lfatal)RETURN
          regeff(nttl)=irgeff
          GO TO 10
         END IF
        END DO
       END DO
   10  CONTINUE
      END DO
c-----------------------------------------------------------------------
c     Total regression effects
c-----------------------------------------------------------------------
      CALL insstr('Total Reg',nttl+1,PTTL,ttlstr,ttlptr,nttl)
c-----------------------------------------------------------------------
c     Regression residuals
c-----------------------------------------------------------------------
      IF(.not.Lfatal)CALL insstr('Reg Resids',nttl+1,PTTL,ttlstr,ttlptr,
     &                           nttl)
      IF(Lfatal)RETURN
c-----------------------------------------------------------------------
c     Calculate the factors.
c-----------------------------------------------------------------------
      neff=nttl-2
      dvec(1)=0.0D0
      DO i=1,neff
       CALL dcopy(Nrxy,dvec,0,txy(i),nttl)
       irgeff=regeff(i)
       begeff=rgefpt(irgeff-1)
       endeff=rgefpt(irgeff)-1
c-----------------------------------------------------------------------
c     Find the next column of the given regression effect type
c-----------------------------------------------------------------------
       DO icol=1,Nb
        DO ieff=begeff,endeff
         IF(Rgvrtp(icol).eq.rgeftp(ieff))THEN
          CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,txy(i),nttl)
          GO TO 20
         END IF
        END DO
   20   CONTINUE
       END DO
      END DO
c-----------------------------------------------------------------------
c     Calculate the total regression effects
c-----------------------------------------------------------------------
      CALL dcopy(Nrxy,dvec,0,txy(nttl-1),nttl)
c      CALL setdp(0D0,Nrxy,txy(nttl-1))
      DO icol=1,neff
       CALL daxpy(Nrxy,1D0,txy(icol),nttl,txy(nttl-1),nttl)
      END DO
c-----------------------------------------------------------------------
c     Calculate the regression residuals
c-----------------------------------------------------------------------
      CALL dcopy(Nrxy,Xy(Ncxy),Ncxy,txy(nttl),nttl)
      CALL daxpy(Nrxy,-1D0,txy(nttl-1),nttl,txy(nttl),nttl)
c     ------------------------------------------------------------------
      IF(Lprtre)THEN
       CALL prtmtx(Begxy,Sp,txy,Nrxy,nttl,ttlstr,ttlptr,nttl)
       IF(Lfatal)RETURN
      END IF
c     ------------------------------------------------------------------
      IF(Lsavre)THEN
       CALL savmtx(LESTRE,Begxy,Sp,txy,Nrxy,nttl,ttlstr,ttlptr,nttl)
       IF(Lfatal)RETURN
      END IF
c     ------------------------------------------------------------------
c     Generate prior adjustment factors.  First, determine type of 
c     regression variable
c-----------------------------------------------------------------------
      iusr=1
      DO icol=1,Nb
       rtype=Rgvrtp(icol)
       IF(Nusrrg.gt.0)THEN
        IF(rtype.eq.PRGTUD)THEN
         rtype=Usrtyp(iusr)
         iusr=iusr+1
        ELSE IF(rtype.eq.PRGTUH.or.rtype.eq.PRGTUS)THEN
         iusr=iusr+1
        END IF
       END IF
c-----------------------------------------------------------------------
c     Generate regARIMA trading day factors
c-----------------------------------------------------------------------
       IF(Adjtd.eq.1.and.
     &   ((rtype.eq.PRGTTD.or.rtype.eq.PRGTST.or.rtype.eq.PRRTTD.or.
     &    rtype.eq.PRRTST.or.rtype.eq.PRATTD.or.rtype.eq.PRATST.or.
     &    rtype.eq.PRG1TD.or.rtype.eq.PRR1TD.or.rtype.eq.PRA1TD).or.
     &    (rtype.eq.PRGTLM.or.rtype.eq.PRGTSL.or.rtype.eq.PRGTLQ.or.
     &    rtype.eq.PRGTLY.or.rtype.eq.PRRTLM.or.rtype.eq.PRRTSL.or.
     &    rtype.eq.PRRTLQ.or.rtype.eq.PRRTLY.or.rtype.eq.PRATLM.or.
     &    rtype.eq.PRATSL.or.rtype.eq.PRATLQ.or.rtype.eq.PRATLY)))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Ftd,1)
c-----------------------------------------------------------------------
c     Generate regARIMA holiday factors
c-----------------------------------------------------------------------
       IF(((Adjhol.eq.1).or.Finhol).and.
     &    (rtype.eq.PRGTEA.or.rtype.eq.PRGTLD.or.rtype.eq.PRGTTH.or.
     &     rtype.eq.PRGTES.or.rtype.eq.PRGTUH))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Fhol,1)
c-----------------------------------------------------------------------
c     Generate regARIMA User-defined regression factors 
c-----------------------------------------------------------------------
       IF(((Adjusr.eq.1).or.Finusr).and.(rtype.eq.PRGTUD))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Fusr,1)
c-----------------------------------------------------------------------
c     Generate regARIMA seasonal regression factors 
c-----------------------------------------------------------------------
       IF((Adjsea.eq.1).and.(rtype.eq.PRGTUS))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Fsea,1)
c-----------------------------------------------------------------------
c     Generate regARIMA AO outlier factors 
c-----------------------------------------------------------------------
       IF(((Adjao.eq.1).or.Finao).and.
     &   (rtype.eq.PRGTAO.or.rtype.eq.PRGTAA))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Fao,1)
c-----------------------------------------------------------------------
c     Generate regARIMA Level Change Outlier factors 
c-----------------------------------------------------------------------
       IF(((Adjls.eq.1).or.Finls).and.(rtype.eq.PRGTLS.or.
     &    rtype.eq.PRGTRP.or.rtype.eq.PRGTAL))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Fls,1)
c-----------------------------------------------------------------------
c     Generate regARIMA Temporary Change Outlier factors
c-----------------------------------------------------------------------
       IF(((Adjtc.eq.1).or.Fintc).and.(rtype.eq.PRGTTC.or.
     &    rtype.eq.PRGTAT))
     &    CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Ftc,1)
c-----------------------------------------------------------------------
c     Generate regARIMA MV outlier factors 
c-----------------------------------------------------------------------
       IF(rtype.eq.PRGTMV)CALL daxpy(Nrxy,B(icol),Xy(icol),Ncxy,Fmv,1)
c-----------------------------------------------------------------------
      END DO
c-----------------------------------------------------------------------
      RETURN
      END
