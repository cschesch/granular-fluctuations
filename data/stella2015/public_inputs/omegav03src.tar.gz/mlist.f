C     Last change:  BCM  10 May 2007 8:28 am
**==mlist.f    processed by SPAG 4.03F  at 12:23 on 21 Jun 1994
      SUBROUTINE mlist(X,Nopt,Nop2,Dmax,N48,Iagr,Ext,Eststr,Nstr,Ncol,Y,
     &                 Period,Ssdiff,Ispan)
      IMPLICIT NONE
c-----------------------------------------------------------------------
C  *****  PRINTS OUT EACH OBSERVATION IN SLIDING SPANS ANALYSIS, WITH
C  *****  DATE, ESTIMATES (EXAMPLE, SEASONAL FACTORS) FOR EACH SPAN,
C  *****  MAXIMUM PERCENTAGE DIFFERENCE (DMAX), AND AN INDICATION OF
C  *****  WHETHER THE OBSERVATION WAS FLAGGED AS AN EXTREME (PER)
C  *****  OR CHANGED DIRECTION (CSIGN).
c-----------------------------------------------------------------------
      LOGICAL T,F
      PARAMETER(T=.TRUE.,F=.FALSE.)
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
      INCLUDE 'notset.prm'
      INCLUDE 'ssap.prm'
      INCLUDE 'ssap.cmn'
C      INCLUDE 'sspvec.cmn'
      INCLUDE 'units.cmn'
      INCLUDE 'title.cmn'
c-----------------------------------------------------------------------
      DOUBLE PRECISION Dmax,X
      LOGICAL Ssdiff,l2Big
      CHARACTER cagr*(31),Eststr*(45),Ext*(2),fstr*(7),bascod*(80),
     &          blank8*(8),dash*(1),fnotvc*(10),tbllbl*(5)
      INTEGER i,Iagr,iy,l,l0,l1,l2,Nstr,m,N48,Nop2,Nopt,Y,Period,nagr,
     &        Ncol,fnotky,nssky,Ispan,nbscod
      DIMENSION dash(3),X(MXLEN,MXCOL),Dmax(MXLEN,NEST),fstr(3),
     &          Y(2*MXCOL),Period(2*MXCOL),
     &          fnotvc(MXLEN),fnotky(7)
c-----------------------------------------------------------------------
      LOGICAL dpeq
      EXTERNAL dpeq
c-----------------------------------------------------------------------
      DATA dash/'-','/',' '/
      DATA fstr/'MAXIMUM',' % DIFF','   DIFF'/
c-----------------------------------------------------------------------
      iy=Iyr
      m=Im-1
      IF(Iagr.eq.5)THEN
       cagr=': Direct seasonal adjustment.'
       nagr=29
      ELSE IF(Iagr.eq.6)THEN
       cagr=': Indirect seasonal adjustment.'
       nagr=31
      ELSE
       cagr='.'
       nagr=1
      END IF
      IF(Laccss)THEN
       tbllbl='  S7.'
      ELSE
       tbllbl='S  7.'
      END IF
      blank8='        '
c-----------------------------------------------------------------------
      IF(Laccss)CALL insmrk(Mt1,Ispan,T,F)
c-----------------------------------------------------------------------
c  Check to see if series is too large to be printed - if so,
c  switch to scientific format.
c  added by BCM Dec 2005
c-----------------------------------------------------------------------
      l2Big=.false.
      IF(Nopt.ge.3.or.Ssdiff)THEN
       DO l1=1,Ncol
        DO l2=Im,Sslen+Im-1
         IF(.not.dpeq(X(l2,l1),DNOTST))THEN
          IF(X(l2,l1).gt.999999.99D0 .or. X(l2,l1).lt.-99999.99D0)
     &       l2Big=.true.
          IF(l2Big)GO TO 1000
         END IF
        END DO
       END DO
      END IF
 1000 CONTINUE
c-----------------------------------------------------------------------
c     Generate footnotes for table (BCM, December 2006)
c-----------------------------------------------------------------------
      CALL ssfnot(Nopt,Nop2,fnotvc,fnotky,nssky)
c-----------------------------------------------------------------------
c     Print out complete sliding spans information, with up to 48
c     observations on a page.
c     Changed 11-2005 BCM - print all together if the -a option is used.
c-----------------------------------------------------------------------
      DO l0=1,N48
       l1=(l0-1)*48+Im
       l2=l0*48+Im-1
       IF(l0.eq.N48)l2=Sslen+Im-1
       IF(Lpage)THEN
        WRITE(Mt1,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
       IF((.not.Laccss).or.(l0.eq.1))THEN
        WRITE(Mt1,1020)tbllbl,Ext,Eststr(1:Nstr),Serno(1:Nser),
     &                 cagr(1:nagr)
 1020   FORMAT(' ',a,a2,'  Sliding spans analysis of ',a,' for ',a,a)
        WRITE(Mt1,1030)
        WRITE(Mt1,F2)(Period(i),dash(2),Y(i),dash(1),i=1,Ncol),fstr(1),
     &                blank8
        IF(Nop2.eq.0.AND.(.not.Ssdiff))THEN
         WRITE(Mt1,F2)(Period(Ncol+i),dash(2),Y(Ncol+i),dash(3),
     &                 i=1,Ncol),fstr(2),'Footnote'
        ELSE
         WRITE(Mt1,F2)(Period(Ncol+i),dash(2),Y(Ncol+i),dash(3),
     &                 i=1,Ncol),fstr(3),'Footnote'
        END IF
        WRITE(Mt1,1030)
 1030   FORMAT(' ')
       END IF
       DO l=l1,l2
        m=m+1
        IF(m.gt.Nsea)THEN
         m=1
         iy=iy+1
        END IF
        CALL wrtmss(m,iy,X,Dmax,Ncol,Nopt,l,fnotvc(l),l2big)
       END DO
      END DO
c-----------------------------------------------------------------------
      IF(Laccss)CALL insmrk(Mt1,Ispan,F,F)
c-----------------------------------------------------------------------
      IF(nssky.gt.0)THEN
       IF(Laccss)THEN
        CALL getmrk(Ispan,F,bascod,nbscod)
        CALL insacd(Mt1,bascod(1:nbscod)//'.key',T)
       END IF
c-----------------------------------------------------------------------
c  Print header for footnotes on separate page
c-----------------------------------------------------------------------
       IF(Lpage)THEN
        WRITE(Mt1,Ttlfmt)Newpg,Title(1:Ntitle),Kpage,Serno(1:Nser)
        Kpage=Kpage+1
       END IF
       WRITE(Mt1,1040)Ext,Eststr(1:Nstr),Serno(1:Nser),cagr(1:nagr)
 1040  FORMAT('  Footnotes for Table S7.',a2,':',/,
     &        '  Sliding spans analysis of ',a,' for ',a,a,/)
       CALL mkssky(fnotky,Nopt,Nop2)
       WRITE(Mt1,1030)
       IF(Laccss)CALL insacd(Mt1,bascod(1:nbscod)//'.key',F)
      END IF
c-----------------------------------------------------------------------
      RETURN
      END

