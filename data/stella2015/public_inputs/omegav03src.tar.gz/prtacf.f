C     Last change:  BCM  6 Mar 2009 3:17 pm
      SUBROUTINE prtacf(Inspc,Nefobs,A,Na,Mxlag,Lgraf,Ldiag,Ndf,Nsdf)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Calculate the ACF, PACF, and residual histogram if requested
c (Replace histogram with a QQ plot when possible)
c-----------------------------------------------------------------------
      INCLUDE 'stdio.i'
      INCLUDE 'notset.prm'
      INCLUDE 'srslen.prm'
      INCLUDE 'model.prm'
      INCLUDE 'model.cmn'
      INCLUDE 'mdldat.cmn'
      INCLUDE 'tbllog.prm'
      INCLUDE 'tbllog.cmn'
c      INCLUDE 'mdltbl.i'
      INCLUDE 'title.cmn'
      INCLUDE 'acfptr.prm'
      INCLUDE 'units.cmn'
      INCLUDE 'error.cmn'
      INCLUDE 'svllog.prm'
      INCLUDE 'svllog.cmn'
      INCLUDE 'mdlsvl.i'
c     ------------------------------------------------------------------
      LOGICAL F,T
      PARAMETER(F=.FALSE.,T=.true.)
c     ------------------------------------------------------------------
      LOGICAL Ldiag,Lgraf,lp2,locok
      INTEGER Inspc,Mxlag,Na,Nefobs,Ndf,Nsdf,ipcp,iacp,ipcf,iacf,np,
     &        ilag,endlag
      DOUBLE PRECISION A,seacf,smpac
      DIMENSION A(PLEN),seacf(PLEN/4),smpac(PLEN/4)
c-----------------------------------------------------------------------
      INTEGER Fhacf,Fhpcf,Fhacfg,Fhpcfg
      COMMON /cfhacf/ Fhacf,Fhpcf,Fhacfg,Fhpcfg
c     ------------------------------------------------------------------
      ipcp=Inspc+LPCP
      ipcf=Inspc+LPCF
      iacp=Inspc+LACP
      iacf=Inspc+LACF
c     ------------------------------------------------------------------
      lp2=Prttab(ipcp).or.Prttab(ipcf).or.Savtab(ipcf)
      IF(Var.le.0D0)THEN
       IF(Prttab(iacf).or.Savtab(iacf).or.Prttab(iacp).or.
     &    Svltab(LSLLBQ).or.lp2)THEN
        IF(.not.Lquiet)WRITE(STDERR,1010)
        CALL errhdr
        WRITE(Mt2,1010)
 1010   FORMAT(/,' NOTE: Can''t calculate an ACF for a model with no ',
     &           'variance.')
       END IF
       RETURN
      END IF
c     ------------------------------------------------------------------
      IF(Prttab(iacf).or.Savtab(iacf).or.Prttab(iacp).or.Svltab(LSLLBQ)
     &   .or.lp2.or.Lgraf.or.Ldiag)THEN
       IF(Prttab(iacf))THEN
        IF(Laccss)CALL insmrk(Mt1,iacf,T,F)
        CALL acfhdr(Mt1,Ndf,Nsdf,2)
       END IF
c     ------------------------------------------------------------------
       IF(Mxlag.eq.0)THEN
        IF(Sp.eq.1)THEN
         Mxlag=10
        ELSE
         Mxlag=2*Sp
        END IF
        Mxlag=min(Mxlag,Nefobs/4)
       ELSE
c     ------------------------------------------------------------------
        Mxlag=min(Mxlag,Nefobs-1)
       END IF
c     ------------------------------------------------------------------
       np=0
       endlag=Opr(Nopr)-1
       DO ilag=1,endlag
        IF(.not.Arimaf(ilag))np=np+1
       END DO
c     ------------------------------------------------------------------
       CALL acf(A(Na-Nefobs+1),Nefobs,Nefobs,smpac,seacf,Mxlag,np,Sp,T,
     &          Prttab(iacf))
       IF(Prttab(iacf))THEN
        IF(Laccss)CALL insmrk(Mt1,iacf,F,F)
        IF(Laccss)CALL insacd(Mt1,'p',T)
        WRITE(Mt1,1030)
        IF(Laccss)CALL insacd(Mt1,'p',F)
       END IF
 1030  FORMAT(/,'  The P-values approximate the probability of ',
     &          'observing a Q-value at least',
     &        /,'  this large when the model fitted is correct.  When ',
     &          'DF is positive, small',
     &        /,'  values of P, customarily those below 0.05, indicate',
     &          ' model inadequacy.',/)
       IF(Savtab(iacf))THEN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)THEN
         CALL opnfil(T,F,iacf,Fhacf,locok)
         IF(.not.locok)THEN
          CALL abend
          RETURN
         END IF
        END IF
        CALL savacf(Fhacf,iacf,smpac,seacf,Mxlag,Ndf,Nsdf)
        IF(Lfatal)RETURN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)CALL fclose(Fhacf)
       END IF
       IF(Lgraf)THEN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)THEN
         CALL opnfil(T,Lgraf,iacf,Fhacfg,locok)
         IF(.not.locok)THEN
          CALL abend
          RETURN
         END IF
        END IF
        CALL savacf(Fhacfg,iacf,smpac,seacf,Mxlag,Ndf,Nsdf)
        IF(Lfatal)RETURN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)CALL fclose(Fhacfg)
       END IF
c     ------------------------------------------------------------------
       IF(Prttab(iacp))THEN
        IF(Laccss)CALL insmrk(Mt1,iacp,T,F)
        CALL acfhdr(Mt1,Ndf,Nsdf,2)
        CALL corplt(smpac,seacf,Mxlag,Sp)
        IF(Lfatal)RETURN
        IF(Laccss)CALL insmrk(Mt1,iacp,F,F)
       END IF
      END IF
c     ------------------------------------------------------------------
      IF(lp2.or.Lgraf)THEN
       IF(Prttab(ipcf))THEN
        IF(Laccss)CALL insmrk(Mt1,ipcf,T,F)
        CALL acfhdr(Mt1,Ndf,Nsdf,1)
       END IF
       CALL pacf(Nefobs,Sp,smpac,seacf,Mxlag,Prttab(ipcf))
       IF(Prttab(ipcf).and.Laccss)CALL insmrk(Mt1,ipcf,F,F)
       IF(Savtab(ipcf))THEN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)THEN
         CALL opnfil(T,F,ipcf,Fhpcf,locok)
         IF(.not.locok)THEN
          CALL abend
          RETURN
         END IF
        END IF
        CALL savacf(Fhpcf,ipcf,smpac,seacf,Mxlag,Ndf,Nsdf)
        IF(Lfatal)RETURN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)CALL fclose(Fhpcf)
       END IF
       IF(Lgraf)THEN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)THEN
         CALL opnfil(T,Lgraf,ipcf,Fhpcfg,locok)
         IF(.not.locok)THEN
          CALL abend
          RETURN
         END IF
        END IF
        CALL savacf(Fhpcfg,ipcf,smpac,seacf,Mxlag,Ndf,Nsdf)
        IF(Lfatal)RETURN
        IF(Ndf.eq.NOTSET.and.Nsdf.eq.NOTSET)CALL fclose(Fhpcfg)
       END IF
c     ------------------------------------------------------------------
       IF(Prttab(ipcp))THEN
        IF(Prttab(ipcf))WRITE(Mt1,'()')
        IF(Laccss)CALL insmrk(Mt1,ipcp,T,F)
        CALL acfhdr(Mt1,Ndf,Nsdf,1)
        CALL corplt(smpac,seacf,Mxlag,Sp)
        IF(Lfatal)RETURN
        IF(Laccss)CALL insmrk(Mt1,ipcp,F,F)
       END IF
      END IF
c     ------------------------------------------------------------------
      RETURN
      END
