C     Last change:  BCM  29 Aug 2005 10:02 am
      SUBROUTINE resid2(Xy,Nr,Nc,Nb,Xdev,B,Kvec,Rsd,Sti)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Returns the residuals from an X-11 regression model for a 
c     multiplicative seasonal adjustment when both X-11 and Holiday 
c     regressors are used.
c-----------------------------------------------------------------------
      INCLUDE 'srslen.prm'
c-----------------------------------------------------------------------
      DOUBLE PRECISION Xy,B,Rsd,Xn,Xnstar,Xlpyr,Daybar,tmp,Sti,Kvec
      INTEGER icol,irow,ir2,Nr,Nc,Nb,Xdev
      DIMENSION B(*),Rsd(*),tmp(PLEN),Xn(PLEN),Xnstar(PLEN),
     &          Xlpyr(PLEN),Xy(Nc*Nr),Sti(PLEN),Kvec(PLEN)
c-----------------------------------------------------------------------
      COMMON /tdvec / Xn,Xnstar,Xlpyr,Daybar
c-----------------------------------------------------------------------
      DO icol=1,Nb
       CALL daxpy(Nr,B(icol),Xy(icol),Nc,tmp,1)
      END DO
c-----------------------------------------------------------------------
      DO irow=1,Nr
       ir2=irow+Xdev-1
       Rsd(irow)=(Xnstar(ir2)*Sti(ir2))-(Xn(ir2)+tmp(irow))/Kvec(irow)
      END DO
c-----------------------------------------------------------------------
      RETURN
      END
