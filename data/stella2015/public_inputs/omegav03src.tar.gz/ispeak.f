C     Last change:  BCM  16 Sep 2005 11:35 am
**==ispeak.f    processed by SPAG 4.03F  at 14:16 on 28 Sep 1994
      INTEGER FUNCTION ispeak(Sxx,Pkidx,Plimit,Mlimit,Peakwd)
      IMPLICIT NONE
c-----------------------------------------------------------------------
c     Function that flags possible trading day or seasonal peaks in a
c     given set of spectral estimates.  Peak must be greater than the
c     median of the spectral estimates computed (Mlimit).  The peaks of
c     interest are defined in the vector pkvec.
c-----------------------------------------------------------------------
      DOUBLE PRECISION Mlimit,Sxx,slimit,Plimit
      INTEGER i,freq,pkvec,Pkidx,pkptr,Peakwd
      DIMENSION Sxx(61),pkvec(11),pkptr(0:4)
c-----------------------------------------------------------------------
      DATA pkvec/43,53,6,12,11,21,31,41,51,31,61/
      DATA pkptr/1,3,5,10,12/
c-----------------------------------------------------------------------
      ispeak=0
c-----------------------------------------------------------------------
      DO i=pkptr(Pkidx-1),pkptr(Pkidx)-1
       freq=pkvec(i)
       IF(Sxx(freq).gt.Mlimit)THEN
        slimit=Sxx(freq)-Plimit
        IF(Sxx(freq-Peakwd).lt.slimit)THEN
         IF(freq.eq.61)THEN
          ispeak=ispeak+1
         ELSE
          IF(Sxx(freq+Peakwd).lt.slimit)ispeak=ispeak+1
         END IF
        END IF
       END IF
      END DO
c-----------------------------------------------------------------------
      RETURN
      END
