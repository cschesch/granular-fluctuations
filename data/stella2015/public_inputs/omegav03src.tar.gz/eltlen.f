C     Last change:  BCM  30 Jul 2008 4:04 pm
**==eltlen.f    processed by SPAG 4.03F  at 09:48 on  1 Mar 1994
      SUBROUTINE eltlen(Istr,Ptrvec,Nstr,Length)
      IMPLICIT NONE
c     -----------------------------------------------------------------
      INCLUDE 'stdio.i'
      INTEGER Istr,Length,Nstr,Ptrvec
      DIMENSION Ptrvec(0:Nstr)
      INCLUDE 'units.cmn'
c     -----------------------------------------------------------------
      IF(Istr.lt.1.or.Istr.gt.Nstr)THEN
       WRITE(STDERR,1010)Istr,Nstr
       CALL errhdr
       WRITE(Mt2,1010)Istr,Nstr
 1010  FORMAT(' ERROR: No position',i3,' in ',i3,
     &        ' long character vector.')
       CALL abend
       RETURN
c     -----------------------------------------------------------------
      ELSE
       Length=Ptrvec(Istr)-Ptrvec(Istr-1)
      END IF
c     -----------------------------------------------------------------
      RETURN
      END
