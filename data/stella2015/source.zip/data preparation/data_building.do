***************************************************************
*** Firm Dynamics and the Origins of Aggregate Fluctuations ***
*** Andrea Stella                                           ***
*** Last Updated: 04.16.2015                                ***
***************************************************************
*The views in this paper are solely the responsibility of the author and 
*should not be interpreted as reflecting the views of the Board of 
*Governors of the Federal Reserve System or of any other person 
*associated with the Federal Reserve System.

clear
cd "C:\..."
capture log close
version 12.1
set more off
sysdir set PLUS "C:\ado\stbplus\"
sysdir
log using data_building, replace

use data_compustat, replace
des
*In the stata file produced by Compustat gvkey and sic are strings. I need to destring.
destring gvkey, generate(gvkey_num)
destring sic , generate(sic_num)

*I want to generate a time variable that uniquely defines the time
generate time_2 = yq( fyearq, fqtr)
egen time = group(time_2)

* There are many international firms. I keep only the ones incorporate in the US with revenues denominated in dollars
keep if curcdq == "USD"
keep if fic == "USA"

* Rename Variables
rename fyearq year
rename fqtr quarter

keep gvkey_num year quarter revtq sic_num time
sort gvkey_num year quarter

*There are some firms that have negative sales or missing sales. I eliminate them
gen negative_sales = 0
replace negative_sales = 1 if revtq<=0
by gvkey_num: egen negative_sales2 = max(negative_sales) 
drop if negative_sales2 == 1
drop negative_sales negative_sales2
drop if revtq ==.

collapse (min) year quarter sic_num (mean) revtq, by(gvkey_num  time)

tsset gvkey_num  time
gen lag_sale = l.revtq

save startpointdata, replace

* I eliminate firms with nonconsecutive datapoints, it is necessary for estimating a dynamic factor model.
tsset gvkey_num time
bysort gvkey_num: gen temp = time[_n+1] - time
collapse (max) temp, by(gvkey_num)
sort gvkey_num
save intermediate.dta, replace
use startpointdata, replace
sort gvkey_num
merge gvkey_num using intermediate
tab _merge
drop _merge
sum temp 
drop if temp>1
sum temp
drop temp

* I introduce a 2 digit sic code and a 1 digit sic code
sort sic_num
merge sic_num using sic_2digit
tab _merge
keep if _merge==3
drop _merge

sort time
merge time using deflator
tab _merge
drop _merge

tsset gvkey time
sort gvkey
save startpointdata, replace

*** Here I select the top 500 firms each period based on the previous period sales. If there are less then 500 firms in that period, I keep all the firms.

	use startpointdata, replace
	gen temp = 1
	bysort gvkey_num: egen tenure = sum(temp)
	keep if time ==1
	egen num_firms = sum(temp)	
	* I only keep firms that have been in the dasaset for at least 10 consecutive years
	keep if tenure>=41
	egen rank_lag_rev_temp = rank(lag_sale), unique
	egen rank_lag_rev_max = max(rank_lag_rev_temp)
	gen rank_lag_rev = rank_lag_rev_max - rank_lag_rev_temp + 1
	keep if rank_lag_rev<=500 | num_firms<=500
	keep gvkey
	gen time_top500 = 1
	sort gvkey
	save top500_raw, replace

forvalues i = 2(1)200 {
	use startpointdata, replace
	gen temp = 1
	bysort gvkey_num: egen tenure = sum(temp)
	capture	keep if time ==`i'
	egen num_firms = sum(temp)
	* I only keep firms that have been in the dasaset for at least 10 consecutive years
	capture keep if tenure>=41
	capture egen rank_lag_rev_temp = rank(lag_sale), unique
	egen rank_lag_rev_max = max(rank_lag_rev_temp)
	capture gen rank_lag_rev = rank_lag_rev_max - rank_lag_rev_temp + 1
	capture keep if rank_lag_rev<=500 | num_firms<=500
	keep gvkey
	gen time_top500 = `i'
	sort gvkey
	capture append using top500_raw
	capture save top500_raw, replace
	display `i'
}

use top500_raw, replace
gen temp = 1
collapse (sum) temp, by( gvkey_num)
sort gvkey_num
drop temp
save top500, replace

use startpointdata.dta, replace
merge gvkey using top500
tab _merge
keep if _merge == 3
drop _merge

save input_nsa.dta, replace

gen temp = 1
bysort gvkey_num: egen tenure = sum(temp)
drop temp
save input_nsa.dta, replace

* I need a tenure variable for sectors
collapse revtq, by(time sic_1digit)
gen tenure_sic = 1
collapse (sum) tenure_sic, by(sic_1digit)
sort sic_1digit
save intermediate.dta, replace
use input_nsa, replace
sort sic_1digit
merge sic_1digit using intermediate
drop _merge
sum tenure_sic
egen tid = group(gvkey_num)
sum tid
save input_nsa.dta, replace


	use input_nsa.dta, replace
	capture keep if tid == 1
	keep revtq time tid
	capture rename revtq revtq
	capture replace time = time + 7
	format time %tqCCYY!qq
	capture tsset time
	sax12 revtq, satype(single)  transfunc(log) outauto(all) outmethod(addone) x11seas() sliding history noview
	capture sax12im revtq, ext(d11) 
	drop revtq
	rename revtq_d11 revtq
	capture save input_sa_temp, replace
	clear all

forvalues i = 2(1)548{
	use input_nsa.dta, replace
	capture keep if tid == `i'
	display `i'
	keep revtq time tid
	capture replace time = time + 7
	format time %tqCCYY!qq
	capture tsset time
	sax12 revtq, satype(single)  transfunc(log) outauto(all) outmethod(addone) x11seas() sliding history noview
	capture sax12im revtq, ext(d11) 
	drop revtq
	rename revtq_d11 revtq
	capture append using input_sa_temp
	capture save input_sa_temp, replace
	clear all
}

	use input_nsa.dta, replace
	capture keep if tid == 549
	keep revtq time tid
	capture replace time = time + 7
	format time %tqCCYY!qq
	capture tsset time
	sax12 revtq, satype(single)  transfunc(log)  x11seas() sliding history noview
	capture sax12im revtq, ext(d11) 
	drop revtq
	rename revtq_d11 revtq
	capture append using input_sa_temp
	capture save input_sa_temp, replace
	clear all


forvalues i = 550(1)1613{
	use input_nsa.dta, replace
	capture keep if tid == `i'
	display `i'
	keep revtq time tid
	capture replace time = time + 7
	format time %tqCCYY!qq
	capture tsset time
	sax12 revtq, satype(single)  transfunc(log) outauto(all) outmethod(addone) x11seas() sliding history noview
	capture sax12im revtq, ext(d11) 
	drop revtq
	rename revtq_d11 revtq
	capture append using input_sa_temp
	capture save input_sa_temp, replace
	clear all
}

use input_sa_temp, replace
rename time time_sa
egen time = group(time)
drop time_sa
sort tid time
drop if revtq ==.
rename revtq revtq_sa
sort time tid
sum tid
save input_sa, replace

use input_nsa, replace
rename revtq revtq_nsa
keep tid time sic_1 tenure sic_num revtq_nsa deflator gvkey_num year quarter
sort tid time
save temp, replace
use input_sa, replace
sort tid time
merge tid time using temp
tab _merge
keep if _merge== 3
drop _merge
save input_sa, replace

* I make the revenues real
gen rev_real = 100*revtq_sa/deflator

tsset tid time
gen log_rev_real = ln(rev_real)
gen rev_growth = d.log_rev_real
gen pvalue = 0
forvalues i = 1(1)1613{
capture dfuller rev_growth if tid==`i'
capture replace pvalue = r(p) if tid==`i'
display  `i'
}
collapse (mean) pvalue, by(tid)
keep if pvalue>0.01
sort tid
save reject_stationarity, replace

use input_sa, replace
* Remove non-stationary
sort tid
merge tid using reject_stationarity
tab _merge
tab tid if _merge!=1
keep if _merge==1
drop _merge
egen tid2 = group(tid)
rename tid tid_old
rename tid2 tid
sum tid

* I make the revenues real
gen rev_real = 100*revtq_sa/deflator

* I compute the weights
bysort time: egen rev_sum_real = sum(rev_real)
gen w_it = rev_real/rev_sum_real
bysort tid: egen w_bar = mean(w_i)
bysort tid: egen w_sd = sd(w_i)
tsset tid time
gen lw_it = l.w_it
save input_descriptive, replace

* I compute revenues' growth
gen log_rev_real = ln(rev_real)
gen rev_growth = d.log_rev_real
drop if rev_growth ==.

bysort tid: egen mean_rev_growth = mean(rev_growth)

replace rev_growth = rev_growth - mean_rev_growth

sum time
replace time = time-1
sum time
tsset tid time

save input_final_small_sample.dta, replace

outsheet tid time rev_growth sic_1digit lw_it w_sd w_bar w_it using "C:\...\sa_data_final.csv", nonames replace

collapse (min) tenure, by(tid)
sort tid
outsheet tid tenure using "C:\...\tenure_final.csv", nonames replace

use macro_shocks, replace
outsheet time oil monetary spending taxes technology oil_lag1 monetary_lag1 spending_lag1 taxes_lag1 technology_lag1 oil_lag2 monetary_lag2 spending_lag2 taxes_lag2 technology_lag2 oil_lag3 monetary_lag3 spending_lag3 taxes_lag3 technology_lag3 oil_lag4 monetary_lag4 spending_lag4 taxes_lag4 technology_lag4 using "C:\...\data_macro_shocks.csv", nonames replace

use input_final_small_sample.dta, replace
collapse gvkey_num , by(tid)
sort gvkey_num
save tid_gvkey, replace

use top500_raw, replace
sort gvkey_num
merge gvkey_num using tid_gvkey
tab _merge
keep if _merge==3
drop if time == 1
replace time = time - 1
tsset tid time_top500
tsfill, full
gen index_top500 = 0
replace index_top500 = 1 if _merge==3
drop gvkey_num _merge
reshape wide index_top500, i(tid) j(time_top500)
outsheet index_top5001-index_top500199 using "C:\...\index_top500.csv", nonames replace

use top500_raw, replace
rename time_top500 time
sort gvkey_num time
save temp, replace

use input_descriptive.dta, replace
sort gvkey_num time
merge gvkey_num time using temp
tab _merge
keep if _merge ==3
gen aggregate_revenues = revtq_sa
collapse (sum) aggregate_revenues, by(time)
gen log_aggregate_revenues =ln(aggregate_revenues)
tsset time
gen aggregate_revenues_growth = d.log_aggregate_revenues
drop if aggregate_revenues_growth==.
replace time = time-1
sort time
merge time using gdp_growth
format time %tqCCYY!qq
tsset time
replace time = time+8
corr real_gdp_growth  aggregate_revenues_growth
graph twoway line real_gdp_growth  aggregate_revenues_growth time, legend(order(1 "U.S. GDP Growth" 2 "Top 500 Sales Growth") ring(0) bplacement(nwest)) xtitle("")
graph export "C:\...\gdp_compustat_growth.eps", as(eps) preview(off) replace


log close

