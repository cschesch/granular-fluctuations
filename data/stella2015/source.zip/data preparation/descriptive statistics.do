***************************************************************
*** Firm Dynamics and the Origins of Aggregate Fluctuations ***
*** Andrea Stella                                           ***
*** Last Updated: 04.16.2015                                ***
***************************************************************
*The views in this paper are solely the responsibility of the author and 
*should not be interpreted as reflecting the views of the Board of 
*Governors of the Federal Reserve System or of any other person 
*associated with the Federal Reserve System.

clear
capture log close
log using decomposition_variance_small_sample, replace

use input_descriptive, replace
collapse (mean) w_it, by(tid)
egen rank_weight = rank(w_it), unique
egen maxrank_weight = max(rank_weight)
gen rank = maxrank- rank_weight +1
egen average_lag_weights = mean(w_it)
keep tid rank average_lag_weights
sort tid
save rank_data, replace

use input_descriptive, replace
sort tid
merge tid using rank_data
tab _merge
drop _merge
bysort tid : egen min_time = min(time)
bysort tid : egen max_time = max(time)
gen entering = 0
replace entering = rev_real if time == min_time
gen exiting = 0
replace exiting = rev_real if time == max_time
tsset tid time
gen rev_growth = 100*(rev_real - l.rev_real)/l.rev_real
gen lag_weights = l.w_it
gen continuing_firms_growth = lag_weights*rev_growth
gen continuing_firms_growth_bigger = 0
replace continuing_firms_growth_bigger = lag_weights*rev_growth if (w_bar > average_lag_weights)
gen continuing_firms_growth_smaller = 0
replace continuing_firms_growth_smaller = lag_weights*rev_growth if (w_bar < average_lag_weights)
gen continuing_firms_growth_top_500 = 0
replace continuing_firms_growth_top_500 = lag_weights*rev_growth if rank<=500

gen aggregate_sales = rev_real
gen aggregate_sales_smaller = 0
replace aggregate_sales_smaller = rev_real if (w_bar < average_lag_weights)
gen aggregate_sales_top_500 = 0
replace aggregate_sales_top_500 = rev_real if rank<=500

collapse (mean) year  (sum) aggregate_sales aggregate_sales_smaller aggregate_sales_top_500 continuing_firms_growth_top_500 continuing_firms_growth_bigger continuing_firms_growth_smaller continuing_firms_growth entering exiting, by(time)

tsset time

replace entering = 100*entering/l.aggregate_sales
gen lag_exiting = l.exiting
replace exiting = 100*(-lag_exiting)/l.aggregate_sales
gen aggregate_sales_growth = 100*(aggregate_sales - l.aggregate_sales)/l.aggregate_sales
gen aggregate_sales_growth_smaller = 100*(aggregate_sales_smaller - l.aggregate_sales_smaller)/l.aggregate_sales_smaller
gen aggregate_sales_growth_top_500 = 100*(aggregate_sales_top_500 - l.aggregate_sales_top_500)/l.aggregate_sales_top_500

drop if time==1

*TABLE 1
sum aggregate_sales_growth continuing_firms_growth entering exiting

*TABLE 2
sum continuing_firms_growth continuing_firms_growth_bigger continuing_firms_growth_smaller continuing_firms_growth_top_500

format time %tqCCYY!qq
tsset time
replace time = time+8
*FIGURE 1
graph twoway line continuing_firms_growth continuing_firms_growth_bigger continuing_firms_growth_smaller  time, legend(order(1 "Aggregate Growth - Continuing Firms" 2 "Bigger than Average" 3 "Smaller than Average")) xtitle("") 
graph export "C:\...\figure1.eps", as(eps) preview(off) replace

use input_descriptive, replace
tsset tid time
gen rev_growth = 100*(rev_real - l.rev_real)/l.rev_real
collapse (min) tenure (sd) rev_growth  (mean) w_bar, by(tid)
sort tid
merge tid using rank_data

* TABLE 3
sum rev_growth, d
sum rev_growth if rank<=500, d
sum rev_growth if w_bar<average_lag_weights, d

log close

set more off
use top500_raw, replace
rename time_top500 time
sort gvkey_num time
save temp, replace
use input_final_small_sample.dta, replace
sort gvkey_num time
merge gvkey_num time using temp
tab _merge
keep if _merge ==3
keep if sic_1digit == 2 | sic_1digit == 3 | sic_1digit == 5
collapse (sum) revtq_sa revtq_nsa, by(time)
line revtq_sa revtq_nsa time
rename revtq_sa revenues_top500
sort time
merge time using bea_sales
tab _merge
keep if _merge ==3
format time %tqCCYY!qq
tsset time
gen bea_sales = retail_food_services + manufacturing_trade_industries
replace time = time+8
replace revenues_top500 = revenues_top500/1000000
replace bea_sales = bea_sales/1000000
graph twoway line bea_sales  revenues_top500 time, legend(order(1 "BEA Sales" 2 "Top 500") ring(0) bplacement(nwest)) xtitle("")
graph export "C:\...\bea_compustat.eps", as(eps) preview(off) replace

use G_regressions, replace

reg G_mean oil monetary spending taxes technology oil_lag1 monetary_lag1 spending_lag1 taxes_lag1 technology_lag1 oil_lag2 monetary_lag2 spending_lag2 taxes_lag2 technology_lag2 oil_lag3 monetary_lag3 spending_lag3 taxes_lag3 technology_lag3 oil_lag4 monetary_lag4 spending_lag4 taxes_lag4 technology_lag4
reg G_mean oil oil_lag1 oil_lag2 oil_lag3 oil_lag4
reg G_mean monetary monetary_lag1 monetary_lag2 monetary_lag3 monetary_lag4
reg G_mean technology technology_lag1 technology_lag2 technology_lag3 technology_lag4
reg G_mean spending spending_lag1 spending_lag2 spending_lag3 spending_lag4
reg G_mean taxes taxes_lag1 taxes_lag2 taxes_lag3 taxes_lag4


use input_final_small_sample.dta, replace
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
tab du
sum time
tsset tid time
tsfill, full
tab du
replace du = 0 if du ==.
tab du
gen index_nofinance = 0
replace index_nofinance = 1 if du ==0
tab index_nofinance
keep tid  time  index_nofinance
reshape wide index_nofinance, i(tid) j(time)
outsheet index_nofinance1-index_nofinance199 using "C:\...\index_nofinance.csv", nonames comma replace




use input_final_small_sample.dta, replace
collapse gvkey_num , by(tid)
sort gvkey_num
save tid_gvkey, replace
use top500_raw, replace
sort gvkey_num
merge gvkey_num using tid_gvkey
tab _merge
keep if _merge==3
drop if time == 1
replace time = time - 1
tsset tid time_top500
tsfill, full
gen index_top500 = 0
replace index_top500 = 1 if _merge==3
rename time_top500 time
keep tid time index_top500
sort tid time
save index_data, replace

cd "C:\...\small sample sa"

log using regressions_small_sa, replace

use input_final_small_sample.dta, replace
sort tid time
merge tid time using index_data
tab _merge
keep if _merge ==3
drop _merge
keep if index_top500 ==1
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
*keep if du ==0
sort time
merge time using gdp_growth
sort tid time
gen granular = lw_it*rev_growth
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular


use input_final_small_sample.dta, replace
sort tid time
merge tid time using index_data
tab _merge
keep if _merge ==3
drop _merge
keep if index_top500 ==1
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
sort time
merge time using gdp_growth
sort tid time
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*rev_growth
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

log close
