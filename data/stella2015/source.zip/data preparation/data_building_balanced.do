***************************************************************
*** Firm Dynamics and the Origins of Aggregate Fluctuations ***
*** Andrea Stella                                           ***
*** Last Updated: 04.16.2015                                ***
***************************************************************
*The views in this paper are solely the responsibility of the author and 
*should not be interpreted as reflecting the views of the Board of 
*Governors of the Federal Reserve System or of any other person 
*associated with the Federal Reserve System.


clear
cd "C:\..."
capture log close
set more off
sysdir set PLUS "C:\ado\stbplus\"
sysdir
log using data_building_balanced_dataset_sa, replace

set more off
use "C:\...\input_descriptive.dta", replace
cd "C:\old top 500 firms"
sum time
sum year quarter if time ==1
sum year quarter if time == 200

sort year quarter
merge year quarter using rgdp
tab _merge
keep if _merge==3
drop _merge

sort gvkey_num
merge gvkey_num using gvkey_sic_naics
tab _merge
keep if _merge==3
drop _merge

replace naics_num =. if naics_num>900000
sort sic_num
merge sic_num using naics97_sic
tab _merge
drop if _merge ==2
replace naics_num = naics97 if naics_num==. & naics97!=.
drop _merge naics97

sort sic_num
merge sic_num using naics_by_hand
tab _merge
replace naics_num =  naics_num_hand if naics_num==. & naics_num_hand!=.
drop if _merge ==2
drop _merge naics_num_hand
drop if naics_num==.

sort  naics_num sic_num
merge  naics_num sic_num using sid_codes
tab _merge
drop _merge
tsset gvkey time
sort gvkey

drop if year<1970

rename time time_old
egen time = group(time_old)
gen temp = 1
rename tenure tenure_500firms
bysort gvkey_num: egen tenure = sum(temp)
sum tenure time
sum year quarter if time ==1
sum year quarter if time == 168

keep if tenure == 168
rename tid tid_500firms
egen tid = group(gvkey)
sum tid

drop  rev_sum_real w_it  w_bar w_sd  lw_it temp

* I compute the weights
bysort time: egen rev_sum_real = sum(rev_real)
gen w_it = rev_real/rev_sum_real
gen w_it_rgdp = rev_real/rgdp
bysort tid: egen w_bar = mean(w_it)
bysort tid: egen w_sd = sd(w_it)
bysort tid: egen w_bar_rgdp = mean(w_it_rgdp)
bysort tid: egen w_sd_rgdp = sd(w_it_rgdp)
tsset tid time
gen lw_it = l.w_it
gen lw_it_rgdp = l.w_it_rgdp 

tsset tid time
save input_descriptive.dta, replace

use input_descriptive.dta, replace
* I compute revenues' growth
gen log_rev_real = ln(rev_real)
gen rev_growth = d.log_rev_real
drop if rev_growth ==.

bysort tid: egen mean_rev_growth = mean(rev_growth)

replace rev_growth = rev_growth - mean_rev_growth

sum time
replace time = time-1
sum time
tsset tid time

save input_final_small_sample.dta, replace


set more off
use "C:\...\annual_data.dta", replace
cd "C:\..."
destring gvkey, generate(gvkey_num)
rename fyear year
keep gvkey_num emp year
keep if emp!=. & gvkey_num!=. & year!=. & emp!=0
rename emp firm_emp
sort gvkey_num year
save temp_annual.dta, replace




set more off
use sectoral_emp_raw.dta, replace
reshape long stub, i(year) j(sid)
rename stub sectoral_emp
drop if sectoral_emp ==0
sort sid year 
save sectoral_emp.dta, replace


*** divided by sectoral employees ***
set more off
use input_descriptive.dta, replace
sort gvkey_num year
merge gvkey_num year using temp_annual
tab _merge
drop if _merge ==2
drop _merge
sort sid year 
merge sid year using sectoral_emp
tab _merge
drop if _merge ==2
drop _merge
gen has_ratio = 0
replace has_ratio = 1 if firm_emp!=. & sectoral_emp!=.
collapse (max) has_ratio sid, by(tid)
tab has_ratio
keep tid has_ratio
sort tid
save temp.dta, replace
use input_descriptive.dta, replace
sort gvkey_num year
merge gvkey_num year using temp_annual
tab _merge
drop if _merge ==2
drop _merge
sort sid year 
merge sid year using sectoral_emp
tab _merge
drop if _merge ==2
drop _merge
sort tid
merge tid using temp
tab _merge
tab gvkey_num if has_ratio==0
drop if has_ratio==0
gen du = 0
replace du = 1 if firm_emp!=. & sectoral_emp!=.
keep if du==1
gen first_time = time
gen last_time = time
bysort sid time: egen sum_emp = sum(firm_emp)
collapse (max) last_time (min) first_time (mean)  sid firm_emp sectoral_emp gvkey_num, by(tid)
bysort sid: egen sum_emp = sum(firm_emp)
gen ratio_emp =  firm_emp/sectoral_emp
* Three sectors where firms are too big
replace ratio_emp =  firm_emp/sum_emp if sid ==1013 | sid == 1034 | sid ==1048
order tid first_time last_time sid ratio_emp
sort tid
egen new_tid = group(tid)
sum new_tid tid
keep tid new_tid first_time last_time sid ratio_emp
order new_tid first_time last_time sid ratio_emp
sort new_tid
outsheet new_tid first_time last_time sid ratio_emp using "C:\...\tid.csv", comma nonames replace
keep tid new_tid sid
sort tid
save newtid.dta, replace

collapse new_tid, by(sid)
outsheet sid using "C:\...\sid.csv", comma nonames replace


set more off
use input_final_small_sample.dta, replace
sort tid
merge tid using newtid
tab _merge
keep if _merge ==3
drop _merge
tsset new_tid time
outsheet new_tid time rev_growth sic_1digit lw_it w_sd w_bar w_it lw_it_rgdp using "C:\...\sa_data_final.csv", comma nonames replace
save input_final_small_sample_new.dta, replace
collapse (min) tenure, by(new_tid)
sort new_tid
outsheet new_tid tenure using "C:\...\tenure_final.csv", comma nonames replace

use input_descriptive, replace
sort tid
merge tid using newtid
tab _merge
keep if _merge ==3
drop _merge
save input_descriptive_new, replace


set more off
use input_final_small_sample_new.dta, replace
keep new_tid time rev_growth
tsset new_tid time
tsfill, full
replace rev_growth = 0 if rev_growth ==.
reshape wide rev_growth, i(time) j(new_tid)
outsheet rev_growth1-rev_growth234 using "C:\...\salesdata.csv", comma nonames replace
 


set more off
use macro_shocks_raw.dta, replace
* time ==1 is 1961q2
tsset time
forvalues i = 1(1)4{
gen oil_lag`i' = l`i'.oil
gen monetary_lag`i' = l`i'.monetary
gen spending_lag`i' = l`i'.spending
gen taxes_lag`i' = l`i'.taxes
gen tfp_shock_lag`i' = l`i'.tfp_shock
}
drop if year<1970
drop if year==1970 & quarter==1
drop if year>2011
replace time = time -36
sum time
save macro_shocks.dta, replace

use macro_shocks.dta, replace
outsheet time oil monetary spending taxes tfp_shock oil_lag1 monetary_lag1 spending_lag1 taxes_lag1 tfp_shock_lag1 oil_lag2 monetary_lag2 spending_lag2 taxes_lag2 tfp_shock_lag2 oil_lag3 monetary_lag3 spending_lag3 taxes_lag3 tfp_shock_lag3 oil_lag4 monetary_lag4 spending_lag4 taxes_lag4 tfp_shock_lag4 using "C:\...\data_macro_shocks.csv", comma nonames replace


use input_final_small_sample_new.dta, replace
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
tab du
sum time
tsset new_tid time
tsfill, full
tab du
replace du = 0 if du ==.
tab du
gen index_nofinance = 0
replace index_nofinance = 1 if du ==0
tab index_nofinance
keep new_tid  time  index_nofinance
reshape wide index_nofinance, i(new_tid) j(time)
outsheet index_nofinance1-index_nofinance167 using "C:\...\index_nofinance.csv", nonames comma replace


use rgdp.dta, replace
gen log_rgdp = ln(rgdp)
sort year quarter
gen time  = _n
tsset time
gen real_gdp_growth = d.log_rgdp
drop if real_gdp_growth ==.
drop time
sort year quarter
save gdp_growth.dta, replace


set more off
capture log close
log using regressions_small_sa, replace

use input_final_small_sample_new.dta, replace
drop if time<3
sort new_tid time
gen granular = lw_it*rev_growth
collapse (sum) granular (min) year quarter, by(time)
sort year quarter
merge year quarter using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

use input_final_small_sample_new.dta, replace
sort new_tid time
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*rev_growth
collapse (sum) granular (min) year quarter, by(time)
sort year quarter
merge year quarter using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular



use input_final_small_sample_new.dta, replace
sort new_tid time
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
sort new_tid time
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*rev_growth
collapse (sum) granular (min) year quarter, by(time)
sort year quarter
merge year quarter using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

log close



