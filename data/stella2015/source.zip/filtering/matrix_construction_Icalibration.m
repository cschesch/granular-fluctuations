clear all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Firm Dynamics and the Origins of Aggregate Fluctuations %%%
%%% Andrea Stella                                           %%%
%%% Last Updated: 04.16.2015                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The views in this paper are solely the responsibility of the author and 
%should not be interpreted as reflecting the views of the Board of 
%Governors of the Federal Reserve System or of any other person 
%associated with the Federal Reserve System.

matrixio = csvread('matrix_io_input.csv');
tid = csvread('tid.csv');
gross_operating_surplus = csvread('valadd.csv');

io_sectoral = matrixio(2:end-1,2:end);
column_io_sectoral = matrixio(1,2:end);
row_io_sectoral = matrixio(2:end-1,1);
value_of_production = matrixio(end,2:end);

% tid - firstyear - lastyear - sid - ratio

matrix_io_final = zeros(size(tid,1),size(tid,1));
matrix_io_final_prova = zeros(size(tid,1),size(tid,1));
matrix_capital_final = eye(size(tid,1),size(tid,1));
alpha_vector = zeros(size(tid,1),1);
for i=1:size(tid,1)
    alpha_vector(i) = gross_operating_surplus(find(column_io_sectoral==tid(i,4)))/value_of_production(find(column_io_sectoral==tid(i,4)));
    
    for j=1:size(tid,1)
        
        matrix_io_final(i,j) = tid(i,5)*io_sectoral(find(row_io_sectoral==tid(i,4)),find(column_io_sectoral==tid(j,4)))/value_of_production(find(column_io_sectoral==tid(j,4)));
        matrix_io_final_prova(i,j) = io_sectoral(find(row_io_sectoral==tid(i,4)),find(column_io_sectoral==tid(j,4)));
        if isnan(matrix_io_final(i,j)) == 1
            matrix_io_final(i,j) = 0;
        end
        
        if  matrix_io_final(i,j) == 0
            matrix_io_final(i,j) = 1e-19;
        end
        
        if  matrix_capital_final(i,j) == 0
            matrix_capital_final(i,j) = 1e-19;
        end
               
    end
end



alpha = full(spdiags(alpha_vector, 0, eye(size(tid,1))));

N = size(matrix_capital_final,1);
gma = matrix_io_final;


part1 =  eye(N) - alpha;
part2 = full(spdiags(sum(gma)', 0, eye(N)));

phi = part1- part2; 


csvwrite('matrix_io.csv',matrix_io_final)
csvwrite('matrix_capital.csv',matrix_capital_final)
csvwrite('alpha.csv',alpha)
