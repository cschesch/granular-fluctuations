clear all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Firm Dynamics and the Origins of Aggregate Fluctuations %%%
%%% Andrea Stella                                           %%%
%%% Last Updated: 04.16.2015                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The views in this paper are solely the responsibility of the author and 
%should not be interpreted as reflecting the views of the Board of 
%Governors of the Federal Reserve System or of any other person 
%associated with the Federal Reserve System.

matrixio = csvread('matrix_io_input.csv');
tid = csvread('tid.csv');
gross_operating_surplus = csvread('valadd.csv');
compustat_data = csvread('comp_data.csv');
% compustat_data: new_tid new_tid_customer  sid sid_customer

matrix_compustat = zeros(size(tid,1),size(tid,1));
for ii = 1:size(tid,1)
    prova = find(compustat_data(:,1)==ii);
    if  isempty(prova)==1
        matrix_compustat(ii,:) = 0;
    else
        for jj = 1:size(tid,1)
            prova = find(compustat_data(:,1)==ii & compustat_data(:,2)==jj);
            if  isempty(prova)==0
                matrix_compustat(ii,jj) = 1;
            end
        end
    end
end
 

io_sectoral = matrixio(2:end-1,2:end);
column_io_sectoral = matrixio(1,2:end);
row_io_sectoral = matrixio(2:end-1,1);
value_of_production = matrixio(end,2:end);

% tid - firstyear - lastyear - sid - ratio

matrix_io_final = zeros(size(tid,1),size(tid,1));
matrix_io_final_prova = zeros(size(tid,1),size(tid,1));
matrix_capital_final = eye(size(tid,1),size(tid,1));
alpha_vector = zeros(size(tid,1),1);
for i=1:size(tid,1)
    alpha_vector(i) = gross_operating_surplus(find(column_io_sectoral==tid(i,4)))/value_of_production(find(column_io_sectoral==tid(i,4)));
    
    for j=1:size(tid,1)
        share_employees = 0;
        prova = find(compustat_data(:,2)==j);
        prova4 = find(compustat_data(prova,1)==i);
        if isempty(prova4)==0
            prova3 = find(compustat_data(prova,3)==compustat_data(prova(prova4),3));
            if isempty(prova3)==0
                if length(prova3)==1
                    share_employees = 1; 
                else
                    share_employees = tid(i,5)/sum(tid(compustat_data(prova(prova3),1),5));
                end
            end
        end
        % Dollar payments from j to i divided by production in j * share of
        % j is the client
        % The notation in the paper is flipped, i is j and viceversa
        matrix_io_final(i,j) = matrix_compustat(i,j)*share_employees*io_sectoral(find(row_io_sectoral==tid(i,4)),find(column_io_sectoral==tid(j,4)))/value_of_production(find(column_io_sectoral==tid(j,4)));
        matrix_io_final_prova(i,j) = io_sectoral(find(row_io_sectoral==tid(i,4)),find(column_io_sectoral==tid(j,4)));
        
        
        if isnan(matrix_io_final(i,j)) == 1
            matrix_io_final(i,j) = 0;
        end
        

        if  matrix_io_final(i,j) == 0
            matrix_io_final(i,j) = 1e-19;
        end
        if  matrix_capital_final(i,j) == 0
            matrix_capital_final(i,j) = 1e-19;
        end
               
    end
end



alpha = full(spdiags(alpha_vector, 0, eye(size(tid,1))));

N = size(matrix_capital_final,1);
gma = matrix_io_final;


part1 =  eye(N) - alpha;
part2 = full(spdiags(sum(gma)', 0, eye(N)));

phi = part1- part2; 


csvwrite('matrix_io.csv',matrix_io_final)
csvwrite('matrix_capital.csv',matrix_capital_final)
csvwrite('alpha.csv',alpha)

