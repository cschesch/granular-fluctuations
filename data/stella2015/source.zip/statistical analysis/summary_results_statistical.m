clear
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Firm Dynamics and the Origins of Aggregate Fluctuations %%%
%%% Andrea Stella                                           %%%
%%% Last Updated: 04.16.2015                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The views in this paper are solely the responsibility of the author and 
%should not be interpreted as reflecting the views of the Board of 
%Governors of the Federal Reserve System or of any other person 
%associated with the Federal Reserve System.
tic

load data_input_fs

Number_datasets = 25;
Number_burnin_datasets = 5;
Number_repetitions = 1000;
burnin_total = Number_burnin_datasets*Number_repetitions;

Total_number_repetitions = Number_datasets*Number_repetitions - burnin_total;
 
Macro_var_draw = zeros(N,Total_number_repetitions);
G_var_draw = zeros(N,Total_number_repetitions);
Y_var_draw = zeros(N,Total_number_repetitions);

total_var_draw = zeros(N,Total_number_repetitions);
total_var_draw_macro = zeros(N,Total_number_repetitions);

fraction_macro_draw = zeros(N,Total_number_repetitions);
fraction_G_draw_macro = zeros(N,Total_number_repetitions);
fraction_Y_draw_macro = zeros(N,Total_number_repetitions);


indice_progressivo = 1;
for t =(Number_burnin_datasets+1):Number_datasets
    disp('   ')    
    disp(['dataset: ',num2str(t)])    
    disp('   ')

    h=t-Number_burnin_datasets;
    str = num2str(t);
    load(str)  
    for index_save =1:Number_repetitions
                    
        for i = 1:N
            G_var_draw(i,indice_progressivo) = 0.01*F_draw_save(i,index_save)^2;
            Y_var_draw(i,indice_progressivo) = (inv(1-psi_Y_save(i,index_save)^2))*sigma_square_Y_save(i,index_save);
        
            total_var_draw_macro(i,indice_progressivo) = G_var_draw(i,indice_progressivo) + Y_var_draw(i,indice_progressivo);
            fraction_G_draw_macro(i,indice_progressivo) = 100*G_var_draw(i,indice_progressivo)/total_var_draw_macro(i,indice_progressivo);
            fraction_Y_draw_macro(i,indice_progressivo) = 100*Y_var_draw(i,indice_progressivo)/total_var_draw_macro(i,indice_progressivo);

        end
        indice_progressivo = indice_progressivo + 1;        
    end
    clear  psi_G_save psi_Y_save sigma_square_G_save sigma_square_Y_save G_draw_save A_draw_save B_draw_save C_draw_save D_draw_save E_draw_save
end

G_var_draw_mean = mean(G_var_draw,2);
Y_var_draw_mean = mean(Y_var_draw,2);
fraction_G_draw_macro_mean = mean(fraction_G_draw_macro,2);
fraction_Y_draw_macro_mean = mean(fraction_Y_draw_macro,2);

Y_var_draw_median = zeros(N,1);
fraction_G_draw_macro_median = zeros(N,1);
fraction_Y_draw_macro_median = zeros(N,1);

Y_var_draw_2_5 = zeros(N,1);
fraction_G_draw_macro_2_5 = zeros(N,1);
fraction_Y_draw_macro_2_5 = zeros(N,1);

Y_var_draw_97_5 = zeros(N,1);
fraction_G_draw_macro_97_5 = zeros(N,1);
fraction_Y_draw_macro_97_5 = zeros(N,1);

for i = 1:N
    Y_var_draw_median(i,1) = prctile(Y_var_draw(i,:),50);
    fraction_G_draw_macro_median(i,1) = prctile(fraction_G_draw_macro(i,:),50);
    fraction_Y_draw_macro_median(i,1) = prctile(fraction_Y_draw_macro(i,:),50);

    Y_var_draw_2_5(i,1) = prctile(Y_var_draw(i,:),2.5);
    fraction_G_draw_macro_2_5(i,1) = prctile(fraction_G_draw_macro(i,:),2.5);
    fraction_Y_draw_macro_2_5(i,1) = prctile(fraction_Y_draw_macro(i,:),2.5);
    
    Y_var_draw_97_5(i,1) = prctile(Y_var_draw(i,:),97.5);
    fraction_G_draw_macro_97_5(i,1) = prctile(fraction_G_draw_macro(i,:),97.5);
    fraction_Y_draw_macro_97_5(i,1) = prctile(fraction_Y_draw_macro(i,:),97.5);
end


load data_input

sa_data_final(:,2) = sa_data_final(:,2) - min(sa_data_final(:,2))+1;
tenure = tenure_final(:,2)-1;

T = max(sa_data_final(:,2));
T_permanent = T;
number_observations = length(sa_data_final);
N = max(sa_data_final(:,1));
Y = zeros(N,T);
revenues = zeros(N,T);
lag_weight = zeros(N,T);
avg_weight = zeros(N,1);

id = zeros(N,1);
ii=1;
for i=1:N
    prova(i) =  ii;
    tenure_X = tenure(i,1);    
    time_X = sa_data_final(ii,2); 
    time(i,1) = time_X;
    Y(i,time_X:(time_X+tenure_X-1)) = sa_data_final(ii:(ii+tenure_X-1),3);
    lag_weight(i,time_X:(time_X+tenure_X-1)) = sa_data_final(ii:(ii+tenure_X-1),5);
    avg_weight(i,:) = sa_data_final(ii,7);
    id(i,1) = sa_data_final(ii,1);
    ii = ii + tenure_X;
end

data = [id  fraction_G_draw_macro_mean fraction_Y_draw_macro_mean  fraction_G_draw_macro_2_5 fraction_Y_draw_macro_2_5  fraction_G_draw_macro_97_5 fraction_Y_draw_macro_97_5];
save('data_histogram_macro_raw','data')


diary log_svd
clear

load data_input_fs
index_top500 =  index.*index_top500;

N_rep = 25000;

Number_datasets = 25;
Number_burnin_datasets = 5;
Number_repetitions = 1000;
burnin_total = Number_burnin_datasets*Number_repetitions;
disp('   ')
disp('Summary of Results   ')
disp('   ')
disp(['The number of firms is:       ',num2str(N)])
disp(['The number of periods is:     ',num2str(T)])
disp(['The number of repetitions is: ',num2str(N_rep)])
disp(['Burnin:                       ',num2str(burnin_total)])

Total_number_repetitions = Number_datasets*Number_repetitions - burnin_total;

Fraction_G = zeros(T,Total_number_repetitions);
Fraction_idiosyncratic_shock = zeros(T,Total_number_repetitions);

total_variance_aggregate = zeros(T,Total_number_repetitions);

for t_index = 1:T   
       
    disp('   ')    
    disp(['time: ',num2str(t_index)])    
    disp('   ')
    disp('   ')

    total_variance_aggregate_temp2 = 0;
    Fraction_G_temp2 = 0;
    Fraction_idiosyncratic_shock_temp2 = 0;
   
    for t =(Number_burnin_datasets+1):Number_datasets
    disp('   ')    
    disp(['dataset: ',num2str(t)])    
    disp('   ')

    h=t-Number_burnin_datasets;
    str = num2str(t);
    load(str)   
    
    total_variance_aggregate_temp = zeros(1,Number_repetitions);
    Fraction_G_temp = zeros(1,Number_repetitions);
    Fraction_idiosyncratic_shock_temp = zeros(1,Number_repetitions);
    total_variance_aggregate_macro_temp = zeros(1,Number_repetitions);
    Fraction_G_macro_temp =zeros(1,Number_repetitions);
    Fraction_idiosyncratic_shock_macro_temp =zeros(1,Number_repetitions);
    
    for index_save =1:Number_repetitions

        Y_var_draw = index_top500(:,t_index).*(avg_weight.^2).*((ones(N,1)-psi_Y_save(:,index_save).^2).^(-1)).*sigma_square_Y_save(:,index_save);   
        contribution_idiosyncratic_shock = sum(Y_var_draw);
        contribution_G = (sum(index_top500(:,t_index).*avg_weight.*(F_draw_save(:,index_save))).^2)*0.01;
        
        total_variance_aggregate_temp(index_save) = contribution_G + contribution_idiosyncratic_shock;

        Fraction_G_temp(index_save) = 100*contribution_G/total_variance_aggregate_temp(index_save);
        Fraction_idiosyncratic_shock_temp(index_save) = 100*contribution_idiosyncratic_shock/total_variance_aggregate_temp(index_save);    
        
    end
    
    total_variance_aggregate_temp2 = [total_variance_aggregate_temp2 total_variance_aggregate_temp];
    Fraction_G_temp2 = [Fraction_G_temp2  Fraction_G_temp];
    Fraction_idiosyncratic_shock_temp2 = [Fraction_idiosyncratic_shock_temp2  Fraction_idiosyncratic_shock_temp];
    
    end
    clear  psi_G_save psi_Y_save sigma_square_G_save sigma_square_Y_save G_draw_save A_draw_save B_draw_save C_draw_save D_draw_save E_draw_save
    
    total_variance_aggregate(t_index,:) = total_variance_aggregate_temp2(2:end);
    Fraction_G(t_index,:) = Fraction_G_temp2(2:end);
    Fraction_idiosyncratic_shock(t_index,:) = Fraction_idiosyncratic_shock_temp2(2:end);

end

Fraction_G_mean = mean(Fraction_G,2);
Fraction_idiosyncratic_shock_mean = mean(Fraction_idiosyncratic_shock,2);

disp('Aggregate Variance Decomposition mean:')
disp('   ')
disp(['R^2(G):          ',num2str(mean(Fraction_G_mean))])
disp(['R^2(e):          ',num2str(mean(Fraction_idiosyncratic_shock_mean))])
disp('   ')
save('data_svd','Fraction_G','Fraction_idiosyncratic_shock')



diary avd
clear

load data_svd

Fraction_G_2_5 = prctile(Fraction_G,2.5,2);
Fraction_idiosyncratic_shock_2_5 = prctile(Fraction_idiosyncratic_shock,2.5,2);

Fraction_G_97_5 = prctile(Fraction_G,97.5,2);
Fraction_idiosyncratic_shock_97_5 = prctile(Fraction_idiosyncratic_shock,97.5,2);

Fraction_G_mean = mean(Fraction_G,2);
Fraction_idiosyncratic_shock_mean = mean(Fraction_idiosyncratic_shock,2);

G_whole = [mean(Fraction_G_2_5) mean(Fraction_G_mean) mean(Fraction_G_97_5)];
idio_whole = [mean(Fraction_idiosyncratic_shock_2_5) mean(Fraction_idiosyncratic_shock_mean) mean(Fraction_idiosyncratic_shock_97_5)];

disp('Aggregate Variance Decomposition Whole Sample:')
disp('   ')
disp(['R^2(G):          ',num2str(G_whole)])
disp(['R^2(e):          ',num2str(idio_whole)])
disp('   ')


G_1960 = [mean(Fraction_G_2_5(1:39)) mean(Fraction_G_mean(1:39)) mean(Fraction_G_97_5(1:39))];
idio_1960 = [mean(Fraction_idiosyncratic_shock_2_5(1:39)) mean(Fraction_idiosyncratic_shock_mean(1:39)) mean(Fraction_idiosyncratic_shock_97_5(1:39))];

disp('Aggregate Variance Decomposition 1960s:')
disp('   ')
disp(['R^2(G):          ',num2str(G_1960)])
disp(['R^2(e):          ',num2str(idio_1960)])
disp('   ')

G_1970 = [mean(Fraction_G_2_5(40:79)) mean(Fraction_G_mean(40:79)) mean(Fraction_G_97_5(40:79))];
idio_1970 = [mean(Fraction_idiosyncratic_shock_2_5(40:79)) mean(Fraction_idiosyncratic_shock_mean(40:79)) mean(Fraction_idiosyncratic_shock_97_5(40:79))];

disp('Aggregate Variance Decomposition 1970s:')
disp('   ')
disp(['R^2(G):          ',num2str(G_1970)])
disp(['R^2(e):          ',num2str(idio_1970)])
disp('   ')

G_1980 = [mean(Fraction_G_2_5(80:119)) mean(Fraction_G_mean(80:119)) mean(Fraction_G_97_5(80:119))];
idio_1980 = [mean(Fraction_idiosyncratic_shock_2_5(80:119)) mean(Fraction_idiosyncratic_shock_mean(80:119)) mean(Fraction_idiosyncratic_shock_97_5(80:119))];

disp('Aggregate Variance Decomposition 1980s:')
disp('   ')
disp(['R^2(G):          ',num2str(G_1980)])
disp(['R^2(e):          ',num2str(idio_1980)])
disp('   ')

G_1990 = [mean(Fraction_G_2_5(120:159)) mean(Fraction_G_mean(120:159)) mean(Fraction_G_97_5(120:159))];
idio_1990 = [mean(Fraction_idiosyncratic_shock_2_5(120:159)) mean(Fraction_idiosyncratic_shock_mean(120:159)) mean(Fraction_idiosyncratic_shock_97_5(120:159))];

disp('Aggregate Variance Decomposition 1990s:')
disp('   ')
disp(['R^2(G):          ',num2str(G_1990)])
disp(['R^2(e):          ',num2str(idio_1990)])
disp('   ')


G_2000 = [mean(Fraction_G_2_5(160:199)) mean(Fraction_G_mean(160:199)) mean(Fraction_G_97_5(160:199))];
idio_2000 = [mean(Fraction_idiosyncratic_shock_2_5(160:199)) mean(Fraction_idiosyncratic_shock_mean(160:199)) mean(Fraction_idiosyncratic_shock_97_5(160:199))];

disp('Aggregate Variance Decomposition 2000s:')
disp('   ')
disp(['R^2(G):          ',num2str(G_2000)])
disp(['R^2(e):          ',num2str(idio_2000)])
disp('   ')

disp('   ')
disp('   ')
disp('Forster et al. sample periods   ')
disp('   ')

G_1972_1983 = [mean(Fraction_G_2_5(48:95)) mean(Fraction_G_mean(48:95)) mean(Fraction_G_97_5(48:95))];
idio_1972_1983 = [mean(Fraction_idiosyncratic_shock_2_5(48:95)) mean(Fraction_idiosyncratic_shock_mean(48:95)) mean(Fraction_idiosyncratic_shock_97_5(48:95))];

disp('Aggregate Variance Decomposition 1972-1983:')
disp('   ')
disp(['R^2(G):          ',num2str(G_1972_1983)])
disp(['R^2(e):          ',num2str(idio_1972_1983)])
disp('   ')

G_1984_2007 = [mean(Fraction_G_2_5(96:191)) mean(Fraction_G_mean(96:191)) mean(Fraction_G_97_5(96:191))];
idio_1984_2007 = [mean(Fraction_idiosyncratic_shock_2_5(96:191)) mean(Fraction_idiosyncratic_shock_mean(96:191)) mean(Fraction_idiosyncratic_shock_97_5(96:191))];

disp('Aggregate Variance Decomposition 1984-2007:')
disp('   ')
disp(['R^2(G):          ',num2str(G_1984_2007)])
disp(['R^2(e):          ',num2str(idio_1984_2007)])
disp('   ')

diary off

clear

load data_input_fs
load data_input

Number_datasets = 25;
Number_burnin_datasets = 5;
Number_repetitions = 1000;
burnin_total = Number_burnin_datasets*Number_repetitions;

Total_number_repetitions = Number_datasets*Number_repetitions - burnin_total;
 
Macro_var_draw = zeros(N,Total_number_repetitions);
G_var_draw = zeros(N,Total_number_repetitions);
Y_var_draw = zeros(N,Total_number_repetitions);

total_var_draw = zeros(N,Total_number_repetitions);
total_var_draw_macro = zeros(N,Total_number_repetitions);

fraction_macro_draw = zeros(N,Total_number_repetitions);
fraction_G_draw_macro = zeros(N,Total_number_repetitions);
fraction_Y_draw_macro = zeros(N,Total_number_repetitions);

real_gdp_growth=[0.010981	0.009204	0.002427	0.012985	0.012453	0.018654	0.007574	0.022196	0.01142	0.013497	0.002768	0.024265	0.013477	0.02009	0.02384	0.024249	0.003323	0.006555	0.008069	0.008771	0.000208	0.007946	0.007601	0.020399	0.016836	0.006818	0.004323	0.015627	0.002908	0.006304	-0.004708	-0.00157	0.001811	0.008865	-0.010661	0.027202	0.005657	0.007951	0.002775	0.017723	0.023439	0.009538	0.016337	0.025258	0.011501	-0.00535	0.009493	-0.008808	0.002557	-0.009937	-0.003943	-0.012238	0.007613	0.016703	0.012978	0.022478	0.007492	0.004887	0.007236	0.011541	0.019678	0.017726	-0.000207	0.003409	0.038585	0.009756	0.01314	0.001671	0.000938	0.007163	0.002748	0.003216	-0.020708	-0.00186	0.018327	0.020567	-0.008011	0.012077	-0.012536	-0.016547	0.005404	-0.003863	0.000789	0.012361	0.022228	0.019528	0.02046	0.01921	0.017118	0.009671	0.008108	0.009392	0.008431	0.0155	0.007561	0.009563	0.004009	0.009595	0.004822	0.005529	0.010578	0.008636	0.016966	0.005159	0.012761	0.00515	0.013264	0.009345	0.007455	0.0079	0.002181	0.010392	0.003967	-0.000015	-0.0088	-0.004856	0.006727	0.004203	0.003912	0.010917	0.010569	0.010265	0.010469	0.001836	0.006378	0.00525	0.013119	0.009688	0.013586	0.00642	0.011045	0.00245	0.002147	0.008369	0.006948	0.006827	0.01714	0.008661	0.010857	0.007662	0.014718	0.012473	0.007642	0.009402	0.008952	0.013109	0.017162	0.008869	0.007786	0.012635	0.0178	0.002608	0.019319	0.00084	0.005908	-0.003291	0.006533	-0.002763	0.003493	0.008505	0.005305	0.005059	0.000343	0.004162	0.008436	0.016322	0.009004	0.006568	0.006414	0.007415	0.008152	0.010262	0.004442	0.007909	0.005121	0.012547	0.00405	0.000133	0.006773	0.001355	0.008954	0.007281	0.004221	-0.004447	0.003283	-0.009325	-0.023276	-0.013484	-0.000786	0.003594	0.009863	0.005771	0.005548	0.006424	0.005913	0.000195	0.006116	0.003181	0.010029]';

weight = zeros(N,1);
sa_data_final(:,2) = sa_data_final(:,2) - min(sa_data_final(:,2))+1;
tenure = tenure_final(:,2)-1; % Because we lose one quarter in the growth calculation
ii=1;
for i=1:N
    tenure_X = tenure(i,1);    
    time_X = sa_data_final(ii,2); 
    weight(i,time_X:(time_X+tenure_X-1)) = sa_data_final(ii:(ii+tenure_X-1),5);
    ii = ii + tenure_X;
end
aggregate_revenues = sum(weight.*Y,1)';
 

indice_progressivo = 1;
for t =(Number_burnin_datasets+1):Number_datasets
    disp('   ')    
    disp(['dataset: ',num2str(t)])    
    disp('   ')

    h=t-Number_burnin_datasets;
    str = num2str(t);
    load(str)  
    for index_save =1:Number_repetitions
        correlation_G_gdp(indice_progressivo,1) = corr(G_draw_save(1,:,index_save)',real_gdp_growth);
        correlation_G_aggregate_reveneus(indice_progressivo,1) = corr(G_draw_save(1,:,index_save)',aggregate_revenues);
        G_draw_save_temp(1,:,indice_progressivo) = G_draw_save(1,:,index_save);                       

        x = Macro_shocks';
        y = G_draw_save(1,:,index_save)';
        sum_of_squares = (y-mean(y))'*(y-mean(y));
        coeff = (x'*x)\(x'*y);
        R_squared(indice_progressivo,1) = 1 - ((y-x*coeff)'*(y-x*coeff))/(sum_of_squares);
        number_of_regressors = 25;
        adj_R_squared(indice_progressivo,1) = R_squared(indice_progressivo,1) - (1 - R_squared(indice_progressivo,1))*number_of_regressors/(length(x)-number_of_regressors-1);

        x = Macro_shocks(1:5:end,:)';
        coeff = (x'*x)\(x'*y);
        R_squared(indice_progressivo,2) = 1 - ((y-x*coeff)'*(y-x*coeff))/(sum_of_squares);
        number_of_regressors = 5;
        adj_R_squared(indice_progressivo,2) = R_squared(indice_progressivo,2) - (1 - R_squared(indice_progressivo,2))*number_of_regressors/(length(x)-number_of_regressors-1);

        x = Macro_shocks(2:5:end,:)';
        coeff = (x'*x)\(x'*y);
        R_squared(indice_progressivo,3) = 1 - ((y-x*coeff)'*(y-x*coeff))/(sum_of_squares);
        number_of_regressors = 5;
        adj_R_squared(indice_progressivo,3) = R_squared(indice_progressivo,3) - (1 - R_squared(indice_progressivo,3))*number_of_regressors/(length(x)-number_of_regressors-1);
        
        x = Macro_shocks(3:5:end,:)';
        coeff = (x'*x)\(x'*y);
        R_squared(indice_progressivo,4) = 1 - ((y-x*coeff)'*(y-x*coeff))/(sum_of_squares);
        number_of_regressors = 5;
        adj_R_squared(indice_progressivo,4) = R_squared(indice_progressivo,4) - (1 - R_squared(indice_progressivo,4))*number_of_regressors/(length(x)-number_of_regressors-1);

        x = Macro_shocks(4:5:end,:)';
        coeff = (x'*x)\(x'*y);
        R_squared(indice_progressivo,5) = 1 - ((y-x*coeff)'*(y-x*coeff))/(sum_of_squares);
        number_of_regressors = 5;
        adj_R_squared(indice_progressivo,5) = R_squared(indice_progressivo,5) - (1 - R_squared(indice_progressivo,5))*number_of_regressors/(length(x)-number_of_regressors-1);

        x = Macro_shocks(5:5:end,:)';
        coeff = (x'*x)\(x'*y);
        R_squared(indice_progressivo,6) = 1 - ((y-x*coeff)'*(y-x*coeff))/(sum_of_squares);
         number_of_regressors = 5;
        adj_R_squared(indice_progressivo,6) = R_squared(indice_progressivo,6) - (1 - R_squared(indice_progressivo,6))*number_of_regressors/(length(x)-number_of_regressors-1);
       
        indice_progressivo = indice_progressivo + 1;                
    end
end
G_draw_2_5 = prctile(G_draw_save_temp,2.5,3);
G_draw_97_5 = prctile(G_draw_save_temp,97.5,3);
G_draw_mean = mean(G_draw_save_temp,3);

A = -G_draw_2_5'/std(G_draw_2_5);
B = -G_draw_mean'/std(G_draw_mean);
C = -G_draw_97_5'/std(G_draw_97_5);
D = real_gdp_growth/std(real_gdp_growth);
tt=[1:199]';

first_coefficient_estimate = [prctile(correlation_G_gdp,2.5) mean(correlation_G_gdp)  prctile(correlation_G_gdp,97.5)];
disp(['The correlation with GDP is:     ',num2str(first_coefficient_estimate,3)])
  
first_coefficient_estimate = [prctile(correlation_G_aggregate_reveneus,2.5) mean(correlation_G_aggregate_reveneus)  prctile(correlation_G_aggregate_reveneus,97.5)];
disp(['The correlation with aggregate revenues:     ',num2str(first_coefficient_estimate,3)])
  
R_squared_2_5 = prctile(R_squared,2.5,1);
R_squared_97_5 = prctile(R_squared,97.5,1);
R_squared_mean = mean(R_squared,1);
disp(['The R_squared is:           ',num2str(R_squared_mean,3)])

adj_R_squared_2_5 = prctile(adj_R_squared,2.5,1);
adj_R_squared_97_5 = prctile(adj_R_squared,97.5,1);
adj_R_squared_mean = mean(adj_R_squared,1);
disp(['The R_squared is:           ',num2str(adj_R_squared_mean,3)])

clear
diary granular_residual_diary

load data_input_5_2_1_fs
index_top500 =  index.*index_top500;
number_of_regressors = 3;

Number_datasets = 25;
Number_burnin_datasets = 5;
Number_repetitions = 1000;
burnin_total = Number_burnin_datasets*Number_repetitions;

Total_number_repetitions = Number_datasets*Number_repetitions - burnin_total;

idiosyncratic_schock = zeros(N,T,Number_repetitions);
coeff_store = zeros(4,Number_repetitions*(Number_datasets-Number_burnin_datasets));     
R_squared = zeros(Number_repetitions*(Number_datasets-Number_burnin_datasets),1);
adj_R_squared = zeros(Number_repetitions*(Number_datasets-Number_burnin_datasets),1);

real_gdp_growth=[0.010981	0.009204	0.002427	0.012985	0.012453	0.018654	0.007574	0.022196	0.01142	0.013497	0.002768	0.024265	0.013477	0.02009	0.02384	0.024249	0.003323	0.006555	0.008069	0.008771	0.000208	0.007946	0.007601	0.020399	0.016836	0.006818	0.004323	0.015627	0.002908	0.006304	-0.004708	-0.00157	0.001811	0.008865	-0.010661	0.027202	0.005657	0.007951	0.002775	0.017723	0.023439	0.009538	0.016337	0.025258	0.011501	-0.00535	0.009493	-0.008808	0.002557	-0.009937	-0.003943	-0.012238	0.007613	0.016703	0.012978	0.022478	0.007492	0.004887	0.007236	0.011541	0.019678	0.017726	-0.000207	0.003409	0.038585	0.009756	0.01314	0.001671	0.000938	0.007163	0.002748	0.003216	-0.020708	-0.00186	0.018327	0.020567	-0.008011	0.012077	-0.012536	-0.016547	0.005404	-0.003863	0.000789	0.012361	0.022228	0.019528	0.02046	0.01921	0.017118	0.009671	0.008108	0.009392	0.008431	0.0155	0.007561	0.009563	0.004009	0.009595	0.004822	0.005529	0.010578	0.008636	0.016966	0.005159	0.012761	0.00515	0.013264	0.009345	0.007455	0.0079	0.002181	0.010392	0.003967	-0.000015	-0.0088	-0.004856	0.006727	0.004203	0.003912	0.010917	0.010569	0.010265	0.010469	0.001836	0.006378	0.00525	0.013119	0.009688	0.013586	0.00642	0.011045	0.00245	0.002147	0.008369	0.006948	0.006827	0.01714	0.008661	0.010857	0.007662	0.014718	0.012473	0.007642	0.009402	0.008952	0.013109	0.017162	0.008869	0.007786	0.012635	0.0178	0.002608	0.019319	0.00084	0.005908	-0.003291	0.006533	-0.002763	0.003493	0.008505	0.005305	0.005059	0.000343	0.004162	0.008436	0.016322	0.009004	0.006568	0.006414	0.007415	0.008152	0.010262	0.004442	0.007909	0.005121	0.012547	0.00405	0.000133	0.006773	0.001355	0.008954	0.007281	0.004221	-0.004447	0.003283	-0.009325	-0.023276	-0.013484	-0.000786	0.003594	0.009863	0.005771	0.005548	0.006424	0.005913	0.000195	0.006116	0.003181	0.010029]';
y = real_gdp_growth(3:end);
n_obs = length(y);
sum_of_squares = (y-mean(y))'*(y-mean(y));


indice_progressivo = 1;
for t =(Number_burnin_datasets+1):Number_datasets

    h=t-Number_burnin_datasets;
    str = num2str(t);
    load(str)   
    for index_save =1:Number_repetitions
        e_Y_draw = Y - F_draw_save(:,index_save)*G_draw_save(1,:,index_save);            
        e_Y_draw = index.*e_Y_draw;
        for i=1:N
            idiosyncratic_schock(i,tenure_Y(i,1),index_save) = e_Y_draw(i,tenure_Y(i,1));
            idiosyncratic_schock(i,(tenure_Y(i,1)+1):tenure_Y(i,2),index_save) = e_Y_draw(i,(tenure_Y(i,1)+1):tenure_Y(i,2)) - psi_Y_save(i,index_save)*e_Y_draw(i,tenure_Y(i,1):(tenure_Y(i,2)-1));            
        end
        idiosyncratic_schock(:,:,index_save) = index_top500.*idiosyncratic_schock(:,:,index_save);
        temp = lag_weight.*idiosyncratic_schock(:,:,index_save);
        granular_residual = sum(temp,1)';
        x = [ones(size(granular_residual(3:end))) granular_residual(3:end) granular_residual(2:end-1)  granular_residual(1:end-2) ] ;
        coeff_store(:,indice_progressivo) = (x'*x)\(x'*y);
        R_squared(indice_progressivo) = 1 - ((y-x*coeff_store(:,indice_progressivo))'*(y-x*coeff_store(:,indice_progressivo)))/(sum_of_squares);
        adj_R_squared(indice_progressivo) = R_squared(indice_progressivo) - (1 - R_squared(indice_progressivo))*number_of_regressors/(length(x)-number_of_regressors-1);
        indice_progressivo = indice_progressivo + 1;
    end
    clear  psi_G_save psi_Y_save sigma_square_G_save sigma_square_Y_save G_draw_save A_draw_save B_draw_save C_draw_save D_draw_save E_draw_save

end

constant_coefficient_2_5 = prctile(coeff_store(1,:)',2.5);
constant_coefficient_97_5 = prctile(coeff_store(1,:)',97.5);
constant_coefficient_mean = mean(coeff_store(1,:));
constant_estimate = [constant_coefficient_2_5 constant_coefficient_mean constant_coefficient_97_5 ];
disp(['The constant is:           ',num2str(constant_estimate,3)])

first_coefficient_2_5 = prctile(coeff_store(2,:)',2.5);
first_coefficient_97_5 = prctile(coeff_store(2,:)',97.5);
first_coefficient_mean = mean(coeff_store(2,:));  
first_coefficient_estimate = [first_coefficient_2_5 first_coefficient_mean first_coefficient_97_5];
disp(['The first estimate is:     ',num2str(first_coefficient_estimate,3)])

second_coefficient_2_5 = prctile(coeff_store(3,:)',2.5);
second_coefficient_97_5 = prctile(coeff_store(3,:)',97.5);
second_coefficient_mean = mean(coeff_store(3,:));
second_coefficient_estimate = [second_coefficient_2_5 second_coefficient_mean second_coefficient_97_5];
disp(['The second estimate is:    ',num2str(second_coefficient_estimate,3)])

third_coefficient_2_5 = prctile(coeff_store(4,:)',2.5);
third_coefficient_97_5 = prctile(coeff_store(4,:)',97.5);
third_coefficient_mean = mean(coeff_store(4,:));
third_coefficient_estimate = [third_coefficient_2_5 third_coefficient_mean third_coefficient_97_5];
disp(['The third estimate is:     ',num2str(third_coefficient_estimate,3)])

R_squared_2_5 = prctile(R_squared,2.5);
R_squared_97_5 = prctile(R_squared,97.5);
R_squared_mean = mean(R_squared);
R_squared_estimate = [R_squared_2_5 R_squared_mean R_squared_97_5 ];
disp(['The R_squared is:           ',num2str(R_squared_estimate,3)])

adj_R_squared_2_5 = prctile(adj_R_squared,2.5);
adj_R_squared_97_5 = prctile(adj_R_squared,97.5);
adj_R_squared_mean = mean(adj_R_squared);
adj_R_squared_estimate = [adj_R_squared_2_5 adj_R_squared_mean adj_R_squared_97_5 ];
disp(['The Adjusted R_squared is:  ',num2str(adj_R_squared_estimate,3)])

clear all

load data_input_fs
index_top500 =  index_nofinance.*index.*index_top500;

Number_datasets = 25;
Number_burnin_datasets = 5;
Number_repetitions = 1000;
burnin_total = Number_burnin_datasets*Number_repetitions;
number_of_regressors = 3;

Total_number_repetitions = Number_datasets*Number_repetitions - burnin_total;

idiosyncratic_schock = zeros(N,T,Number_repetitions);
coeff_store = zeros(4,Number_repetitions*(Number_datasets-Number_burnin_datasets));     
R_squared = zeros(Number_repetitions*(Number_datasets-Number_burnin_datasets),1);
adj_R_squared = zeros(Number_repetitions*(Number_datasets-Number_burnin_datasets),1);

real_gdp_growth=[0.010981	0.009204	0.002427	0.012985	0.012453	0.018654	0.007574	0.022196	0.01142	0.013497	0.002768	0.024265	0.013477	0.02009	0.02384	0.024249	0.003323	0.006555	0.008069	0.008771	0.000208	0.007946	0.007601	0.020399	0.016836	0.006818	0.004323	0.015627	0.002908	0.006304	-0.004708	-0.00157	0.001811	0.008865	-0.010661	0.027202	0.005657	0.007951	0.002775	0.017723	0.023439	0.009538	0.016337	0.025258	0.011501	-0.00535	0.009493	-0.008808	0.002557	-0.009937	-0.003943	-0.012238	0.007613	0.016703	0.012978	0.022478	0.007492	0.004887	0.007236	0.011541	0.019678	0.017726	-0.000207	0.003409	0.038585	0.009756	0.01314	0.001671	0.000938	0.007163	0.002748	0.003216	-0.020708	-0.00186	0.018327	0.020567	-0.008011	0.012077	-0.012536	-0.016547	0.005404	-0.003863	0.000789	0.012361	0.022228	0.019528	0.02046	0.01921	0.017118	0.009671	0.008108	0.009392	0.008431	0.0155	0.007561	0.009563	0.004009	0.009595	0.004822	0.005529	0.010578	0.008636	0.016966	0.005159	0.012761	0.00515	0.013264	0.009345	0.007455	0.0079	0.002181	0.010392	0.003967	-0.000015	-0.0088	-0.004856	0.006727	0.004203	0.003912	0.010917	0.010569	0.010265	0.010469	0.001836	0.006378	0.00525	0.013119	0.009688	0.013586	0.00642	0.011045	0.00245	0.002147	0.008369	0.006948	0.006827	0.01714	0.008661	0.010857	0.007662	0.014718	0.012473	0.007642	0.009402	0.008952	0.013109	0.017162	0.008869	0.007786	0.012635	0.0178	0.002608	0.019319	0.00084	0.005908	-0.003291	0.006533	-0.002763	0.003493	0.008505	0.005305	0.005059	0.000343	0.004162	0.008436	0.016322	0.009004	0.006568	0.006414	0.007415	0.008152	0.010262	0.004442	0.007909	0.005121	0.012547	0.00405	0.000133	0.006773	0.001355	0.008954	0.007281	0.004221	-0.004447	0.003283	-0.009325	-0.023276	-0.013484	-0.000786	0.003594	0.009863	0.005771	0.005548	0.006424	0.005913	0.000195	0.006116	0.003181	0.010029]';
y = real_gdp_growth(3:end);
n_obs = length(y);
sum_of_squares = (y-mean(y))'*(y-mean(y));


indice_progressivo = 1;
for t =(Number_burnin_datasets+1):Number_datasets

    h=t-Number_burnin_datasets;
    str = num2str(t);
    load(str)   
    for index_save =1:Number_repetitions
        e_Y_draw = Y - F_draw_save(:,index_save)*G_draw_save(1,:,index_save);            
        e_Y_draw = index.*e_Y_draw;
        for i=1:N
            idiosyncratic_schock(i,tenure_Y(i,1),index_save) = e_Y_draw(i,tenure_Y(i,1));
            idiosyncratic_schock(i,(tenure_Y(i,1)+1):tenure_Y(i,2),index_save) = e_Y_draw(i,(tenure_Y(i,1)+1):tenure_Y(i,2)) - psi_Y_save(i,index_save)*e_Y_draw(i,tenure_Y(i,1):(tenure_Y(i,2)-1));            
        end
        pippoprova = index_top500.*idiosyncratic_schock(:,:,index_save);
        pippoprova(abs(Y)>0.20) = 0;
        temp = lag_weight.*pippoprova;
        granular_residual = sum(temp,1)';
        x = [ones(size(granular_residual(3:end))) granular_residual(3:end) granular_residual(2:end-1)  granular_residual(1:end-2) ] ;
        coeff_store(:,indice_progressivo) = (x'*x)\(x'*y);
        R_squared(indice_progressivo) = 1 - ((y-x*coeff_store(:,indice_progressivo))'*(y-x*coeff_store(:,indice_progressivo)))/(sum_of_squares);
        adj_R_squared(indice_progressivo) = R_squared(indice_progressivo) - (1 - R_squared(indice_progressivo))*number_of_regressors/(length(x)-number_of_regressors-1);
        indice_progressivo = indice_progressivo + 1;
    end
    clear  psi_G_save psi_Y_save sigma_square_G_save sigma_square_Y_save G_draw_save A_draw_save B_draw_save C_draw_save D_draw_save E_draw_save

end

constant_coefficient_2_5 = prctile(coeff_store(1,:)',2.5);
constant_coefficient_97_5 = prctile(coeff_store(1,:)',97.5);
constant_coefficient_mean = mean(coeff_store(1,:));
constant_estimate = [constant_coefficient_2_5 constant_coefficient_mean constant_coefficient_97_5 ];
disp(['The constant is:           ',num2str(constant_estimate,3)])

first_coefficient_2_5 = prctile(coeff_store(2,:)',2.5);
first_coefficient_97_5 = prctile(coeff_store(2,:)',97.5);
first_coefficient_mean = mean(coeff_store(2,:));  
first_coefficient_estimate = [first_coefficient_2_5 first_coefficient_mean first_coefficient_97_5];
disp(['The first estimate is:     ',num2str(first_coefficient_estimate,3)])

second_coefficient_2_5 = prctile(coeff_store(3,:)',2.5);
second_coefficient_97_5 = prctile(coeff_store(3,:)',97.5);
second_coefficient_mean = mean(coeff_store(3,:));
second_coefficient_estimate = [second_coefficient_2_5 second_coefficient_mean second_coefficient_97_5];
disp(['The second estimate is:    ',num2str(second_coefficient_estimate,3)])

third_coefficient_2_5 = prctile(coeff_store(4,:)',2.5);
third_coefficient_97_5 = prctile(coeff_store(4,:)',97.5);
third_coefficient_mean = mean(coeff_store(4,:));
third_coefficient_estimate = [third_coefficient_2_5 third_coefficient_mean third_coefficient_97_5];
disp(['The third estimate is:     ',num2str(third_coefficient_estimate,3)])

R_squared_2_5 = prctile(R_squared,2.5);
R_squared_97_5 = prctile(R_squared,97.5);
R_squared_mean = mean(R_squared);
R_squared_estimate = [R_squared_2_5 R_squared_mean R_squared_97_5 ];
disp(['The R_squared is:           ',num2str(R_squared_estimate,3)])

adj_R_squared_2_5 = prctile(adj_R_squared,2.5);
adj_R_squared_97_5 = prctile(adj_R_squared,97.5);
adj_R_squared_mean = mean(adj_R_squared);
adj_R_squared_estimate = [adj_R_squared_2_5 adj_R_squared_mean adj_R_squared_97_5 ];
disp(['The Adjusted R_squared is:  ',num2str(adj_R_squared_estimate,3)])

diary off


seconds = toc;
minutes = seconds/60;
hours = minutes/60;

disp('   ')
disp(['The number of minutes is:     ',num2str(minutes)])
disp(['The number of hours is:       ',num2str(hours)])