***************************************************************
*** Firm Dynamics and the Origins of Aggregate Fluctuations ***
*** Andrea Stella                                           ***
*** Last Updated: 04.16.2015                                ***
***************************************************************
*The views in this paper are solely the responsibility of the author and 
*should not be interpreted as reflecting the views of the Board of 
*Governors of the Federal Reserve System or of any other person 
*associated with the Federal Reserve System
clear
capture log close
set more off
log using quarterly_regressions_log, replace



use inputdata, replace
egen interaction = group(time sic_2digit)
sum interaction
set matsize 5000
areg rev_growth, a(interaction)
predict res_shock, r
corr rev_growth res_shock
save temp_reg_quarterly, replace


use inputdata, replace
egen interaction = group(year sic_2digit)
sum interaction
set matsize 5000
areg rev_growth, a(interaction)
predict res_shock, r
corr rev_growth res_shock
save temp_reg_annual, replace


use temp_reg_quarterly, replace
keep if index_top500 ==1
gen granular = lw_it*rev_growth
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

use temp_reg_quarterly, replace
keep if index_top500 ==1
gen granular = lw_it*res_shock
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular


use temp_reg_quarterly, replace
keep if index_top500 ==1
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*rev_growth
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

use temp_reg_quarterly, replace
keep if index_top500 ==1
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*res_shock
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular




use temp_reg_annual, replace
keep if index_top500 ==1
gen granular = lw_it*rev_growth
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

use temp_reg_annual, replace
keep if index_top500 ==1
gen granular = lw_it*res_shock
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular


use temp_reg_annual, replace
keep if index_top500 ==1
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*rev_growth
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

use temp_reg_annual, replace
keep if index_top500 ==1
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
drop if rev_growth>0.2 | rev_growth<-0.2
gen granular = lw_it*res_shock
collapse (sum) granular, by(time)
sort time
merge time using gdp_growth
tsset time
reg real_gdp_growth granular l.granular l2.granular

log close
