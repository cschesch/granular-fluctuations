clear
tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Firm Dynamics and the Origins of Aggregate Fluctuations %%%
%%% Andrea Stella                                           %%%
%%% Last Updated: 04.16.2015                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The views in this paper are solely the responsibility of the author and 
%should not be interpreted as reflecting the views of the Board of 
%Governors of the Federal Reserve System or of any other person 
%associated with the Federal Reserve System.

disp('   ')
disp('   ')
disp('   ')

% Load data
rng('default')

load data_input_fs

% Number of simulations
N_rep = 100001;
burnin = 1001;

N_rep_save = burnin;

% Display information
disp('   ')
disp(['The number of firms is:       ',num2str(N)])
disp(['The number of periods is:     ',num2str(T)])
disp(['The number of repetitions is: ',num2str(N_rep)])

count = 2;
dis_count = 2;
repetition_for = 2;
name_dataset= 0;

count_sign = 0;

for repetition=2:N_rep

    %%%% Draw Common Factors %%%%
    [G_temp] = draw_macro(T,Y,F_draw(:,repetition_for-1),psi_G_draw(repetition_for-1),psi_Y_draw(:,repetition_for-1),sigma_square_G_draw(repetition_for-1),sigma_square_Y_draw(:,repetition_for-1),index);
    G_draw(1,:,repetition_for) = sqrt(0.01)*G_temp;
       
%%%% Draw coefficients Common Components %%%%

        T_temp_chib = T;
        Y_tilde = G_draw(1,:,repetition_for)';
        y_tilde_1 = Y_tilde(1);
        e_star = zeros(T_temp_chib-1,1);
        for t_star = 2:T_temp_chib
            e_star(t_star-1) = Y_tilde(t_star);
        end
        E_star = [y_tilde_1; e_star(1:length(e_star)-1)];

        v_i = prior_v_i + inv(sigma_square_G_draw(repetition_for-1))*(E_star')*E_star;
        phi_hat_i = inv(v_i)*(prior_v_i*prior_phi_i+inv(sigma_square_G_draw(repetition_for-1))*(E_star')*e_star);
        chol_sigma = chol(inv(v_i));
        phi_new = phi_hat_i + chol_sigma*randn(1,1);
        while (phi_new<=-1 || phi_new>=1)
            phi_new = phi_hat_i + chol_sigma*randn(1,1);
        end
        Psi_phi = (-1/(2*sigma_square_G_draw(repetition_for-1)))*(y_tilde_1)^2*(1-phi_new^2);
        Psi_phi_old = (-1/(2*sigma_square_G_draw(repetition_for-1)))*(y_tilde_1)^2*(1-psi_G_draw(repetition_for-1)^2);
        ratio = (sqrt(abs((1-phi_new^2)))/sqrt(abs((1-psi_G_draw(repetition_for-1)^2))))*exp(Psi_phi-Psi_phi_old);
        omega = min([ratio 1]);
        weight = binornd(1,omega);
        psi_G_draw(repetition_for) = weight*phi_new + (1-weight)*psi_G_draw(repetition_for-1);
    
        Sigma = 1/(1-psi_G_draw(repetition_for)^2);
        Q = chol(Sigma);
        y_tilde_star_1 = Q\y_tilde_1;
        y_tilde_star_2 = zeros(T_temp_chib-1,1);
        for t_star = 2:T_temp_chib
            y_tilde_star_2(t_star-1) = Y_tilde(t_star) - psi_G_draw(repetition_for)*Y_tilde(t_star-1);
        end
        y_tilde_star = [y_tilde_star_1;y_tilde_star_2];
        a_gamma = (prior_v_bar + T_temp_chib)/2;
        b_gamma = 2*inv(prior_delta_bar + ((y_tilde_star)'*(y_tilde_star)));
        sigma_square_G_draw(repetition_for) = 1/gamrnd(a_gamma,b_gamma);

    
%%%% Draw idiosyncratic coefficients %%%%

    for jj=1:N

        T_temp_chib = tenure_Y(jj,2)-tenure_Y(jj,1)+1;
        Y_tilde = zeros(T_temp_chib,1);
        for t_star = (tenure_Y(jj,1)):tenure_Y(jj,2)
            h_t_star = t_star - tenure_Y(jj,1)+1;
            Y_tilde(h_t_star) = (Y(jj,t_star))';
        end       
        X_tilde = G_draw(1,tenure_Y(jj,1):tenure_Y(jj,2))';
        prior_F = zeros(size(X_tilde,2),1);        
        prior_F_var = 0.1*eye(size(X_tilde,2));
        y_tilde_1 = Y_tilde(1);
        x_tilde_1 = X_tilde(1,:);
        Sigma = 1/(1-psi_Y_draw(jj,repetition_for-1)^2);
        Q = chol(Sigma);
        y_tilde_star_1 = Q\y_tilde_1;
        x_tilde_star_1 = Q\x_tilde_1;
        y_tilde_star_2 = zeros(T_temp_chib-1,1);
        x_tilde_star_2 = zeros(T_temp_chib-1,size(X_tilde,2));            
        e_star = zeros(T_temp_chib-1,1);
        for t_star = 2:T_temp_chib
            y_tilde_star_2(t_star-1) = Y_tilde(t_star) - psi_Y_draw(jj,repetition_for-1)*Y_tilde(t_star-1);
            x_tilde_star_2(t_star-1,:) = X_tilde(t_star,:) - psi_Y_draw(jj,repetition_for-1)*X_tilde(t_star-1,:);
        end
        y_tilde_star = [y_tilde_star_1;y_tilde_star_2];
        x_tilde_star = [x_tilde_star_1;x_tilde_star_2];
        F_var = prior_F_var + inv(sigma_square_Y_draw(jj,repetition_for-1))*(x_tilde_star')*x_tilde_star ;
        chol_sigma = chol(inv(F_var));
        alpha_draw = inv(F_var)*(prior_F_var*prior_F +inv(sigma_square_Y_draw(jj,repetition_for-1))*(x_tilde_star')*y_tilde_star) + chol_sigma*randn(size(X_tilde,2),1);
        F_draw(jj,repetition_for) = alpha_draw;

        for t_star = 2:T_temp_chib
            e_star(t_star-1) = Y_tilde(t_star) - X_tilde(t_star,:)*alpha_draw;
        end
        E_star = [(y_tilde_1 - x_tilde_1*alpha_draw);e_star(1:length(e_star)-1)];
        
        v_i = prior_v_i + inv(sigma_square_Y_draw(jj,repetition_for-1))*(E_star')*E_star;
        phi_hat_i = inv(v_i)*(prior_v_i*prior_phi_i+inv(sigma_square_Y_draw(jj,repetition_for-1))*(E_star')*e_star);
        chol_sigma = chol(inv(v_i));
        phi_new = phi_hat_i + chol_sigma*randn(1,1);
        while (phi_new<=-1 || phi_new>=1)
            phi_new = phi_hat_i + chol_sigma*randn(1,1);
        end
        Psi_phi = (-1/(2*sigma_square_Y_draw(jj,repetition_for-1)))*(y_tilde_1 - x_tilde_1*alpha_draw)^2*(1-phi_new^2);
        Psi_phi_old = (-1/(2*sigma_square_Y_draw(jj,repetition_for-1)))*(y_tilde_1 - x_tilde_1*alpha_draw)^2*(1-psi_Y_draw(jj,repetition_for-1)^2);
        ratio = (sqrt(abs((1-phi_new^2)))/sqrt(abs((1-psi_Y_draw(jj,repetition_for-1)^2))))*exp(Psi_phi-Psi_phi_old);
        omega = min([ratio 1]);
        weight = binornd(1,omega);
        psi_Y_draw(jj,repetition_for) = weight*phi_new + (1-weight)*psi_Y_draw(jj,repetition_for-1);
    
        Sigma = 1/(1-psi_Y_draw(jj,repetition_for)^2);
        Q = chol(Sigma);
        y_tilde_star_1 = Q\y_tilde_1;
        x_tilde_star_1 = Q\x_tilde_1;
        y_tilde_star_2 = zeros(T_temp_chib-1,1);
        x_tilde_star_2 = zeros(T_temp_chib-1,size(X_tilde,2));
        for t_star = 2:T_temp_chib
            y_tilde_star_2(t_star-1) = Y_tilde(t_star) - psi_Y_draw(jj,repetition_for)*Y_tilde(t_star-1);
            x_tilde_star_2(t_star-1,:) = X_tilde(t_star,:) - psi_Y_draw(jj,repetition_for)*X_tilde(t_star-1,:);
        end
        y_tilde_star = [y_tilde_star_1;y_tilde_star_2];
        x_tilde_star = [x_tilde_star_1;x_tilde_star_2];
        a_gamma = (prior_v_bar + T_temp_chib)/2;
        b_gamma = 2*inv(prior_delta_bar + ((y_tilde_star-x_tilde_star*alpha_draw)'*(y_tilde_star-x_tilde_star*alpha_draw)));
        sigma_square_Y_draw(jj,repetition_for) = 1/gamrnd(a_gamma,b_gamma);
        
    end
%} 
    
    if count == N_rep_save
        disp('   ')
        disp(['number of repetition: ',num2str(dis_count)])
        disp('   ')

        disp('   ')        
        disp(['The number of sign changes are ',num2str(count_sign)])        
        disp('   ')
        count_sign = 0;
        
        count=1;
        repetition_for=1;
        name_dataset = name_dataset+1;
        str = num2str(name_dataset);
        rand_seed=rng;
        psi_G_save = psi_G_draw(2:N_rep_save);
        psi_Y_save = psi_Y_draw(:,2:N_rep_save);
        sigma_square_G_save = sigma_square_G_draw(2:N_rep_save);
        sigma_square_Y_save = sigma_square_Y_draw(:,2:N_rep_save);
        G_draw_save = G_draw(1,:,2:N_rep_save);        
        F_draw_save = F_draw(:,2:N_rep_save);
        
        save(str,'rand_seed','psi_G_save','psi_Y_save','sigma_square_G_save','sigma_square_Y_save','G_draw_save','F_draw_save')
        clear coeff F_draw_save G_draw_save psi_G_save psi_Y_save sigma_square_G_save sigma_square_Y_save  

        G_draw(1,:,1) = G_draw(1,:,N_rep_save);
        F_draw(:,1) = F_draw(:,N_rep_save);
        sigma_square_G_draw(1) = sigma_square_G_draw(N_rep_save);
        sigma_square_Y_draw(:,1) = sigma_square_Y_draw(:,N_rep_save);
        psi_G_draw(1) = psi_G_draw(N_rep_save);
        psi_Y_draw(:,1) = psi_Y_draw(:,N_rep_save);
    end
              

    count = count+1;
    dis_count = dis_count+1;
    repetition_for = repetition_for+1;
end

seconds = toc;
minutes = seconds/60;
hours = minutes/60;
days = hours/24;

disp('   ')
disp(['The number of hours is:       ',num2str(hours)])
disp(['The number of days is:        ',num2str(days)])