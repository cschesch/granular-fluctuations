***************************************************************
*** Firm Dynamics and the Origins of Aggregate Fluctuations ***
*** Andrea Stella                                           ***
*** Last Updated: 04.16.2015                                ***
***************************************************************
*The views in this paper are solely the responsibility of the author and 
*should not be interpreted as reflecting the views of the Board of 
*Governors of the Federal Reserve System or of any other person 
*associated with the Federal Reserve System.
clearcapture log closeset more off

use data_histogram_macro_raw, replace
rename var1 tid
rename var2 fraction_G
rename var3 fraction_Y
rename var4 fraction_G_2_5
rename var5 fraction_Y_2_5
rename var6 fraction_G_97_5
rename var7 fraction_Y_97_5
sort tid
save data_histogram_macro, replace


use data_histogram_macro, replace


sum fraction_G, d
sum fraction_G_2_5, d
sum fraction_G_97_5, d

sum fraction_Y, d
sum fraction_Y_2_5, d
sum fraction_Y_97_5, d

