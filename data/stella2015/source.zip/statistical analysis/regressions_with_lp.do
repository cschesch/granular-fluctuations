***************************************************************
*** Firm Dynamics and the Origins of Aggregate Fluctuations ***
*** Andrea Stella                                           ***
*** Last Updated: 04.16.2015                                ***
***************************************************************
*The views in this paper are solely the responsibility of the author and 
*should not be interpreted as reflecting the views of the Board of 
*Governors of the Federal Reserve System or of any other person 
*associated with the Federal Reserve System
clear
capture log close
set more off
log using annual_lp_regressions_log, replace


use inputdata_lp.dta, replace
keep if index_500 ==1
bysort year: egen mean_lp_growth = mean(lp_growth)
replace lp_growth = lp_growth - mean_lp_growth
gen granular = lw_it*lp_growth
collapse (sum) granular, by(year)
sort year
merge year using gdp_data
tsset year
reg gdp_g granular l.granular l2.granular

use inputdata_lp.dta, replace
egen interaction = group(year sic_2digit)
sum interaction
keep if index_500 ==1
set matsize 5000
areg lp_growth, a(interaction)
predict res_shock, r
corr lp_growth res_shock
gen granular = lw_it*res_shock
collapse (sum) granular, by(year)
sort year
merge year using gdp_data
tsset year
reg gdp_g granular l.granular l2.granular


use inputdata_lp.dta, replace
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
keep if index_500 ==1
bysort year: egen mean_lp_growth = mean(lp_growth)
replace lp_growth = lp_growth - mean_lp_growth
drop if lp_growth>0.2 | lp_growth<-0.2
gen granular = lw_it*lp_growth
collapse (sum) granular, by(year)
sort year
merge year using gdp_data
tsset year
reg gdp_g granular l.granular l2.granular

use input_final_annual.dta, replace
egen interaction = group(year sic_2digit)
sum interaction
gen du = 0
replace du = 1 if (sic_num >= 6000 & sic_num<7000) | (sic_num == 1389 | sic_num == 1311 | sic_num == 2911 | sic_num == 5172 ) | (sic_num >= 4900 & sic_num< 4940)
keep if du ==0
keep if index_500 ==1
bysort year: egen mean_lp_growth = mean(lp_growth)
drop if lp_growth>0.2 | lp_growth<-0.2
set matsize 5000
areg lp_growth, a(interaction)
predict res_shock, r
corr lp_growth res_shock
gen granular = lw_it*res_shock
collapse (sum) granular, by(year)
sort year
merge year using gdp_data
tsset year
reg gdp_g granular l.granular l2.granular

log close
