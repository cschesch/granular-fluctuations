clear
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Firm Dynamics and the Origins of Aggregate Fluctuations %%%
%%% Andrea Stella                                           %%%
%%% Last Updated: 04.16.2015                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The views in this paper are solely the responsibility of the author and 
%should not be interpreted as reflecting the views of the Board of 
%Governors of the Federal Reserve System or of any other person 
%associated with the Federal Reserve System.

index_nofinance = csvread('index_nofinance.csv');
data_macro_shocks = csvread('data_macro_shocks.csv');
tenure_final = csvread('tenure_final.csv');
sa_data_final = csvread('sa_data_final.csv');
index_top500 = csvread('index_top500.csv');

sa_data_final(:,2) = sa_data_final(:,2) - min(sa_data_final(:,2))+1;
tenure = tenure_final(:,2)-1; % Because we lose one quarter in the growth calculation

T = max(sa_data_final(:,2));
number_observations = length(sa_data_final);
N = max(sa_data_final(:,1));
Y = zeros(N,T);
lag_weight = zeros(N,T);
avg_weight = zeros(N,1);

ii=1;
for i=1:N
    prova(i) =  ii;
    tenure_X = tenure(i,1);    
    time_X = sa_data_final(ii,2); 
    time(i,1) = time_X;
    Y(i,time_X:(time_X+tenure_X-1)) = sa_data_final(ii:(ii+tenure_X-1),3);
    lag_weight(i,time_X:(time_X+tenure_X-1)) = sa_data_final(ii:(ii+tenure_X-1),5);
    avg_weight(i,:) = sa_data_final(ii,7);
    ii = ii + tenure_X;
end

index = ones(size(Y));
for i_N = 1:N
    for i_T = 1:T
        if Y(i_N,i_T) == 0           
            index(i_N,i_T) = 0;
        end
    end
end

index_top500 =  index.*index_top500;

tenure_Y = zeros(N,2);
for i_N = 1:N
    tenure_Y(i_N,1) = min(find(index(i_N,:)));
    tenure_Y(i_N,2) = max(find(index(i_N,:)));
end
%e{
save temp

Macro_shocks = data_macro_shocks(:,2:end)';
save('data_input','sa_data_final','tenure_final','index_top500','index_nofinance','data_macro_shocks')

%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preallocation %%%%
%%%%%%%%%%%%%%%%%%%%%%%
N_rep_save = 1000;

G_draw = zeros(1,T,N_rep_save);
F_draw = zeros(N,N_rep_save);
psi_G_draw = zeros(N_rep_save,1);
psi_Y_draw = zeros(N,N_rep_save);
sigma_square_G_draw = zeros(N_rep_save,1);
sigma_square_Y_draw = zeros(N,N_rep_save);
Constant_draw = zeros(N,N_rep_save);

%%%%%%%%%%%%%%%%%%%%
%%%% Initialize %%%%
%%%%%%%%%%%%%%%%%%%%
Constant_draw(:,1) = sqrt(.1)*randn(N,1);
F_draw(:,1) = sqrt(.1)*randn(N,1);
psi_G_draw(1) = sqrt(.1)*randn(1,1);
while (psi_G_draw(1)<=-1 || psi_G_draw(1)>=1)
    psi_G_draw(1) = sqrt(.1)*randn(1,1);
end
for jj = 1:N
    psi_Y_draw(jj,1) = sqrt(.1)*randn(1,1);
    while (psi_Y_draw(jj,1)<=-1 || psi_Y_draw(jj,1)>=1)
        psi_Y_draw(jj,1) = sqrt(.1)*randn(1,1);
    end
end
sigma_square_G_draw(1) = 1/gamrnd(1,inv(0.01));  
sigma_square_Y_draw(:,1) = 1./gamrnd(1,inv(0.01),N,1); 

prior_phi_i = 0;
prior_v_i = 0.1;

prior_v_bar = 1;
prior_delta_bar = 0.01;

clear tenure_X i ii e_index time time_X  prova sa_data_final  i_* j t  tenure_final cum tenure F_temp F_initial

save data_input_fs

clear all
load temp

Macro_shocks = data_macro_shocks(:,2:end)';

%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preallocation %%%%
%%%%%%%%%%%%%%%%%%%%%%%
N_rep_save = 1000;

G_draw = zeros(1,T,N_rep_save);
F_draw = zeros(N,N_rep_save);
psi_G_draw = zeros(N_rep_save,1);
psi_Y_draw = zeros(N,N_rep_save);
sigma_square_G_draw = zeros(N_rep_save,1);
sigma_square_Y_draw = zeros(N,N_rep_save);
Macro_par_draw = zeros(N,(number_lags2+1)*number_macro_vars,N_rep_save);
Constant_draw = zeros(N,N_rep_save);

%%%%%%%%%%%%%%%%%%%%
%%%% Initialize %%%%
%%%%%%%%%%%%%%%%%%%%
Macro_par_draw(:,:,1) = sqrt(.1)*randn(N,(number_lags2+1)*number_macro_vars);
for jj = 1:N
    if tenure(jj)<120
        Macro_par_draw(jj,((number_lags1+1)*number_macro_vars+1):(number_lags2+1)*number_macro_vars,1) = 0;
    end
end
Constant_draw(:,1) = sqrt(.1)*randn(N,1); 
F_draw(:,1) = sqrt(.1)*randn(N,1);
psi_G_draw(1) = sqrt(.1)*randn(1,1);
while (psi_G_draw(1)<=-1 || psi_G_draw(1)>=1)
    psi_G_draw(1) = sqrt(.1)*randn(1,1);
end
for jj = 1:N
    psi_Y_draw(jj,1) = sqrt(.1)*randn(1,1);
    while (psi_Y_draw(jj,1)<=-1 || psi_Y_draw(jj,1)>=1)
        psi_Y_draw(jj,1) = sqrt(.1)*randn(1,1);
    end
end
sigma_square_G_draw(1) = 1/gamrnd(1,inv(0.01));  
sigma_square_Y_draw(:,1) = 1./gamrnd(1,inv(0.01),N,1);  

prior_phi_i = 0;
prior_v_i = 0.1;

prior_v_bar = 1;
prior_delta_bar = 0.01;

clear tenure_X i ii e_index time time_X  prova sa_data_final  i_* j t  tenure_final cum tenure F_temp F_initial

save data_input_ss
