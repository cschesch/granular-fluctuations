%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Firm Dynamics and the Origins of Aggregate Fluctuations %%%
%%% Andrea Stella                                           %%%
%%% Last Updated: 04.16.2015                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The views in this paper are solely the responsibility of the author and 
%should not be interpreted as reflecting the views of the Board of 
%Governors of the Federal Reserve System or of any other person 
%associated with the Federal Reserve System.
function  [G_draw] = draw_macro(T,Y_draw,F_draw,psi_G_draw,psi_Y_draw,sigma_square_G_draw,sigma_square_Y_draw,index)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Draw G %%%%%%%%%%%%%%%%%%%%%%%%%%
% G_draw is zeros(1,T)                                          %                                        
% The parameter matrix F is (N,2)                               %
% psi_Y_draw is (N,1)                                           %
% and sigma_square_Y_draw is (N,1)                              %
% and psi_G_draw is (1,1) and sigma_square_G_draw is (1,1)      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Draw G %%%%%%%%%%%%%%%%%%%%%%%%%%
    Y_tilde = zeros(size(Y_draw));
    Y_tilde(:,1) = Y_draw(:,1);
    for t_temp = 2:T
        Y_tilde(:,t_temp) = Y_draw(:,t_temp) - psi_Y_draw.*Y_draw(:,t_temp-1);
    end
    F_tilde_0 = F_draw;
    F_tilde_1 = -psi_Y_draw.*F_tilde_0;
    G_arrow_update = zeros(2,T);
    G_arrow = zeros(2,T);
    P_G_arrow = zeros(2,2,T);
    P_G_arrow(:,:,1) = eye(2);
    P_G_arrow_update = zeros(2,2,T);
    psi_G_tilde_arrow = [psi_G_draw 0 ; 1 0 ];
    Sigma_arrow_G = [sigma_square_G_draw 0 ; 0  0];
    for t=2:T
        real_index = index(:,t).*index(:,t-1);
        index_temp = find(real_index==1);
        D_tilde_arrow_padded = [F_tilde_0(index_temp) F_tilde_1(index_temp)];
        Y_tilde_padded = Y_tilde(index_temp,t);
        Sigma_arrow_Y = spdiags(sigma_square_Y_draw(index_temp), 0, eye(length(sigma_square_Y_draw(index_temp))));    
        G_arrow_update(:,t) = psi_G_tilde_arrow*G_arrow(:,t-1);
        P_G_arrow_update(:,:,t) = psi_G_tilde_arrow*P_G_arrow(:,:,t-1)*psi_G_tilde_arrow' + Sigma_arrow_G;
        kalman_filter = P_G_arrow_update(:,:,t)*(D_tilde_arrow_padded')/(D_tilde_arrow_padded*P_G_arrow_update(:,:,t)*D_tilde_arrow_padded' + Sigma_arrow_Y);
        G_arrow(:,t) = G_arrow_update(:,t) + kalman_filter*(Y_tilde_padded - D_tilde_arrow_padded* G_arrow_update(:,t));
        P_G_arrow(:,:,t) = P_G_arrow_update(:,:,t) - kalman_filter*D_tilde_arrow_padded*P_G_arrow_update(:,:,t);
    end    
    chol_cov = chol(P_G_arrow(:,:,T));
    G_a = zeros(2,T);
    G_a(:,T) = G_arrow(:,T) + chol_cov*randn(2,1);
    G_arrow_given_star=zeros(2,T-1);
    for k=1:(T-1)
        t = T-k;
        G_arrow_given_star(:,t) = G_arrow(:,t) + P_G_arrow(:,:,t)*((psi_G_tilde_arrow(1,:)')/(psi_G_tilde_arrow(1,:)*P_G_arrow(:,:,t)*(psi_G_tilde_arrow(1,:)') + sigma_square_G_draw))*(G_a(1,t+1) - psi_G_tilde_arrow(1,:)*G_arrow(:,t));
        P_G_arrow_given_star = P_G_arrow(:,:,t) - P_G_arrow(:,:,t)*((psi_G_tilde_arrow(1,:)')/(psi_G_tilde_arrow(1,:)*P_G_arrow(:,:,t)*(psi_G_tilde_arrow(1,:)') + sigma_square_G_draw))*psi_G_tilde_arrow(1,:)*P_G_arrow(:,:,t);
        chol_cov = chol(P_G_arrow_given_star);
        G_a(:,t) = G_arrow_given_star(:,t) + chol_cov*randn(2,1);
    end
    G_draw = G_a(1,:)/std(G_a(1,:));