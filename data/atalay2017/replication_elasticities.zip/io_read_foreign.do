set more off
set matsize 5000
local countrylist "ESP JPN NLD FRA DNK ITA USA"

/* Notice that the USA data is not from the BEA or Dale Jorgenon's data but from EUKLEMS and 
  the WIOT. Here, I wanted to check whether there were any differences in the main results for the 
  US in the two datasources.  There doesn't seem to be (there isn't any discussion of this in the paper)*/ 

/* Here we figure out consumption in each foreign country.  These data will be used solely to compute 
  the preference weights in different countries, as they appear in Online Appendix C */

local directory = "../replicationfiles"  /* You will need to change the value of this macro variable */

use if (col_country=="JPN" | col_country=="ESP" | col_country=="USA" | col_country=="NLD" | col_country=="DNK" | col_country=="FRA" | col_country=="ITA") using `directory'/wiot_full, replace
foreach var of varlist row_item col_item {
  replace `var'=`var'-1 if `var'>=5  /* combine Textiles & Leather */
  replace `var'=`var'-1 if `var'>=19  /* combine different wholesale/retail industries */
  replace `var'=`var'-1 if `var'>=19
  replace `var'=`var'-1 if `var'>=21  /* combine different transport industries */
  replace `var'=`var'-1 if `var'>=21
  replace `var'=`var'-1 if `var'>=21
}
replace col_item=31 if col_item==32 | col_item==33 /* combine non-profit consumption and government consumption into private consumption*/
collapse (sum) value , by(col_country row_item col_item year)
keep if col_item==31  /* private consumption, nonprofits, and the government */
ren row_item industry
ren col_country country
ren value consumption
drop col_item
save consumption_foreign, replace

/* This is the part of the code that will produce the Gamma^M matrices for each country,
  the Input Output Table for each country */

use if (col_country=="JPN" | col_country=="ESP" | col_country=="USA" | col_country=="NLD" | col_country=="DNK" | col_country=="FRA" | col_country=="ITA") using `directory'/wiot_full, replace
foreach var of varlist row_item col_item {
  replace `var'=`var'-1 if `var'>=5
  replace `var'=`var'-1 if `var'>=19
  replace `var'=`var'-1 if `var'>=19
  replace `var'=`var'-1 if `var'>=21
  replace `var'=`var'-1 if `var'>=21
  replace `var'=`var'-1 if `var'>=21
}
collapse (sum) value , by(col_country row_item col_item year)
bys year col_country col_item: egen totIntermediate=sum(value*(row_item==54))
bys year col_country col_item: egen total=sum(value*(row_item==63))
keep if row_item<=28 & col_item<=28
ren col_country country
sort country row_item col_item year
gen share_within=value/totIntermediate
gen overall_grow=log(value/total/value[_n-1]*total[_n-1]) if year>1995
gen within_grow=log(value/totIntermediate/value[_n-1]*totIntermediate[_n-1]) if year>1995
gen between_grow=overall_grow-within_grow
save iotable_foreign, replace

/* In the way in which I am calibrating preferences, an industry will have a high 
  export weight if it exports a lot */
use if row_item<=35  & (row_country=="JPN" | row_country=="ESP" | row_country=="USA" | row_country=="NLD" | row_country=="DNK" | row_country=="FRA" | row_country=="ITA") using `directory'/wiot_full, replace
gen export=value*(row_country~=col_country)
collapse (sum) export , by(row_country row_item year)
ren row_country country
ren row_item industry
replace industry=industry-1 if industry>=5
replace industry=industry-1 if industry>=19
replace industry=industry-1 if industry>=19
replace industry=industry-1 if industry>=21
replace industry=industry-1 if industry>=21
replace industry=industry-1 if industry>=21
collapse (sum) export , by(industry country year)
save exports_foreign, replace

local counter=0

foreach x of local countrylist  {
  use if  year==1997 &  country=="`x'" & industry<=28  using consumption_foreign, replace
  merge 1:n year country industry using exports_foreign
  drop if _merge==2
  drop _merge
  bys country: egen sc=sum(consumption+export)
  gen c=(consumption+export)/sc
  keep country c industry
  ren industry ind
  save cons`x', replace

  use if year==1997 & country=="`x'" using iotable_foreign , replace
  gen v=value/totIntermediate
  keep row_item col_item v 
  reshape wide v, i(row_item) j(col_item)
  keep v*
  outsheet using dataMJ_`x'.csv, delim(,) replace nonames
}

insheet using all_countries_09I.csv, clear delim(,) names
keep if var=="GO" | var=="GO_P" | var=="II" | var=="II_P" | var=="CAP" | var=="LAB"
keep if _1973~=. | country=="USA-NAICS" 
keep if country=="AUS" | country=="DNK" | country=="ESP" | country=="FIN" | country=="FRA" | country=="GER" | country=="GRC" | country=="NLD" | country=="UK" | country=="ITA" | country=="JPN" | country=="KOR" | country=="USA-NAICS" 
drop if code=="K" | code=="TOT" | code=="LtQ" | code=="Q" | code=="D"  |  code=="JtK" | code=="50" | code=="51" | code=="52"  | code=="40"  | code=="23t25" | code=="I" | code=="P"
bys code: gen x=_N
drop if x<20
drop x
gen x=_n 
replace country="USA" if country=="USA-NAICS"
replace _1970=. if country=="JPN" | country=="ESP" | country=="FRA" | country=="USA"
sort country var x 
by country var: gen ind=_n
drop code x

forvalues x=1970/2007 {
 ren _`x' v`x'
}

reshape long v , i(country var ind) j(year)
replace var="1" if var=="GO"
replace var="2" if var=="GO_P"
replace var="3" if var=="II"
replace var="4" if var=="II_P"
replace var="5" if var=="CAP"
replace var="6" if var=="LAB"
destring var, replace force 
reshape wide v , i(country year ind) j(var)
ren v1 y
ren v2 pout
ren v3 m
ren v4 pm
ren v5 cap
ren v6 lab
save eutemp, replace

foreach x of local countrylist  {
  use if country=="`x'" using eutemp, replace
  sort ind year
  local botyear=1970
  /* Data for Japan only begin in 1973 */
  if  "`x'"=="JPN" {  
     local botyear=1973  
  }
  drop if country=="JPN" & year==2007
  sort ind year
  gen dq=log(y/y[_n-1])-log(po/po[_n-1])
  drop if year<=`botyear'
  /* De-trend each variable */
  bys ind: egen t1=mean(dq)
  replace dq=dq-t1
  drop t1
  ren dq dq_
  keep year ind dq_
  reshape wide dq_ , j(ind) i(year)
  aorder
  outsheet using ioJ_data_dt_`x'.csv, replace delim(,)
  
  use eutemp, replace
  keep if country=="`x'" & year==1997
  replace y=y+abs(cap) if cap<0
  replace y=y+abs(lab) if lab<0
  replace y=y+abs(m) if m<0
  gen iak=cap/y
  gen ial=lab/y
  gen iam=m/y

  forvalues xq=1/20 {
    replace iak=max(.005, iak/(iak+ial+iam))   /* For some foreign countries/industries, the measured cost shares was
    negative (?!).  Here I make an ad-hoc adjustment so that the factor shares are at least somewhat 
    slightly positive */
    replace ial=max(.005, ial/(iak+ial+iam))
    replace iam=max(.005, iam/(iak+ial+iam))
    replace ial=min(.75, ial/(iak+ial+iam))
    replace iak=iak/(iak+ial+iam)
    replace ial=ial/(iak+ial+iam)
    replace iam=iam/(iak+ial+iam)
  }
  egen sv=sum(y)
  gen shareV=y/sv
  keep ind iak-iam shareV
  merge using cons`x'
  drop _merge country
  order iak ial iam c shareV 
  ren c share
  gen dep=1
  replace dep=.021 if ind==17  /* Depreciation rates are from U.S. data */
  replace dep=.118 if ind==5
  replace dep=.165 if ind==10 | ind==11 | ind==12
  replace dep=(.170*.005 +.167*.014 )/(.005+.014 )   if ind==13
  replace dep=(.353*.037 +.165*.003 )/(.037+.003 )   if ind==14
  replace dep=(.162*.005 +.118*.004 )/(.005+.004 )   if ind==15
  drop ind
  outsheet using dataOJ_`x'.csv, replace delim(,)
}

/* Take U.S. data to compute capital flows into the government industry.  Need to use
  U.S. data since capital flows data do not exist in the WIOT */

insheet using io_use_1997.csv, clear names 
drop t004 t007
keep in 1/71
local count=0
foreach var of varlist ca-f10n {
    local count=`count'+1
    ren `var' v`count'
    local store`count'=code[`count']   
}
reshape long v, i(code) j(code_n)
replace v=0 if v==.
gen naics_customer=" "
ren code naics_supplier
forvalues x=1/71 {
   replace naics_customer="`store`x''" if code_n==`x'
}
drop if code_n==78 | code_n==79 
keep if (code_n>=81 & code_n<=83) | (code_n>=85 & code_n<=87) | (code_n>=89 & code_n<=91)  /* government investment */
drop code_n naics_customer
gen bea_supplier=.
replace bea_supplier=1 if substr(naics_supplier,1,5)=="111CA" | substr(naics_supplier,1,5)=="113FF"
replace bea_supplier=2 if substr(naics_supplier,1,3)=="212" | substr(naics_supplier,1,3)=="213" | substr(naics_supplier,1,3)=="211" 
 replace bea_supplier=3 if substr(naics_supplier,1,5)=="311FT"
replace bea_supplier=4 if substr(naics_supplier,1,5)=="313TT" |substr(naics_supplier,1,5)=="315AL"
replace bea_supplier=5 if substr(naics_supplier,1,3)=="321" |substr(naics_supplier,1,3)=="337"
replace bea_supplier=6 if substr(naics_supplier,1,3)=="322" | substr(naics_supplier,1,3)=="323" | substr(naics_supplier,1,3)=="511"
replace bea_supplier=7 if substr(naics_supplier,1,3)=="324"
replace bea_supplier=8 if substr(naics_supplier,1,3)=="325"
replace bea_supplier=9 if substr(naics_supplier,1,3)=="326"
replace bea_supplier=10 if substr(naics_supplier,1,3)=="327"
replace bea_supplier=11 if substr(naics_supplier,1,3)=="331" | substr(naics_supplier,1,3)=="332"
replace bea_supplier=12 if substr(naics_supplier,1,3)=="333" 
replace bea_supplier=13 if substr(naics_supplier,1,3)=="334"| substr(naics_supplier,1,3)=="335"
replace bea_supplier=14 if naics_supplier=="3361MV" | naics_supplier=="3364OT"
replace bea_supplier=15 if substr(naics_supplier,1,3)=="339"
replace bea_supplier=16 if substr(naics_supplier,1,2)=="22" 
replace bea_supplier=17 if substr(naics_supplier,1,2)=="23"
replace bea_supplier=18 if substr(naics_supplier,1,2)=="42" | substr(naics_supplier,1,2)=="44" |substr(naics_supplier,1,2)=="45" |substr(naics_supplier,1,2)=="4A"
replace bea_supplier=19 if substr(naics_supplier,1,2)=="71" | substr(naics_supplier,1,2)=="72" 
replace bea_supplier=20 if substr(naics_supplier,1,2)=="48" | substr(naics_supplier,1,2)=="49" 
replace bea_supplier=21 if substr(naics_supplier,1,3)=="512" | substr(naics_supplier,1,3)=="513"| substr(naics_supplier,1,3)=="514" 
 replace bea_supplier=22 if substr(naics_supplier,1,3)=="523" |substr(naics_supplier,1,3)=="524"| substr(naics_supplier,1,5)=="521CI"| substr(naics_supplier,1,3)=="525" 
replace bea_supplier=23 if substr(naics_supplier,1,3)=="531" | substr(naics_supplier,1,2)=="HS" | substr(naics_supplier,1,3)=="ORE" 
replace bea_supplier=24 if substr(naics_supplier,1,4)=="5411" |substr(naics_supplier,1,3)=="532" | substr(naics_supplier,1,4)=="5415" | substr(naics_supplier,1,4)=="5412" | substr(naics_supplier,1,2)=="55" | substr(naics_supplier,1,2)=="56" | substr(naics_supplier,1,3)=="514"
replace bea_supplier=25 if substr(naics_supplier,1,3)=="GFG" | substr(naics_supplier,1,3)=="GFE" | substr(naics_supplier,1,4)=="GSLG" | substr(naics_supplier,1,4)=="GSLE" 
replace bea_supplier=26 if substr(naics_supplier,1,2)=="61"
replace bea_supplier=27 if substr(naics_supplier,1,2)=="62" 
replace bea_supplier=28 if substr(naics_supplier,1,2)=="81"
collapse (sum) v, by(bea_supplier)
sum v
gen share=v/r(sum)*0.65+0.35*(_n==25)
keep share
save government_invest_foreign, replace 

/* capital flow tables.  Here we use data from the US, but combine industries according to the 
  industry definitions in Appendix C  */

insheet using capital_flows97.csv, clear 
local count=0
foreach var of varlist v3-v125 {
   local count=`count'+1
   local nm=`var'[1]
   ren `var' v`nm'_`count'
}
drop in 1/1
drop commodity 
qui destring v111CA_1-v81_123, replace force
collapse (sum) v111CA_1-v81_123, by(v1)
local vars=" "
forvalues x=1/26 {
   local toadd=v1[`x']
   local vars="`vars' `toadd'"
}

xpose, clear varname
drop in 1/1
gen naics_customer=substr(_varname, 1, strpos(_varname,"_")-1)
collapse (sum) v1-v26, by(naics_customer)
reshape long v, j(naics_supplier) i(naics_customer)
tostring naics_supplier, replace
gen naics_supplier_temp=" " 
forvalues x=1/26 {
   replace naics_supplier_temp=word("`vars'", `x') if naics_supplier=="`x'"
}
drop naics_supplier
ren naics_supplier_temp naics_supplier
replace naics_customer=substr(naics_customer,2,.)
ren v valCapital_Flow
local nm = "customer supplier" 
foreach x of local nm {
  gen bea_`x' = .
  replace bea_`x'=1 if substr(naics_`x',1,5)=="111CA" | substr(naics_`x',1,5)=="113FF"
  replace bea_`x'=2 if substr(naics_`x',1,3)=="212" | substr(naics_`x',1,3)=="213" | substr(naics_`x',1,3)=="211" 
   replace bea_`x'=3 if substr(naics_`x',1,5)=="311FT"
  replace bea_`x'=4 if substr(naics_`x',1,5)=="313TT" |  substr(naics_`x',1,5)=="315AL"
  replace bea_`x'=5 if substr(naics_`x',1,3)=="321" |  substr(naics_`x',1,3)=="337"
  replace bea_`x'=6 if substr(naics_`x',1,3)=="322" | substr(naics_`x',1,3)=="323" | substr(naics_`x',1,3)=="511"
  replace bea_`x'=7 if substr(naics_`x',1,3)=="324"
  replace bea_`x'=8 if substr(naics_`x',1,3)=="325"
  replace bea_`x'=9 if substr(naics_`x',1,3)=="326"
  replace bea_`x'=10 if substr(naics_`x',1,3)=="327"
  replace bea_`x'=11 if substr(naics_`x',1,3)=="331" |   substr(naics_`x',1,3)=="332"
  replace bea_`x'=12 if substr(naics_`x',1,3)=="333" 
  replace bea_`x'=13 if  substr(naics_`x',1,3)=="334"  | substr(naics_`x',1,3)=="335"
  replace bea_`x'=14 if naics_`x'=="3361MV" | naics_`x'=="3364OT"
  replace bea_`x'=15 if substr(naics_`x',1,3)=="339"
  replace bea_`x'=16 if substr(naics_`x',1,2)=="22" 
  replace bea_`x'=17 if substr(naics_`x',1,2)=="23"
  replace bea_`x'=18 if substr(naics_`x',1,2)=="42" | substr(naics_`x',1,2)=="44" |  substr(naics_`x',1,2)=="45" |  substr(naics_`x',1,2)=="4A"
  replace bea_`x'=19  if substr(naics_`x',1,2)=="71" | substr(naics_`x',1,2)=="72" 
  replace bea_`x'=20 if substr(naics_`x',1,2)=="48" | substr(naics_`x',1,2)=="49" 
  replace bea_`x'=21 if substr(naics_`x',1,3)=="512" | substr(naics_`x',1,3)=="513"  | substr(naics_`x',1,3)=="514" 
   replace bea_`x'=22 if substr(naics_`x',1,3)=="523" |  substr(naics_`x',1,3)=="524"  | substr(naics_`x',1,5)=="521CI"  | substr(naics_`x',1,3)=="525" 
  replace bea_`x'=23 if   substr(naics_`x',1,3)=="531" | substr(naics_`x',1,2)=="HS" | substr(naics_`x',1,3)=="ORE" 
  replace bea_`x'=24 if substr(naics_`x',1,4)=="5411" |  substr(naics_`x',1,3)=="532" | substr(naics_`x',1,4)=="5415" | substr(naics_`x',1,4)=="5412" | substr(naics_`x',1,2)=="55" | substr(naics_`x',1,2)=="56" | substr(naics_`x',1,3)=="514"
  replace bea_`x'=25 if substr(naics_`x',1,3)=="GFG" | substr(naics_`x',1,3)=="GFE" | substr(naics_`x',1,4)=="GSLG" | substr(naics_`x',1,4)=="GSLE" 
  replace bea_`x'=26 if substr(naics_`x',1,2)=="61"
  replace bea_`x'=27 if substr(naics_`x',1,2)=="62" 
  replace bea_`x'=28 if substr(naics_`x',1,2)=="81"
}

fillin bea_supplier bea_customer
drop _fillin
sort bea_supplier bea_customer
/* create rows for the industries that don't produce capital */
sort bea_customer bea_supplier
collapse (sum) valCapital, by(bea_customer bea_supplier)
expand 28 if bea_supplier==2
bys bea_customer bea_supplier : gen temp_counter=_n
replace valCapital=0 if temp_counter>1
replace bea_supplier=bea_supplier+temp_counter-1 if bea_supplier==2
replace bea_supplier=bea_supplier-28 if bea_supplier>28
collapse (sum) valCapital, by(bea_customer bea_supplier)
gen year=1997
save capitaltable97, replace 
bys bea_customer: egen sval=sum(valCapital)
replace valCapital=.65*valCapital/sval   /* McGrattan and Schmitz correction, in this line and the next. */
replace valCapital=valCapital+.35 if bea_supplier==bea_customer
keep bea_customer bea_supplier valCapital
drop if bea_supplier==. | bea_customer==.   /* No observations dropped here, in actuality */
replace valCapital=0 if valCapital==.
reshape wide  valCapital, i(bea_supplier) j(bea_customer)
drop bea_supplier
keep valCapital*
merge using government_invest_foreign
ren share valCapital_Flow25
aorder
drop _merge
keep in 1/28
foreach x of local countrylist  {
   outsheet using dataKJ_`x'.csv, delim(,) replace nonames  /* Outsheet the same dataset for different countries */
}

insheet using price_changes_foreign.csv, clear
drop in 1/1
destring v5-v21, replace force
local counter=1994
foreach var of varlist v5-v21 {
  local counter=`counter'+1
  ren `var' v`counter'
}
ren v1 country 
ren v2 variable
ren v3 code
drop v4 v2010 v2011
gen industry=mod(_n-1,36)+1
keep if variable=="GO" | variable=="VA" | variable=="GO_P"
gen variable_num=1 if variable=="GO"
replace variable_num=2 if variable=="VA"
replace variable_num=3 if variable=="GO_P"
drop variable
reshape long v , i(country industry variable_num) j(year)
reshape wide v, i(country industry year) j(variable_num)
ren v1 go
ren v2 va
ren v3 go_p
replace industry=industry-1 if industry>=5
replace industry=industry-1 if industry>=19
replace industry=industry-1 if industry>=19
replace industry=industry-1 if industry>=21
replace industry=industry-1 if industry>=21
replace industry=industry-1 if industry>=21
drop if industry==1 | industry==30
replace industry=industry-1  /* "Total"  was the first industry before the previous line */
bys industry country year: egen numer=sum(go_p*go)
bys industry country year: egen denom=sum(go)
gen price=numer/denom
bys industry country year: egen value_added=sum(va)
bys industry country year: keep if _n==1
gen d_va=log(value_added/value_added[_n-1])
gen d_go=log(denom/denom[_n-1])
gen d_price=log(price/price[_n-1])
drop if year==1995
gen nonmiss=(d_va~=. & d_go~=. & d_price~=.)
bys country: egen sum_nonmiss=sum(nonmiss)
sum sum_nonmiss
keep if sum_nonmiss==r(max)  | country=="JPN" | country=="ESP"
keep industry country year d_va-d_price
save price_changes_foreign, replace

ren industry row_item
merge 1:n year country row_item using iotable_foreign
keep if _merge==3
drop d_va d_go _merge
ren d_price dprice_supp
ren col_item industry
merge n:1 year country industry using price_changes_foreign
ren industry col_item
keep if _merge==3
drop d_va d_go _merge
ren d_price dprice_cust
sort country col_item row_item year 
gen dpmat_temp=(1/2*share_within+1/2*share_within[_n-1])*dprice_supp if year>1995
bys country col_item year: egen dpmat=sum(dpmat_temp)
gen relprice_between=dprice_cust-dpmat
gen relprice_within=dpmat-dprice_supp
bys country col_item row_item: egen mean_share=mean(share_within)
gsort country col_item year -mean_share
by country col_item year: gen rk=_n 
drop  dpmat_temp

label var row_item "Supplying industry" 
label var dprice_supp "Change in the output price for the supplying industry" 
label var col_item "Downstream industry"
label var totIntermediate "Total Intermediate Purchases" 
label var total "Total Costs"
label var share_within "share of upstream industry of downstream industry's intermediate input purchases"
label var overall_grow" year over year growtyh in within share plut between share"
label var dpmat "year over year change in the (ideal) price of the intermediate input"
label var dprice_cust "change in the price of the downstream industry"
label var within_grow "year over year growth in within share"
label var between_grow "year over year growth in between share"
label var value "value of shipments from upstream industry to downstream industry"
label var rk "Rank of the upstream industry, in terms of importance as a supplier of intermediate inputs for the downstream industry"

/* Loop over countries */
foreach country of local countrylist {
  /* Loop over how many upstream observations to include per downstream observation X year */
  /* The paper only reports values for x=10, for the OLS estimates */
  foreach x in  2 4 6 8 10 15 {
    local counter=0
    local counter=`counter'+1
    gen reg_`counter'_`country'_`x'=.
    reg overall_grow relprice_b relprice_wi  i.year if country=="`country'" & rk<=`x'
    replace reg_`counter'_`country'_`x'=_b[relprice_within] in 1/1
    replace reg_`counter'_`country'_`x'=_se[relprice_within] in 2/2
    replace reg_`counter'_`country'_`x'=_b[relprice_between] in 3/3
    replace reg_`counter'_`country'_`x'=_se[relprice_between] in 4/4
    replace reg_`counter'_`country'_`x'=e(N) in 5/5
   local counter=`counter'+1
    gen reg_`counter'_`country'_`x'=.
    reg overall_grow relprice_b relprice_wi  if country=="`country'" & rk<=`x'
    replace reg_`counter'_`country'_`x'=_b[relprice_within] in 1/1
    replace reg_`counter'_`country'_`x'=_se[relprice_within] in 2/2
    replace reg_`counter'_`country'_`x'=_b[relprice_between] in 3/3
    replace reg_`counter'_`country'_`x'=_se[relprice_between] in 4/4
    replace reg_`counter'_`country'_`x'=e(N) in 5/5
  }
}
keep reg* 
keep in 1/23
save all_regression_results_foreign, replace

use all_regression_results_foreign, replace
keep reg_1_*_10
foreach var of varlist reg* {
   replace `var'=`var'+1 in 1/1
   replace `var'=`var'+1 in 3/3
}
aorder 
outsheet using regression_table_14.csv, replace delim(,)  /* This is Table 14 of the paper, in Appendix D3 */

