set scheme s1mono

/* This file produces the Section 4 Figures (and the table that summarizes the 
  importance of different industries in different historical episodes) 
  of the paper.  This should be the very last file that is run. */

insheet using results_table.csv, clear non
destring v10 v13 v14, replace force
ren v1 eps_D
ren v2 eps_Q
ren v3 eps_M
ren v4 eps_X
ren v5 eps_LS
ren v6 durable
ren v7 data_set
drop v8
ren v9 correlation_A
ren v10 correlation_B
ren v11 correlation_A_kf
ren v12 correlation_B_kf
ren v13 r_squared_A
ren v14 r_squared_B
ren v15 r_squared_A_kf
ren v16 r_squared_B_kf
ren v17 eigenvalue_A
ren v18 eigenvalue_B
ren v19 eigenvalue_2_A
ren v20 eigenvalue_2_B

replace r_squared_A=. if eigenvalue_A>1 |  eigenvalue_2_A<.01
replace r_squared_B=. if eigenvalue_B>1 |  eigenvalue_2_B<.01
gen impute_A=(r_squared_A==.)
gen impute_B=(r_squared_B==.)
replace correlation_A=. if eigenvalue_A>1 |  eigenvalue_2_B<.01
replace correlation_B=. if eigenvalue_B>1 |  eigenvalue_2_B<.01

/* This is Figure 3 of the paper */

graph twoway (scatter r_squared_A r_squared_A_kf correlation_A correlation_A_kf  eps_M if data_set==1 & abs(eps_D-0.999)<.01  & durable==0 & abs(eps_Q-0.999)<.001 & abs(eps_LS-2)<.001 & abs(eps_X-0.999)<.001, msymbol( Oh + Oh +) color(black black blue blue)) ,   text(0.18 0.29 "Avg. correlation among" " productivity shocks", color(blue))  text(0.61 0.35 "Fraction of variation" "due to sectoral shocks" )   ylab(0(0.2)1.0) ytitle(" ") xtitle("{&epsilon}{subscript:M}", size(medlarge)) xlab(0.1(0.1)1) legend(off)
graph export "main_results_eps_M.eps" , replace

scatter  r_squared_A r_squared_A_kf correlation_A correlation_A_kf  eps_Q if   data_set==1 &  abs(eps_M-0.999)<.001 & durable==0 & eps_Q>.1 & eps_Q<1.5 &  abs(eps_D-0.999)<.001 & abs(eps_LS-2)<.001 & abs(eps_X-0.999)<.001 & abs(eps_Q-2/5)>.01 &  abs(eps_Q-3/5)>.01 &  abs(eps_Q-5/5)>.01   & abs(eps_Q-4/5)> .01  , msymbol(Oh + Oh + Oh +) color(black) ytitle(" ") xtitle("{&epsilon}{subscript:Q}", size(medlarge)) xlab(0.2(0.2)1.4) legend(off) color(black black blue blue)   text(0.33 0.83 "Avg. correlation among" "productivity shocks", color(blue))  text(0.08 0.88 "Fraction of variation" "due to sectoral shocks", color(black) ) ylab(0(0.2)1.0)
graph export "main_results_eps_Q.eps" , replace

/* This is Figure 4 of the paper */

insheet using historical_decomposition.csv, clear
gen year= 1964+_n
foreach var of varlist v* {
  replace `var'=`var'*100
}
line v1 v2  year, xlab(1970(10)2010) color(black blue) lwidth(medthin medthick) legend(off) xtitle("Year") ylab(-8(2)4) lpattern(solid dash) text(2.2 1995 "Industry" "Specific", color(blue))  text(2.6 2009 "Common", color(black))  xtitle("Year") ytitle("Contribution to GDP Fluctuations" "(Percentage Points)")
graph export "historical_decomposition_1.eps", replace

line v3 v4  year, xlab(1970(10)2010) color(black blue) lwidth(medthin medthick) legend(off) xtitle("Year") ylab(-8(2)4) lpattern(solid dash)  text(-3.8 2003 "Industry" "Specific", color(blue))  text(2.7 1992 "Common", color(black))  xtitle("Year") ytitle("Contribution to GDP Fluctuations" "(Percentage Points)")
graph export "historical_decomposition_2.eps", replace

/* This is Table 3 of the paper */

insheet using historical_decomposition_all_1.csv, clear
gen year= 1964+_n
gen recession=1 if year==1974 | year==1975
replace recession=2 if year>=1980 & year<=1982
replace recession=3 if year>=1996 &  year<=2000
replace recession=4 if year>=2001 &  year<=2002
replace recession=5 if year>=2008 &  year<=2009
drop if recession==.
collapse (sum) v1-v30, by(recession)
outsheet using table_periods.csv, replace delim(,)  
