/* This is the do file that creates that does two things.  First, it 
  creates the datasets that will be used in filter_full.m.  Second 
  it will produce the regression tables that appear in Section 3 and 
  Appendix D1 of the paper.  It will proceed in a few steps 
  1A Compute the Capital Flow Tables 
  1B Compute the IO Tables 
  1C Compute the datasets of output changes by industry/year from 1997 to 2013; these will be 
     combined with the Jorgenson data (in step 1D)
  2A Compute the changes in input choices and input prices across periods and industry-pairs
  1D Compute the datasets of output changes by industry/year from 1960 to 2013, combining 
    the Jorgenson data and the BEA data  
  2B Compute the military spending  shocks.
  2C Bring together the material that are used for the regression 
  2D Run regressions */

set more off
set matsize 5000
set scheme s1color
ssc install hprescott
local makeplots=1 /* Should we make Figures 5-6 in the paper ? */
local create_data=1  /* Should we create the main dataset, used in the regressions? */

/* Step 1A: Takes the commodity by commodity total requirement's table (downloaded from
the BEA website, and manipulates it in a form that is easier to use.  */

insheet using capital_flows97.csv, clear 
local count=0
foreach var of varlist v3-v125 {
   local count=`count'+1
   local nm=`var'[1]
   ren `var' v`nm'_`count'
}
drop in 1/1
drop commodity 
qui destring v111CA_1-v81_123, replace force
collapse (sum) v111CA_1-v81_123, by(v1)
local vars=" "
forvalues x=1/26 {
   local toadd=v1[`x']
   local vars="`vars' `toadd'"
}
xpose, clear varname
drop in 1/1
gen naics_customer=substr(_varname, 1, strpos(_varname,"_")-1)
collapse (sum) v1-v26, by(naics_customer)
reshape long v, j(naics_supplier) i(naics_customer)
tostring naics_supplier, replace
gen naics_supplier_temp=" " 
forvalues x=1/26 {
   replace naics_supplier_temp=word("`vars'", `x') if naics_supplier=="`x'"
}
drop naics_supplier
ren naics_supplier_temp naics_supplier
replace naics_customer=substr(naics_customer,2,.)
ren v valCapital_Flow
local nm = "customer supplier" 
foreach x of local nm {
  gen bea_`x' = .
  replace bea_`x'=1 if substr(naics_`x',1,5)=="111CA" | substr(naics_`x',1,5)=="113FF"
  replace bea_`x'=2 if substr(naics_`x',1,3)=="212"
  replace bea_`x'=3 if substr(naics_`x',1,3)=="211" | substr(naics_`x',1,3)=="213"
  replace bea_`x'=4 if substr(naics_`x',1,2)=="23"
  replace bea_`x'=5 if substr(naics_`x',1,5)=="311FT"
  replace bea_`x'=6 if substr(naics_`x',1,5)=="313TT"
  replace bea_`x'=7 if substr(naics_`x',1,5)=="315AL"
  replace bea_`x'=8 if substr(naics_`x',1,3)=="321"
  replace bea_`x'=9 if substr(naics_`x',1,3)=="337"
  replace bea_`x'=10 if substr(naics_`x',1,3)=="322"
  replace bea_`x'=11 if substr(naics_`x',1,3)=="323" | substr(naics_`x',1,3)=="511"
  replace bea_`x'=12 if substr(naics_`x',1,3)=="325"
  replace bea_`x'=13 if substr(naics_`x',1,3)=="324"
  replace bea_`x'=14 if substr(naics_`x',1,3)=="326"
  replace bea_`x'=15 if substr(naics_`x',1,3)=="327"
  replace bea_`x'=16 if substr(naics_`x',1,3)=="331"
  replace bea_`x'=17 if substr(naics_`x',1,3)=="332"
  replace bea_`x'=18 if substr(naics_`x',1,3)=="333" 
  replace bea_`x'=19 if substr(naics_`x',1,3)=="335"
  replace bea_`x'=20 if naics_`x'=="3361MV"
  replace bea_`x'=21 if naics_`x'=="3364OT"
  replace bea_`x'=22 if  substr(naics_`x',1,3)=="334" 
  replace bea_`x'=23 if substr(naics_`x',1,3)=="339"
  replace bea_`x'=24 if substr(naics_`x',1,2)=="48" | substr(naics_`x',1,2)=="49" 
  replace bea_`x'=25 if substr(naics_`x',1,3)=="512" | substr(naics_`x',1,3)=="513"  | substr(naics_`x',1,3)=="514" 
  replace bea_`x'=26 if substr(naics_`x',1,2)=="22" 
  replace bea_`x'=27 if substr(naics_`x',1,2)=="42" | substr(naics_`x',1,2)=="44" |  substr(naics_`x',1,2)=="45" |  substr(naics_`x',1,2)=="4A"
   replace bea_`x'=28 if substr(naics_`x',1,3)=="523"  | substr(naics_`x',1,3)=="531" | substr(naics_`x',1,2)=="HS" | substr(naics_`x',1,3)=="ORE" | substr(naics_`x',1,3)=="524"  | substr(naics_`x',1,5)=="521CI"  | substr(naics_`x',1,3)=="525" 
  replace bea_`x'=29 if substr(naics_`x',1,4)=="5411" |  substr(naics_`x',1,3)=="532" | substr(naics_`x',1,4)=="5415" | substr(naics_`x',1,4)=="5412" | substr(naics_`x',1,2)=="55" | substr(naics_`x',1,2)=="56" | substr(naics_`x',1,3)=="514"
  replace bea_`x'=29 if substr(naics_`x',1,2)=="61" |  substr(naics_`x',1,2)=="62" |substr(naics_`x',1,2)=="71" | substr(naics_`x',1,2)=="72" | substr(naics_`x',1,2)=="81" 
  replace bea_`x'=30 if substr(naics_`x',1,3)=="GFG" | substr(naics_`x',1,3)=="GFE" | substr(naics_`x',1,4)=="GSLG" | substr(naics_`x',1,4)=="GSLE" 
}

fillin bea_supplier bea_customer
drop _fillin
sort bea_supplier bea_customer
/* create rows for the industries that don't produce capital */
sort bea_customer bea_supplier
collapse (sum) valCapital, by(bea_customer bea_supplier)
expand 30 if bea_supplier==3  
bys bea_customer bea_supplier : gen temp_counter=_n
replace valCapital=0 if temp_counter>1
replace bea_supplier=bea_supplier+temp_counter-1 if bea_supplier==3
replace bea_supplier=bea_supplier-30 if bea_supplier>30
collapse (sum) valCapital, by(bea_customer bea_supplier)
gen year=1997
save capitaltable97, replace 
bys bea_customer: egen sval=sum(valCapital)
replace valCapital=valCapital/sval
drop sval
reshape wide valCapital, i(bea_supplier) j(bea_customer)
drop bea_supplier year
outsheet using dataKJ.csv, delim(,) replace nonames

/* Now combine industries, so that we have the same table for the 
  "coarse" 9-industry classification */
use capitaltable97, replace
foreach var of varlist bea_customer bea_supplier {
 gen `var'2=1 if `var'<=3  /* Primary inputs */
 replace `var'2=2 if `var'==4   /* Construction */
 replace `var'2=3 if `var'==8 | `var'==9 | (`var'>=15 & `var'<=23)  /* Durable goods */
 replace `var'2=4 if (`var'>=5 & `var'<=7) | (`var'>=10 & `var'<=14)   /* Nondurable goods */
 replace `var'2=5 if `var'>=24 & `var'<=26 /* Transport and Communications */
 replace `var'2=6 if `var'==27  /* Wholesale/Retail */
 replace `var'2=7 if `var'==28  /* FIRE */ 
 replace `var'2=8 if `var'==29  /* Other Services */
 replace `var'2=9 if `var'==30  /* Government */
}
collapse (sum) valCapital, by(bea_customer2 bea_supplier2) 
bys bea_customer: egen sval=sum(valCapital)
replace valCapital=valCapital/sval
drop sval
reshape wide valCapital, i(bea_supplier) j(bea_customer)
drop bea_supplier 
outsheet using dataKJ_coarse.csv, delim(,) replace nonames

/* This is the beginning of step 1B */
insheet using io_use_1997.csv, clear names 
drop t004 t007
keep in 1/71
local count=0
foreach var of varlist ca-f10n {
    local count=`count'+1
    ren `var' v`count'
    local store`count'=code[`count']   
}
reshape long v, i(code) j(code_n)
replace v=0 if v==.
gen naics_customer=" "
ren code naics_supplier
forvalues x=1/71 {
   replace naics_customer="`store`x''" if code_n==`x'
}
drop if  code_n==79 
replace naics_customer="91" if  code_n==78 | code_n==72 | code_n==76   | code_n==80 | code_n==84 | code_n==88   /* consumption + residential investment + government consumption */
replace naics_customer="93" if (code_n>=81 & code_n<=83) | (code_n>=85 & code_n<=87) | (code_n>=89 & code_n<=91)  /* government investment */
collapse (sum) v, by(naics_customer naics_supplier)
gen year=1997
ren v flows
drop if length(naics_customer)<=1
save iouse, replace

 use iouse, replace
 collapse (sum) flows, by(naics_customer naics_supplier)
 local nm = "customer supplier" 
 foreach x of local nm {
  gen bea_`x' = .
  replace bea_`x'=1 if substr(naics_`x',1,5)=="111CA" | substr(naics_`x',1,5)=="113FF"
  replace bea_`x'=2 if substr(naics_`x',1,3)=="212"
  replace bea_`x'=3 if substr(naics_`x',1,3)=="211" | substr(naics_`x',1,3)=="213"
  replace bea_`x'=4 if substr(naics_`x',1,2)=="23"
  replace bea_`x'=5 if substr(naics_`x',1,5)=="311FT"
  replace bea_`x'=6 if substr(naics_`x',1,5)=="313TT"
  replace bea_`x'=7 if substr(naics_`x',1,5)=="315AL"
  replace bea_`x'=8 if substr(naics_`x',1,3)=="321"
  replace bea_`x'=9 if substr(naics_`x',1,3)=="337"
  replace bea_`x'=10 if substr(naics_`x',1,3)=="322"
  replace bea_`x'=11 if substr(naics_`x',1,3)=="323" | substr(naics_`x',1,3)=="511"
  replace bea_`x'=12 if substr(naics_`x',1,3)=="325"
  replace bea_`x'=13 if substr(naics_`x',1,3)=="324"
  replace bea_`x'=14 if substr(naics_`x',1,3)=="326"
  replace bea_`x'=15 if substr(naics_`x',1,3)=="327"
  replace bea_`x'=16 if substr(naics_`x',1,3)=="331"
  replace bea_`x'=17 if substr(naics_`x',1,3)=="332"
  replace bea_`x'=18 if substr(naics_`x',1,3)=="333" 
  replace bea_`x'=19 if substr(naics_`x',1,3)=="335"
  replace bea_`x'=20 if naics_`x'=="3361MV"
  replace bea_`x'=21 if naics_`x'=="3364OT"
  replace bea_`x'=22 if  substr(naics_`x',1,3)=="334" 
  replace bea_`x'=23 if substr(naics_`x',1,3)=="339"
  replace bea_`x'=24 if substr(naics_`x',1,2)=="48" | substr(naics_`x',1,2)=="49"
 
  replace bea_`x'=25 if substr(naics_`x',1,3)=="512" | substr(naics_`x',1,3)=="513"  | substr(naics_`x',1,3)=="514" 
  replace bea_`x'=26 if substr(naics_`x',1,2)=="22" 
  replace bea_`x'=27 if substr(naics_`x',1,2)=="42" | substr(naics_`x',1,2)=="44" |  substr(naics_`x',1,2)=="45" |  substr(naics_`x',1,2)=="4A"
   replace bea_`x'=28 if substr(naics_`x',1,3)=="523"  | substr(naics_`x',1,3)=="531" | substr(naics_`x',1,2)=="HS" | substr(naics_`x',1,3)=="ORE" | substr(naics_`x',1,3)=="524"  | substr(naics_`x',1,5)=="521CI"  | substr(naics_`x',1,3)=="525" 
  replace bea_`x'=29 if substr(naics_`x',1,4)=="5411" |  substr(naics_`x',1,3)=="532" | substr(naics_`x',1,4)=="5415" | substr(naics_`x',1,4)=="5412" | substr(naics_`x',1,2)=="55" | substr(naics_`x',1,2)=="56" | substr(naics_`x',1,3)=="514"
  replace bea_`x'=29 if substr(naics_`x',1,2)=="61" |  substr(naics_`x',1,2)=="62" |substr(naics_`x',1,2)=="71" | substr(naics_`x',1,2)=="72" | substr(naics_`x',1,2)=="81" 
  replace bea_`x'=30 if substr(naics_`x',1,3)=="GFG" | substr(naics_`x',1,3)=="GFE" | substr(naics_`x',1,4)=="GSLG" | substr(naics_`x',1,4)=="GSLE" 
  replace bea_`x'= 31 if substr(naics_`x',1,2)=="91" 
  replace bea_`x'=32 if  substr(naics_`x',1,2)=="93" 
}
 drop if naics_customer=="92"
 collapse (sum) flows, by(bea_customer bea_supplier)
 drop if bea_customer==. | bea_supplier==.
 save intermediate_flows, replace
 drop if bea_customer>=31
 bys bea_customer: egen sval=sum(flows)
 replace flows=flows/sval
 drop sval
 reshape wide flows, i(bea_supplier) j(bea_customer)
 drop bea_supplier 
 outsheet using dataMJ.csv, replace delim(,) nonames
 use intermediate_flows, replace
 keep if bea_customer==31
 sum flows
 gen share=flows/r(sum)
 ren bea_supplier ind
 keep ind share
 save demandJ, replace 
 gen ind2=1 if ind<=3
 replace ind2=2 if ind==4
 replace ind2=3 if ind==8 | ind==9 | (ind>=15 & ind<=23) 
 replace ind2=4 if (ind>=5 & ind<=7) | (ind>=10 & ind<=14) 
 replace ind2=5 if ind>=24 & ind<=26
 replace ind2=6 if ind==27
 replace ind2=7 if ind==28
 replace ind2=8 if ind==29
 replace ind2=9 if ind==30
 collapse (sum) share , by(ind2)
 ren ind2 ind
 save demandJ_coarse, replace  /* This dataset and the dataset, above, will be combined into dataOJ 
  (and dataOJ.csv), as the \xi preference paramters */

/* Below, I take information from the IO Table to compute the sources of government capital.  These will 
   enter the tables used to calibrate Gamma_K (both for the 9-industry classification and the 
   30-industry classification */ 
 use intermediate_flows, replace   
 keep if bea_customer==32
 sum flows
 gen share=flows/r(sum)
 ren bea_supplier ind
 keep ind share
 save government_invest, replace 
 gen ind2=1 if ind<=3
 replace ind2=2 if ind==4
 replace ind2=3 if ind==8 | ind==9 | (ind>=15 & ind<=23) 
 replace ind2=4 if (ind>=5 & ind<=7) | (ind>=10 & ind<=14) 
 replace ind2=5 if ind>=24 & ind<=26
 replace ind2=6 if ind==27
 replace ind2=7 if ind==28
 replace ind2=8 if ind==29
 replace ind2=9 if ind==30
 collapse (sum) share , by(ind2)
 ren ind2 ind
 save government_invest_coarse, replace

use if bea_customer<31 using intermediate_flows, replace
foreach var of varlist bea_customer bea_supplier {
 gen `var'2=1 if `var'<=3
 replace `var'2=2 if `var'==4
 replace `var'2=3 if `var'==8 | `var'==9 | (`var'>=15 & `var'<=23) 
 replace `var'2=4 if (`var'>=5 & `var'<=7) | (`var'>=10 & `var'<=14) 
 replace `var'2=5 if `var'>=24 & `var'<=26
 replace `var'2=6 if `var'==27
 replace `var'2=7 if `var'==28
 replace `var'2=8 if `var'==29
 replace `var'2=9 if `var'==30
}
collapse (sum) flows, by(bea_customer2 bea_supplier2) 
bys bea_customer: egen sval=sum(flows)
replace flows=flows/sval
drop sval
reshape wide flows, i(bea_supplier) j(bea_customer)
drop bea_supplier 
outsheet using dataMJ_coarse.csv, delim(,) replace nonames

insheet using dataKJ_coarse.csv, clear 
merge using government_invest_coarse, 
drop _merge ind
keep in 1/9
outsheet using dataKJ_coarse.csv, delim(,) replace nonames

insheet using dataKJ.csv, clear 
merge using government_invest 
drop _merge ind
keep in 1/30
outsheet using dataKJ.csv, delim(,) replace nonames

/* This is the beginning of Step 1C */

insheet using bea_go_gopi_ii.csv, clear
gen sic=.
gen vartype=.
replace sic=0 if ind=="ALL"
replace sic=1 if ind=="11"
replace sic=2 if ind=="212"
replace sic=3 if ind=="211" | ind=="213"
replace sic=4 if ind=="23" 
replace sic=5 if ind=="311FT"
replace sic=6 if ind=="313TT"
replace sic=7 if ind=="315AL"
replace sic=8 if ind=="321"
replace sic=9 if ind=="337"
replace sic=10 if ind=="322"
replace sic=11 if ind=="511" | ind=="323" 
replace sic=12 if ind=="325"
replace sic=13 if ind=="324"
replace sic=14 if ind=="326"
replace sic=15 if ind=="327"
replace sic=16 if ind=="331"
replace sic=17 if ind=="332"
replace sic=18 if ind=="333"
replace sic=19 if ind=="335"
replace sic=20 if ind=="3361MV"
replace sic=21 if ind=="3364OT"
replace sic=22 if ind=="334"
replace sic=23 if ind=="339"
replace sic=24 if ind=="48TW"
replace sic=25 if ind=="512" | ind=="513" | ind=="514"
replace sic=26 if ind=="22"
replace sic=27 if ind=="42" | ind=="44RT"
replace sic=28 if ind=="FIRE"
replace sic=29 if ind=="PROF" | ind=="60" | ind=="70" | ind=="81"
replace sic=30 if ind=="G"
replace vartype=1 if code=="GO"
replace vartype=2 if code=="II"
replace vartype=3 if code=="GOPI"
replace vartype=4 if code=="IIPI"
replace vartype=5 if code=="K"
replace vartype=6 if code=="L"
reshape long v , i(ind vartype)  j(year)
drop code
reshape wide v , i(ind year) j(vartype)
ren v1 go
ren v2 ii
ren v3 gopi
ren v4 iipi
ren v5 kk
ren v6 ll
sort sic year
by sic year: egen y=sum(go)
by sic year: egen k=sum(kk)
by sic year: egen l=sum(ll)
by sic year: egen mat=sum(ii)
sort ind year
gen  d_gopi=log(gopi/gopi[_n-1])*go/y if year>1997
gen  d_iipi=log(iipi/iipi[_n-1])*ii/mat if year>1997
bys sic year: egen dp=sum(d_gopi)
bys sic year: egen dpmat=sum(d_iipi)
bys sic year: keep if _n==1 
gen dy=log(y/y[_n-1]) if year>1997
gen dl=log(l/l[_n-1]) if year>1997
gen dk=log(k/k[_n-1]) if year>1997
gen dmat=log(mat/mat[_n-1]/y*y[_n-1]) if year>1997
keep if year>1997
foreach var of varlist dp dpmat {
   replace `var'=. if sic==0
}
keep sic year dy dmat dp dpmat dl dk 
ren dl dlind
ren dk dkind
ren sic ind
gen data_set="bea"
save bea_temp, replace

use bea_temp, replace
sort year ind
by year: keep if _n==1
keep year dlind dkind
ren dlind dl
ren dkind dk
merge 1:n year using bea_temp
drop dlind dkind _merge
drop if ind==0
sort ind year
save bea9813, replace

/* These data come originally from Hulten and Wykoff */

use intermediate_flows, replace
keep bea_supplier 
gen dep=1
replace dep=.021 if bea_supplier==4
replace dep=.165 if bea_supplier>=15 & bea_supplier<=21
replace dep=.1179 if bea_supplier==8 | bea_supplier==9
replace dep=.170 if bea_supplier==19
replace dep=.353 if bea_supplier==20
replace dep=.167 if bea_supplier==22
replace dep=.162 if bea_supplier==23
bys bea_supplier: keep if _n==1
ren bea_supplier  ind
save drates,  replace
/* we will merge in these depreciation rates, below, when producing dataOJ.csv.  In the end though, I will 
   use larger depreciation rates (as can be seen in filter_full.m */

/*  part 2A */
/* Now create the dataset that draws only on Jorgenson data.  This is the benchmark dataset for the sample up to 1997. */

use  klem , replace
sort ind year
gen ind2=1 if ind==1
replace ind2=2 if ind==2 | ind==3 | ind==5
replace ind2=3 if ind==4
replace ind2=4 if ind==6
replace ind2=5 if ind==7 | ind==8
replace ind2=6 if ind==9
replace ind2=7 if ind==10 | ind==18
replace ind2=ind-3 if ind>=11 & ind<=17
replace ind2=ind-4 if ind>=19 & ind<=29
replace ind2=26 if ind==30 | ind==31
replace ind2=ind-5 if ind>=32 & ind<=35
gen y=qout*po
sort ind year
gen dpo=log(po/po[_n-1])*(1/2*y+1/2*y[_n-1])
collapse (sum) y dpo , by(ind2 year)
ren ind2 ind
sort ind year
replace dpo=dpo/(1/2*y+1/2*y[_n-1])
gen data_set="jorgenson"
ren dpo dp
gen dy = log(y/y[_n-1])
keep ind year dp dy data_set
drop if year>=1998
append using bea9813
drop if year==1960
foreach var of varlist  dp dy {
   ren `var' `var'_
}
gen dq_=dy_-dp_
sort ind year
drop if year==1960
keep dq_ ind year
outsheet using ioJ_data.csv, replace delim(,)

/* Next remove outliers and detrend.  */

insheet using ioJ_data.csv, clear
reshape wide  dq  ,  i(year) j(ind)
aorder
foreach var of varlist dq_*  {
   qui sum `var' 
   replace `var'=`var'-r(mean)
} 
outsheet using ioJ_data_dt.csv, replace delim(,)

insheet using ioJ_data.csv, clear
reshape wide  dq_  ,  i(year) j(ind)
aorder
tsset year

foreach var of varlist dq_*  {
   qui replace `var'=sum(`var')
   qui hprescott `var', stub(hp) smooth(6.25)
   qui gen temp =hp_`var'_1
   qui replace `var'=temp-temp[_n-1]  if _n>1
   drop hp* temp
   qui sum `var' 
   replace `var'=`var'-r(mean)
} 
outsheet using ioJ_data_hp.csv, replace delim(,)

insheet using ioJ_data.csv, clear
reshape wide  dq_  ,  i(year) j(ind)
aorder
gen yearP=(year>1982)
foreach var of varlist dq_* {
   qui reg `var' yearP
   predict f, residuals
   replace `var'=f 
    drop f
} 
outsheet using ioJ_data_dtB.csv, replace delim(,)

insheet using ioJ_data.csv, clear
foreach var of varlist  dq_  {  
     _pctile `var' , p(1 99)
     replace `var'=r(r1) if `var'<r(r1)
     replace `var'=r(r2) if `var'>r(r2) 
}
reshape wide  dq_ ,  i(year) j(ind)
aorder
foreach var of varlist dq_*  {
   qui sum `var' 
   replace `var'=`var'-r(mean)
} 
outsheet using ioJ_data_dt_outliers.csv, replace delim(,)

/* Do the same for the 9-industry classification.   */

use klem , replace
gen ind2=1 if ind<=5
replace ind2=2 if ind==6
replace ind2=3 if ind==11 | ind==12 | (ind>=19 & ind<=27) 
replace ind2=4 if (ind>=7 & ind<=10) | (ind>=13 & ind<=18) 
replace ind2=5 if ind>=28 & ind<=31
replace ind2=6 if ind==32
replace ind2=7 if ind==33
replace ind2=8 if ind==34
replace ind2=9 if ind==35
gen y=qout*po
sort ind year
gen dpo=log(po/po[_n-1])*(1/2*y+1/2*y[_n-1])
collapse (sum) y  dpo , by(ind2 year)
ren ind2 ind
replace dpo=dpo/(1/2*y+1/2*y[_n-1])
sort ind year
ren dpo dp_
gen dq_ = log(y/y[_n-1])-dp_
drop if year==1960
keep dq_ year ind 
reshape wide dq_ ,  i(year) j(ind)
aorder
foreach var of varlist dq_*  {
   qui sum `var' 
   replace `var'=`var'-r(mean)
} 
outsheet using ioJ_data_dt_coarse.csv, replace delim(,)

/* Construct datasets for the two halves of the sample, separately */

insheet using ioJ_data.csv, clear
reshape wide  dq_ ,  i(year) j(ind)
aorder
keep if year<=1983
foreach var of varlist dq_*  {
   qui sum `var' 
   replace `var'=`var'-r(mean)
}
outsheet using ioJ_data_dt_early.csv, replace delim(,)

insheet using ioJ_data.csv, clear
reshape wide  dq_ ,  i(year) j(ind)
aorder
keep if year>=1984
foreach var of varlist dq_*  {
   qui sum `var' 
   replace `var'=`var'-r(mean)
}
outsheet using ioJ_data_dt_late.csv, replace delim(,)

/* Take the period length to be 2 years or 3 years */

insheet using ioJ_data_dt.csv, clear
foreach var of varlist dq_* {
  replace `var'=`var'+`var'[_n-1] if mod(_n,2)==0
}
keep if mod(_n,2)==0
outsheet using ioJ_data_dt_perl_2.csv, replace delim(,)
insheet using ioJ_data_dt.csv, clear
foreach var of varlist dq_* {
  replace `var'=`var'+`var'[_n-1]+`var'[_n-2] if mod(_n,3)==0
}
keep if mod(_n,3)==0
outsheet using ioJ_data_dt_perl_3.csv, replace delim(,)

insheet using ioJ_data.csv, clear
reshape wide  dq  ,  i(year) j(ind)
aorder
outsheet using ioJ_data.csv, replace delim(,)

/* Here we get data on the factor shares (output shares), the output shares
  (across industries) and merge in the depreciation rates.  We do this first
  for the baseline classification and the coarse (9-industry) classification
*/

insheet using bea_go_gopi_ii.csv, clear
gen ind_new=.
gen vartype=.
drop if ind=="ALL"
replace ind_new=1 if ind=="11"
replace ind_new=2 if ind=="212"
replace ind_new=3 if ind=="211" | ind=="213"
replace ind_new=4 if ind=="23" 
replace ind_new=5 if ind=="311FT"
replace ind_new=6 if ind=="313TT"
replace ind_new=7 if ind=="315AL"
replace ind_new=8 if ind=="321"
replace ind_new=9 if ind=="337"
replace ind_new=10 if ind=="322"
replace ind_new=11 if ind=="511" | ind=="323" 
replace ind_new=12 if ind=="325"
replace ind_new=13 if ind=="324"
replace ind_new=14 if ind=="326"
replace ind_new=15 if ind=="327"
replace ind_new=16 if ind=="331"
replace ind_new=17 if ind=="332"
replace ind_new=18 if ind=="333"
replace ind_new=19 if ind=="335"
replace ind_new=20 if ind=="3361MV"
replace ind_new=21 if ind=="3364OT"
replace ind_new=22 if ind=="334"
replace ind_new=23 if ind=="339"
replace ind_new=24 if ind=="48TW"
replace ind_new=25 if ind=="512" | ind=="513" | ind=="514"
replace ind_new=26 if ind=="22"
replace ind_new=27 if ind=="42" | ind=="44RT"
replace ind_new=28 if ind=="FIRE"
replace ind_new=29 if ind=="PROF" | ind=="60" | ind=="70" | ind=="81"
replace ind_new=30 if ind=="G"
replace vartype=1 if code=="GO"
replace vartype=2 if code=="II"
replace vartype=3 if code=="GOPI"
replace vartype=4 if code=="IIPI"
replace vartype=5 if code=="L"
reshape long v , i(ind vartype)  j(year)
drop code
reshape wide v , i(ind year) j(vartype)
ren v1 go
ren v2 ii
ren v3 gopi
ren v4 iipi
ren v5 ll
save dataO, replace
collapse (sum) go-ll, by(ind_new year)
ren ind_new ind
keep if year==1997
gen iak=(go-ii-ll)/go
gen ial=ll/go
gen iam=ii/go
sum go
gen shareV=go/r(sum)
keep ind iak-iam shareV
merge 1:1 ind using demandJ
drop _merge
merge 1:1 ind using drates
order iak ial iam share shareV
drop _merge ind
outsheet using dataOJ.csv, replace delim(,) nonames

use if year==1997 using dataO, replace
keep go-ll ind_new
gen ind2=1 if ind_new<=3
replace ind2=2 if ind_new==4
replace ind2=3 if ind_new==8 | ind_new==9 | (ind_new>=15 & ind_new<=23) 
replace ind2=4 if (ind_new>=5 & ind_new<=7) | (ind_new>=10 & ind_new<=14) 
replace ind2=5 if ind_new>=24 & ind_new<=26
replace ind2=6 if ind_new==27
replace ind2=7 if ind_new==28
replace ind2=8 if ind_new==29
replace ind2=9 if ind_new==30
collapse (sum) go-ll, by(ind2)
ren ind2 ind
gen iak=(go-ii-ll)/go
gen ial=ll/go
gen iam=ii/go
sum go
gen shareV=go/r(sum)
keep ind iak-iam shareV
merge 1:1 ind using demandJ_coarse
gen drate=1
replace drate=.02 if _n==2
replace drate=.14 if _n==3
order iak ial iam share shareV
drop _merge ind
outsheet using dataOJ_coarse.csv, replace delim(,) nonames

insheet using corresp.csv, clear
gen io=floor(v1/100)
bys io: keep if _n==1
drop v1
ren v2 myind
save corresp, replace
insheet using  matflow72.csv, clear
drop makevalue
drop if usevalue==0
bys column_code : egen totUse=sum(usevalue)
save use72, replace

bys col row :  egen Flow=sum(usevalue)
by col ro : keep if _n==1
keep if Flow>.01
ren col io
merge n:1 io using corresp
drop if _merge<3
drop _merge
ren io col 
ren my myC
ren row io
merge n:1 io using corresp
ren myind myR
drop if _merge<3
drop _merge 
collapse (sum) Flow, by(myR myC)
save temp72, replace
bys myC: egen s1=sum(Flow)
ren Flow frac
drop s1 
order myR myC
reshape wide frac, i(myR) j(myC)
foreach var of varlist frac* {
  replace `var'=0 if `var'==.
  sum `var'
  replace `var'=`var'/r(sum)
}
keep frac1-frac30
outsheet using dataMJ_72.csv, replace delim(,) nonames

use if myC==31 using temp72, replace
sort myR myC
egen s1=sum(Flow)
gen share=Flow/s1
ren myR groupU
keep share groupU
ren groupU ind
save demandJ72, replace

use if year==1972  using klem, replace
gen ind2=1 if ind==1
replace ind2=2 if ind==2 | ind==3 | ind==5
replace ind2=3 if ind==4
replace ind2=4 if ind==6
replace ind2=5 if ind==7 | ind==8
replace ind2=6 if ind==9
replace ind2=7 if ind==10 | ind==18
replace ind2=ind-3 if ind>=11 & ind<=17
replace ind2=ind-4 if ind>=19 & ind<=29
replace ind2=26 if ind==30 | ind==31
replace ind2=ind-5 if ind>=32 & ind<=35
gen outp=qout*po
gen ener=pe*qe
gen mate=pm*qm
gen labo=qltemp*pl
gen capi=qktemp*pk
collapse (sum) outp-capi , by(ind2 year)
ren ind2 ind
egen yyy=sum(outp)
gen shareV=outp/yyy
drop outp yyy
gen iak=capi/(mate + ener+labo+capi)
gen ial=labo/(mate + ener+labo+capi)
gen iam=(mate + ener)/(mate + ener+labo+capi)
keep ind iak-iam shareV
merge 1:1 ind using demandJ72  /* Merge in consumption shares */
drop _merge
merge 1:1 ind using drates  /* Merge in depreciation rates */
order iak ial iam share shareV
drop _merge ind
outsheet using dataOJ_72.csv, replace delim(,) nonames

/* This file is a lightly modified (just selecting the relavant rows)
 version of GDPbyInd_VA_NAICS_1997-2014.xlsx from    
  http://www.bea.gov/industry/gdpbyind_data.htm */

insheet using price_changes.csv, clear
gen sic=.
gen sic_coarse=.
/* Combine industries to get down to the 30-industry classification that is used in the paper */
replace sic=1 if naics=="111CA" |naics=="113FF"
replace sic=2 if naics=="212"
replace sic=3 if naics=="211" | naics=="213"
replace sic=4 if naics=="23" 
replace sic=5 if naics=="311FT"
replace sic=6 if naics=="313TT"
replace sic=7 if naics=="315AL"
replace sic=8 if naics=="321"
replace sic=9 if naics=="337"
replace sic=10 if naics=="322"
replace sic=11 if naics=="511" | naics=="323" 
replace sic=12 if naics=="325"
replace sic=13 if naics=="324"
replace sic=14 if naics=="326"
replace sic=15 if naics=="327"
replace sic=16 if naics=="331"
replace sic=17 if naics=="332"
replace sic=18 if naics=="333"
replace sic=19 if naics=="335"
replace sic=20 if naics=="3361MV"
replace sic=21 if naics=="3364OT"
replace sic=22 if naics=="334"
replace sic=23 if naics=="339"
replace sic=24 if substr(naics,1,2)=="48" | substr(naics,1,2)=="49"| substr(naics,1,2)=="4A"
replace sic=25 if naics=="512" | naics=="513" | naics=="514"
replace sic=26 if naics=="22"
replace sic=27 if naics=="42" | substr(naics,1,2)=="44" | substr(naics,1,2)=="45"
replace sic=28 if substr(naics,1,2)=="52" | substr(naics,1,2)=="53" | substr(naics,1,2)=="HS" | substr(naics,1,2)=="OR"
replace sic=29 if substr(naics,1,1)=="6" | substr(naics,1,1)=="7" | substr(naics,1,1)=="8" | substr(naics,1,2)=="54"|substr(naics,1,2)=="55"| substr(naics,1,2)=="56"
replace sic=30 if substr(naics,1,1)=="G"

replace sic_coarse=1 if sic<=3
replace sic_coarse=2 if sic==4
replace sic_coarse=3 if  sic==8 | sic==9 | (sic>=15 & sic<=23)   /* durable manuf. */
replace sic_coarse=4 if (sic>=5 & sic<=7) | (sic>=10 & sic<=14)  /* nondurable manuf */
replace sic_coarse=5 if sic>=24 & sic<=26
replace sic_coarse=sic-21 if sic>=27 & sic<. 
reshape long v, i(naics variable) j(year)
sort naics year
replace year=year+1994
reshape wide v, i(naics year) j(variable)
ren v2 go
sort naics year
gen price_change=ln(v1/v1[_n-1]) if year>1997
gen weight=1/2*(go+go[_n-1]) if year>1997
sort sic_coarse year
by sic_coarse year: egen numer=sum(weight*price_change)
by sic_coarse year: egen denom=sum(weight)
gen dprice_coarse=numer/denom
drop numer denom 
sort sic year
by sic year: egen numer=sum(weight*price_change)
by sic year: egen denom=sum(weight)
gen dprice=numer/denom
drop if sic==. 
drop go numer denom v1 weight  price_change
save price_changes, replace

if `create_data'==1 {
forvalues yr=1997/2013 {
/* Clean the io use tables, originally from  http://www.bea.gov/industry/io_annual.htm */
insheet using io_use_`yr'.csv, clear names   
drop commoditydescription
local count=0
foreach var of varlist ca-t007  {
  local count=`count'+1
  ren `var' v`count'
}
reshape long v, i(code) j(code_n)
by code: gen x=_n
qui sum code_n
local variable_count=r(max)
tostring code_n, replace
local var_names="111CA 113FF 211 212 213 22 23 321 327 331 332 333 334 335 3361MV 3364OT 337 339 311FT 313TT 315AL 322 323 324 325 326 42 441 445 452 4A0 481 482 483 484 485 486 487OS 493 511 512 513 514 521CI 523 524 525 HS ORE 532RL 5411 5415 5412OP 55 561 562 61 621 622 623 624 711AS 713 721 722 81 GFGD GFGN GFE GSLG GSLE F010 F02S F02E F02N F02R F030 F040 F050 F06C F06S F06E F06N F07C F07S F07E F07N F10C F10S F10E F10N T004 T007"
gen code_t=""
forvalues x=1/`variable_count' {
  qui replace code_t=word("`var_names'", `x') if code_n=="`x'"
}
drop x code_n
ren code commodity
ren code_t naics_customer
gen year=`yr'
ren v valIO
if `yr'~=1997 {
   append using iousetable
}
compress
save iousetable, replace
}

use iousetable, replace
ren commodity naics_supplier
replace naics_supplier="T007" if naics_supplier=="T008"
save iotable, replace
}

use iotable, replace
keep if naics_customer=="F050"    /* keep imports */
gen imports=-valIO
keep naics_supplier imports year
ren naics_supplier naics_customer
save imports_from_iotable, replace

/* Part 2b: This next bit of text will produce the federal spending instrument.
  Here, I take data from the 1997 io table, then compute the leontief 
  inverse of the demand linkages, then multiply this leontief inverse 
  with the share of each industry's output that is sold to the federal 
  government. The resulting vector is called federal_initial.dta .  Then, 
  to compute the year-industry instrument, I multiply this vector with 
  annual changes in federal spending.  */ 

use if year==1997 using iotable, replace
gen _cust=.
gen _supp=.
foreach s of varlist _cust _supp {
  replace `s'=1 if naics`s'=="111CA" |naics`s'=="113FF"  
  replace `s'=2 if naics`s'=="212"
  replace `s'=3 if naics`s'=="211" | naics`s'=="213"
  replace `s'=4 if naics`s'=="23" 
  replace `s'=5 if naics`s'=="311FT"
  replace `s'=6 if naics`s'=="313TT"
  replace `s'=7 if naics`s'=="315AL"
  replace `s'=8 if naics`s'=="321"
  replace `s'=9 if naics`s'=="337"
  replace `s'=10 if naics`s'=="322"
  replace `s'=11 if naics`s'=="511" | naics`s'=="323" 
  replace `s'=12 if naics`s'=="325"
  replace `s'=13 if naics`s'=="324"
  replace `s'=14 if naics`s'=="326"
  replace `s'=15 if naics`s'=="327"
  replace `s'=16 if naics`s'=="331"
  replace `s'=17 if naics`s'=="332"
  replace `s'=18 if naics`s'=="333"
  replace `s'=19 if naics`s'=="335"
  replace `s'=20 if naics`s'=="3361MV"
  replace `s'=21 if naics`s'=="3364OT"
  replace `s'=22 if naics`s'=="334"
  replace `s'=23 if naics`s'=="339"
  replace `s'=24 if substr(naics`s',1,2)=="48" | substr(naics`s',1,2)=="49"| substr(naics`s',1,2)=="4A"
  replace `s'=25 if naics`s'=="512" | naics`s'=="513" | naics`s'=="514"
  replace `s'=26 if naics`s'=="22"
  replace `s'=27 if naics`s'=="42" | substr(naics`s',1,2)=="44" | substr(naics`s',1,2)=="45"
  replace `s'=28 if substr(naics`s',1,2)=="52" | substr(naics`s',1,2)=="53" | substr(naics`s',1,2)=="HS" | substr(naics`s',1,2)=="OR"
  replace `s'=29 if substr(naics`s',1,1)=="6" | substr(naics`s',1,1)=="7" | substr(naics`s',1,1)=="8" | substr(naics`s',1,2)=="54"|substr(naics`s',1,2)=="55"| substr(naics`s',1,2)=="56"
  replace `s'=30 if substr(naics`s',1,1)=="G"
}
ren _cust sic_cust
ren _supp sic_supp
gen sic_cust_coarse=.
gen sic_supp_coarse=.
foreach s of varlist sic_cust sic_supp {
  replace `s'_coarse=1 if `s'<=3
  replace `s'_coarse=2 if `s'==4
  replace `s'_coarse=3 if  `s'==8 | `s'==9 | (`s'>=15 & `s'<=23)   /* durable manuf. */
  replace `s'_coarse=4 if (`s'>=5 & `s'<=7) | (`s'>=10 & `s'<=14)  /* nondurable manuf */
  replace `s'_coarse=5 if `s'>=24 & `s'<=26
  replace `s'_coarse=`s'-21 if `s'>=27 & `s'<.
}
replace sic_cust=30 if substr(naics_customer,1,3)=="F07"  | substr(naics_customer,1,3)=="F10"
replace sic_cust=32 if substr(naics_customer,1,3)=="F06"
replace sic_cust_coarse=9 if substr(naics_customer,1,3)=="F07" | substr(naics_customer,1,3)=="F10"
replace sic_cust_coarse=11 if substr(naics_customer,1,3)=="F06" 
replace sic_cust=31 if naics_customer=="T007"
replace sic_cust_coarse=10 if naics_customer=="T007"
ren sic_cust_coarse sic_coarse_cust
ren sic_supp_coarse sic_coarse_supp
collapse (sum) valIO, by(sic_cust sic_supp sic_coarse_cust sic_coarse_supp)
bys sic_coarse_cust sic_coarse_supp: egen valIOcoarse=sum(valIO)
drop if sic_cust==. | sic_supp==.
bys sic_supp: egen tot_send=sum(valIO*((sic_cust==31)))
bys sic_coarse_supp: egen tot_send_coarse=sum(valIO*((sic_coarse_cust==10)))
gen share_down=valIO/tot_send
gen share_down_coarse=valIOcoarse/tot_send_coarse
drop tot_send valIO valIOcoarse tot_send_coarse
drop if sic_cust==31
save federal_temporary, replace
keep sic_cust sic_supp sic_coarse_supp share_down
sort sic_supp sic_cust
reshape wide share_down, i(sic_supp sic_coarse_supp) j(sic_cust) 
replace share_down30=share_down30+share_down32
mkmat share_down1-share_down30, matrix(mat1)
mkmat share_down32, matrix(mat1_A)
matrix mat2=inv(I(30)-1*mat1)*mat1_A
svmat mat2 
ren mat21 federal_share_initial
keep federal_share_initial sic_supp sic_coarse_supp
ren sic_supp sic 
ren sic_coarse_supp sic_coarse
save federal_initial, replace

use federal_temporary, replace
keep sic_coarse_supp sic_coarse_cust share_down_coarse
bys sic_coarse_supp sic_coarse_cust: keep if _n==1
reshape wide share_down, i(sic_coarse_supp) j(sic_coarse_cust) 
mkmat share_down_coarse1-share_down_coarse9, matrix(mat1)
matrix mat2C=inv(I(9)-mat1)
matrix mat2=inv(I(9)-mat1)*mat1[1...,9]
svmat mat2
ren mat21 federal_share_initial_coarse
keep federal_share_initial sic_coarse_supp
ren sic_coarse_supp sic_coarse 
merge 1:n sic_coarse using federal_initial
drop _merge
save federal_initial, replace

use  if  substr(naics_customer,1,3)=="F06"   using iotable, replace
drop if substr(naics_supplier,1,1)=="T" | naics_supplier=="Used" | substr(naics_supplier,1,1)=="V" |  naics_supplier=="Other"
bys year: egen fed_spending=sum(valIO)
bys year: keep if _n==1
keep fed_spending year
gen federal_spending_grow=log(fed_spending/fed_spending[_n-1])
cross using federal_initial
gen federal_shock=federal_spending_grow*federal_share_initial
gen federal_shock_coarse=federal_spending_grow*federal_share_initial_coarse
keep year sic federal_shock federal_shock_coarse
sort sic year
replace federal_shock=0 if federal_shock==. & year>1997
save federal_shocks, replace

/* Beginning of part 2c */

use iotable, replace
drop if length(naics_customer)==1
replace valIO=0 if valIO==.
merge n:1 naics_cust year using  imports_from_iotable
bys naics_cust year: egen totIntermediate=max( valIO*(naics_supp=="T005")) 
bys naics_cust year: egen total=max(valIO*(naics_supp=="T007")) 
replace valIO=valIO*(totIntermediate+imports)/totIntermediate if substr(naics_supp,1,1)~="T" & substr(naics_supp,1,1)~="V" & substr(naics_supp,1,1)~="F"
replace totIntermediate=totIntermediate+imports
replace total=total+imports
bys naics_cust year: egen totalVA=max( valIO*(naics_supp=="T006"))
drop if  substr(naics_supp,1,1)=="T" | substr(naics_supp,1,1)=="V"
ren total totalCosts
sort year naics_cust naics_supp
ren naics_cust naics
drop if _merge<3
drop _merge
merge n:1 naics year using price_changes
drop _merge
foreach var of varlist sic-dprice naics {
   ren `var' `var'_cust
}
ren naics_supp naics  
merge n:1 naics year using price_changes
drop _merge
foreach var of varlist sic-dprice naics {
   ren `var' `var'_supp
}
drop if sic_cust==. | sic_supp==.
replace totalCosts=totalCosts*(naics_supp==naics_cust)
replace totIntermediate=totIntermediate*(naics_supp==naics_cust)
bys sic_cust year: egen totInt=sum(totIntermediate)
bys sic_cust year: egen totCost=sum(totalCosts)
bys sic_coarse_cust year: egen totInt_coarse=sum(totIntermediate)
bys sic_coarse_cust year: egen totCost_coarse=sum(totalCosts)
collapse (min) totInt-totCost_coarse dprice* (sum) valIO, by(sic_cust sic_supp sic_coarse_cust sic_coarse_supp year)
bys sic_coarse_cust sic_coarse_supp year: egen valIO_coarse=sum(valIO)

gen share_within=valIO/totInt
gen share_between=totInt/totCost
gen share_within_coarse=valIO_coarse/totInt_coarse
gen share_between_coarse=totInt_coarse/totCost_coarse
bys sic_coarse_cust  year: gen first_of_coarse_cust=1 if _n==1 
bys sic_coarse_cust  sic_coarse_supp year: gen first_of_coarse=1 if _n==1 
sort  sic_cust sic_supp year
gen within_grow=log(share_within/share_within[_n-1]) if year>1997
gen between_grow=log(share_between/share_between[_n-1]) if year>1997
gen dpmat_temp=(1/2*share_within+1/2*share_within[_n-1])*dprice_supp if year>1997 
bys sic_cust year: egen dpmat=sum(dpmat_temp)
drop dpmat_temp
sort first_of_coarse sic_coarse_supp sic_coarse_cust year
gen within_grow_coarse=log(share_within_coarse/share_within_coarse[_n-1]) if year>1997 & first_of_coarse==1
gen between_grow_coarse=log(share_between_coarse/share_between_coarse[_n-1]) if year>1997 & first_of_coarse==1
gen dpmat_temp=(1/2*share_within_coarse+1/2*share_within_coarse[_n-1])*dprice_coarse_supp if year>1997  & first_of_coarse==1
bys sic_coarse_cust year: egen dpmat_coarse=sum(dpmat_temp*first_of_coarse)
drop dpmat_temp
gen overall_grow=within_grow+between_grow
gen relprice_between=dprice_cust-dpmat
gen relprice_within=dpmat-dprice_supp
gen overall_grow_coarse=within_grow_coarse+between_grow_coarse
gen relprice_between_coarse=dprice_coarse_cust-dpmat_coarse
gen relprice_within_coarse=dpmat_coarse-dprice_coarse_supp
ren sic_cust sic
merge n:1 year sic using federal_shocks
ren federal_shock federal_shock_cust
ren federal_shock_coarse federal_shock_coarse_cust
drop _merge
ren sic sic_cust 
ren sic_supp sic
merge n:1 year sic using federal_shocks
ren federal_shock federal_shock_supp
ren federal_shock_coarse federal_shock_coarse_supp
drop _merge
ren sic sic_supp
sort sic_cust sic_supp year
gen lag_within=share_within[_n-1]
gen lag_within_coarse=share_within_coarse[_n-1]
gen totIntLag=totInt[_n-1]

sort sic_cust year
by  sic_cust year: egen federal_shock_inter=sum((1/2*share_within+1/2*lag_within)*federal_shock_supp)

sort  sic_coarse_supp sic_coarse_cust sic_cust year
bys  sic_coarse_cust year: egen federal_shock_inter_coarse=sum((1/2*share_within_coarse*totInt+1/2*lag_within_coarse*totIntLag)*federal_shock_supp)
bys  sic_coarse_cust year: egen federal_shock_supp_inter_denom=sum(1/2*share_within_coarse*totInt+1/2*lag_within_coarse*totIntLag)
replace federal_shock_inter_coarse=federal_shock_inter_coarse/federal_shock_supp_inter_denom
drop federal_shock_supp_inter_denom 

bys sic_cust sic_supp: egen mean_share=mean(share_within)
gsort sic_cust year -mean_share
by sic_cust year: gen rank_within_customer=_n 
bys sic_coarse_cust sic_coarse_supp: egen mean_share_coarse=mean(share_within_coarse)
gsort sic_coarse_cust   year first_of_coarse -mean_share_coarse
by  sic_coarse_cust  year : gen rank_within_customer_coarse=_n 
gen energy_group=(sic_cust==3 | sic_cust==13 | sic_cust==26)
gen sector_group=1 + (sic_cust>3) + (sic_cust>23)
sort sic_cust sic_supp year

gen dprice_coarse_cust_nondur=dprice_coarse_cust
replace dprice_coarse_cust_nondur=. if sic_coarse_cust==2 | sic_coarse_cust==3
foreach var of varlist overall_grow relprice* dprice_cust federal_shock_cust federal_shock_supp federal_shock_inter {
   gen `var'_2_years=`var'+`var'[_n-1] if  year>=1999 & mod(year,2)==1
   gen `var'_3_years=`var'+`var'[_n-1]+`var'[_n-2] if  year>=2000 & mod(year,3)==2
}
bys sic_cust sic_supp: egen count_fine=sum(overall_grow~=.)
bys sic_cust sic_supp: egen count_coarse=sum(overall_grow_coarse~=.)

label var sic_cust "Name of Downstream Industry"
label var sic_coarse_cust "Name of Downstream Industry using the 9-industry classification"
label var sic_supp "Name of Upstream Industry"
label var sic_coarse_supp "Name of Upstream Industry using the 9-industry classification"
label var totInt "Total Intermediate Purchases, as taken from row 83 from the Use tables"
label var totInt_coarse "Total Intermediate Purchases, as taken from row 83 from the Use tables, using the 9-industry classification"
label var totCost "Total Costs, as taken from row 90 from the Use tables"
label var totCost_coarse "Total Costs, as taken from row 90 from the Use tables, using the 9-industry classification" 
label var mean_share "Mean Share (over the years of the sample) of Upstream Industry, as a share of the intermediate input purchases of the downstream industry"
label var mean_share_coarse "Mean Share (over the years of the sample) of Upstream Industry, as a share of the intermediate input purchases of the downstream industry, 9-industry classification"
label var rank_within_customer "Rank of the upstream industry, in terms of importance as a supplier of intermediate inputs for the downstream industry"
label var energy_group "indicator variable, oil extraction; refining; utilities" 
label var sector_group " equals 1 for primary industries; 2 for manufacturing; 3 for services" 
label var share_within "share of upstream industry of downstream industry's intermediate input purchases"
label var share_between "share of intermediate input purchases of downstream industry's total costs"
label var share_within_coarse "share of upstream industry of downstream industry's intermediate input purchases, using the 9-industry classification"
label var share_between_coarse "share of intermediate input purchases of downstream industry's total costs, using the 9-industry classification"
label var valIO "value of shipments from upstream industry to downstream industry"
label var valIO_coarse "value of shipments from upstream industry to downstream industry, using the 9-industry classification"
label var within_grow "year over year growth in within share"
label var between_grow "year over year growth in between share"
label var within_grow_coarse "year over year growth in within share, using the 9-industry classification"
label var between_grow_coarse "year over year growth in between share, using the 9-industry classification"
label var overall_grow" year over year growtyh in within share plut between share"
label var dpmat "year over year change in the (ideal) price of the intermediate input"
label var dpmat_coarse "year over year change in the (ideal) price of the intermediate input, using the 9-industry classification"
label var dprice_cust "change in the price of the downstream industry"
label var dprice_supp "change in the price of the upstream industry"
label var dprice_coarse_cust "change in the price of the downstream industry, using the 9-industry classification"
label var dprice_coarse_supp "change in the price of the upstream industry, using the 9-industry classification"
label var relprice_within "difference between the change in the price of the intermediate input and the change in price of the upstream industry"
label var relprice_between "difference between the change in the price of the intermediate input and the change in price of the downstream industry"
label var federal_shock_supp "demand shifter for supplier (upstream) industry output due to federal spending changes"
label var federal_shock_cust "demand shifter for customer (downstream) industry output due to federal spending changes"
label var federal_shock_inter" demand shifter for the intermediate input bundle due to federal spending changes"

/* Beginning of part 2d */

/* looping over the number of observations per year-downstream industry, to be used in the regressions. */   
foreach x in 2 4 6 8 10 15 {
    local counter=0

    local counter=`counter'+1 
     gen regression_`counter'_`x'=.
     reg overall_grow relprice_within relprice_between i.year if rank_within_customer<=`x'   [aw=valIO]
     replace regression_`counter'_`x'=_b[relprice_within] in 1/1
     replace regression_`counter'_`x'=_se[relprice_within] in 2/2
     replace regression_`counter'_`x'=_b[relprice_between] in 3/3
     replace regression_`counter'_`x'=_se[relprice_between] in 4/4
     replace regression_`counter'_`x'=e(N) in 5/5
     local counter=`counter'+1
     gen regression_`counter'_`x'=.
     reg overall_grow relprice_within relprice_between  if  rank_within_customer<=`x'  [aw=valIO]
     replace regression_`counter'_`x'=_b[relprice_within] in 1/1
     replace regression_`counter'_`x'=_se[relprice_within] in 2/2
     replace regression_`counter'_`x'=_b[relprice_between] in 3/3
     replace regression_`counter'_`x'=_se[relprice_between] in 4/4
     replace regression_`counter'_`x'=e(N) in 5/5


local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow (relprice_within relprice_between= federal_shock_supp federal_shock_cust federal_shock_inter)  i.year  if rank_within_customer<=`x'  & sic_cust~=30 & sic_supp~=30  [aw=valIO]  , 
  replace regression_`counter'_`x'=_b[relprice_within] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous , forceweights
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23
  reg  relprice_within federal_shock_supp federal_shock_cust  federal_shock_inter i.year if rank_within_customer<=`x'    & sic_cust~=30 & sic_supp~=30  [aw=valIO], 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between federal_shock_supp federal_shock_cust federal_shock_inter i.year if rank_within_customer<=`x'     & sic_cust~=30 & sic_supp~=30  [aw=valIO]  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 16/16
 replace regression_`counter'_`x'=_b[federal_shock_inter] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19

 local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow (relprice_within relprice_between= federal_shock_supp federal_shock_cust federal_shock_inter)  if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30  [aw=valIO] , 
  replace regression_`counter'_`x'=_b[relprice_within] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous , forceweights
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23
  reg  relprice_within federal_shock_supp federal_shock_cust  federal_shock_inter if rank_within_customer<=`x'     & sic_cust~=30 & sic_supp~=30  [aw=valIO], 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between federal_shock_supp federal_shock_cust federal_shock_inter if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30   [aw=valIO] , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 16/16
 replace regression_`counter'_`x'=_b[federal_shock_inter] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19


    local counter=`counter'+1
     gen regression_`counter'_`x'=.
     reg overall_grow relprice_within relprice_between i.year if rank_within_customer<=`x' 
     replace regression_`counter'_`x'=_b[relprice_within] in 1/1
     replace regression_`counter'_`x'=_se[relprice_within] in 2/2
     replace regression_`counter'_`x'=_b[relprice_between] in 3/3
     replace regression_`counter'_`x'=_se[relprice_between] in 4/4
     replace regression_`counter'_`x'=e(N) in 5/5
     local counter=`counter'+1
     gen regression_`counter'_`x'=.
     reg overall_grow relprice_within relprice_between  if  rank_within_customer<=`x' 
     replace regression_`counter'_`x'=_b[relprice_within] in 1/1
     replace regression_`counter'_`x'=_se[relprice_within] in 2/2
     replace regression_`counter'_`x'=_b[relprice_between] in 3/3
     replace regression_`counter'_`x'=_se[relprice_between] in 4/4
     replace regression_`counter'_`x'=e(N) in 5/5

  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow (relprice_within relprice_between= federal_shock_supp federal_shock_cust federal_shock_inter)  i.year  if rank_within_customer<=`x'  & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[relprice_within] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous , forceweights
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23
  reg  relprice_within federal_shock_supp federal_shock_cust  federal_shock_inter i.year if rank_within_customer<=`x'    & sic_cust~=30 & sic_supp~=30 , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between federal_shock_supp federal_shock_cust federal_shock_inter i.year if rank_within_customer<=`x'     & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 16/16
 replace regression_`counter'_`x'=_b[federal_shock_inter] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19

 local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow (relprice_within relprice_between= federal_shock_supp federal_shock_cust federal_shock_inter)  if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[relprice_within] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous , forceweights
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23
  reg  relprice_within federal_shock_supp federal_shock_cust  federal_shock_inter if rank_within_customer<=`x'     & sic_cust~=30 & sic_supp~=30 , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between federal_shock_supp federal_shock_cust federal_shock_inter if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 16/16
 replace regression_`counter'_`x'=_b[federal_shock_inter] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19

  forvalues sector_idx=1/3  {

     local counter=`counter'+1
     gen regression_`counter'_`x'=.
     reg overall_grow relprice_within relprice_between i.year if rank_within_customer<=`x'  & sector_group==`sector_idx'   
     replace regression_`counter'_`x'=_b[relprice_within] in 1/1
     replace regression_`counter'_`x'=_se[relprice_within] in 2/2
     replace regression_`counter'_`x'=_b[relprice_between] in 3/3
     replace regression_`counter'_`x'=_se[relprice_between] in 4/4
     replace regression_`counter'_`x'=e(N) in 5/5
     local counter=`counter'+1
     gen regression_`counter'_`x'=.
     reg overall_grow relprice_within relprice_between  if rank_within_customer<=`x'  & sector_group==`sector_idx'   
     replace regression_`counter'_`x'=_b[relprice_within] in 1/1
     replace regression_`counter'_`x'=_se[relprice_within] in 2/2
     replace regression_`counter'_`x'=_b[relprice_between] in 3/3
     replace regression_`counter'_`x'=_se[relprice_between] in 4/4
     replace regression_`counter'_`x'=e(N) in 5/5
  
  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow (relprice_within relprice_between= federal_shock_supp federal_shock_cust federal_shock_inter)  i.year  if rank_within_customer<=`x'  & sector_group==`sector_idx'  & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[relprice_within] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous , forceweights
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23
  reg  relprice_within federal_shock_supp federal_shock_cust  federal_shock_inter i.year if rank_within_customer<=`x'  & sector_group==`sector_idx'   & sic_cust~=30 & sic_supp~=30 , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between federal_shock_supp federal_shock_cust federal_shock_inter i.year if rank_within_customer<=`x'  & sector_group==`sector_idx'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 16/16
 replace regression_`counter'_`x'=_b[federal_shock_inter] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19

 local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow (relprice_within relprice_between= federal_shock_supp federal_shock_cust federal_shock_inter)  if rank_within_customer<=`x'  & sector_group==`sector_idx'  & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[relprice_within] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous , forceweights
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23
  reg  relprice_within federal_shock_supp federal_shock_cust  federal_shock_inter if rank_within_customer<=`x'  & sector_group==`sector_idx'   & sic_cust~=30 & sic_supp~=30 , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between federal_shock_supp federal_shock_cust federal_shock_inter if rank_within_customer<=`x'  & sector_group==`sector_idx'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust] in 16/16
 replace regression_`counter'_`x'=_b[federal_shock_inter] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19
}

  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  reg overall_grow_2_years relprice_within_2_years relprice_between_2_years i.year if rank_within_customer<=`x'  , 
  replace regression_`counter'_`x'=_b[relprice_within_2_years] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_2_years] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_2_years] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_2_years] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5

  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  reg overall_grow_2_years relprice_within_2_years relprice_between_2_years if rank_within_customer<=`x'  , 
  replace regression_`counter'_`x'=_b[relprice_within_2_years] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_2_years] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_2_years] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_2_years] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5

  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow_2_years (relprice_within_2_years relprice_between_2_years= federal_shock_supp_2_years federal_shock_cust_2_years  federal_shock_inter_2_years)  i.year if rank_within_customer<=`x' & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[relprice_within_2_years] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_2_years] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_2_years] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_2_years] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous 
  replace regression_`counter'_`x'=r(p_wu) in 22/22 
  replace regression_`counter'_`x'=r(p_durbin) in 23/23 
  reg  relprice_within_2_years federal_shock_supp_2_years federal_shock_cust_2_years federal_shock_inter_2_years  i.year  if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30 , 
  replace regression_`counter'_`x'=_b[federal_shock_supp_2_years] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp_2_years] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust_2_years] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust_2_years] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter_2_years] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter_2_years] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between_2_years federal_shock_supp_2_years federal_shock_cust_2_years federal_shock_inter_2_years  i.year  if rank_within_customer<=`x' & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp_2_years] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp_2_years] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust_2_years] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust_2_years] in 16/16
  replace regression_`counter'_`x'=_b[federal_shock_inter_2_years] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter_2_years] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19 

 local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow_2_years (relprice_within_2_years relprice_between_2_years= federal_shock_supp_2_years federal_shock_cust_2_years  federal_shock_inter_2_years) if rank_within_customer<=`x' & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[relprice_within_2_years] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_2_years] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_2_years] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_2_years] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous 
  replace regression_`counter'_`x'=r(p_wu) in 22/22 
  replace regression_`counter'_`x'=r(p_durbin) in 23/23 
  reg  relprice_within_2_years federal_shock_supp_2_years federal_shock_cust_2_years federal_shock_inter_2_years  if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30 , 
  replace regression_`counter'_`x'=_b[federal_shock_supp_2_years] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_supp_2_years] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_cust_2_years] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_cust_2_years] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter_2_years] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter_2_years] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between_2_years federal_shock_supp_2_years federal_shock_cust_2_years federal_shock_inter_2_years  if rank_within_customer<=`x'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_supp_2_years] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_supp_2_years] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_cust_2_years] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_cust_2_years] in 16/16
  replace regression_`counter'_`x'=_b[federal_shock_inter_2_years] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter_2_years] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19 

  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  reg overall_grow_coarse relprice_within_coarse relprice_between_coarse i.year if rank_within_customer_coarse<=`x', 
  replace regression_`counter'_`x'=_b[relprice_within_coarse] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_coarse] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_coarse] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_coarse] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5

  local counter=`counter'+1
  gen regression_`counter'_`x'=.
  reg overall_grow_coarse relprice_within_coarse relprice_between_coarse if rank_within_customer_coarse<=`x' , 
  replace regression_`counter'_`x'=_b[relprice_within_coarse] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_coarse] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_coarse] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_coarse] in 4/4
  replace regression_`counter'_`x'=e(N) in 5/5

 local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample*/
  ivregress 2sls overall_grow_coarse (relprice_within_coarse relprice_between_coarse=  federal_shock_inter_coarse  federal_shock_coarse_supp federal_shock_coarse_cust) i.year    if rank_within_customer_coarse<=`x'    & sic_cust~=30 & sic_supp~=30   , 
  replace regression_`counter'_`x'=_b[relprice_within_coarse] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_coarse] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_coarse] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_coarse] in 4/4
 replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous 
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23 
  reg  relprice_within_coarse federal_shock_coarse_supp federal_shock_coarse_cust federal_shock_inter_coarse i.year   if rank_within_customer_coarse<=`x'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_coarse_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_coarse_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_coarse_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_coarse_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter_coarse] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter_coarse] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between_coarse federal_shock_coarse_supp federal_shock_coarse_cust  federal_shock_inter_coarse  i.year  if rank_within_customer_coarse<=`x'   & sic_cust~=30 & sic_supp~=30   , 
  replace regression_`counter'_`x'=_b[federal_shock_coarse_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_coarse_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_coarse_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_coarse_cust] in 16/16
  replace regression_`counter'_`x'=_b[federal_shock_inter_coarse] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter_coarse] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19

 local counter=`counter'+1
  gen regression_`counter'_`x'=.
  /* when the federal spending variable is used as an instrument, drop the government industry (industry 30) from the sample */
  ivregress 2sls overall_grow_coarse (relprice_within_coarse relprice_between_coarse= federal_shock_coarse_supp federal_shock_coarse_cust federal_shock_inter_coarse) if rank_within_customer_coarse<=`x' & sic_cust~=30 & sic_supp~=30   , 

  replace regression_`counter'_`x'=_b[relprice_within_coarse] in 1/1
  replace regression_`counter'_`x'=_se[relprice_within_coarse] in 2/2
  replace regression_`counter'_`x'=_b[relprice_between_coarse] in 3/3
  replace regression_`counter'_`x'=_se[relprice_between_coarse] in 4/4
  replace regression_`counter'_`x'=e(N) in 5/5
  estat first
  replace regression_`counter'_`x'=r(mineig) in 20/20
  matrix temp_matrix=r(mineigcv)
  replace regression_`counter'_`x'=temp_matrix[2,1] in 21/21
  estat endogenous 
  replace regression_`counter'_`x'=r(p_wu) in 22/22
  replace regression_`counter'_`x'=r(p_durbin) in 23/23 
  reg  relprice_within_coarse federal_shock_coarse_supp federal_shock_coarse_cust federal_shock_inter_coarse  if rank_within_customer_coarse<=`x'   & sic_cust~=30 & sic_supp~=30  , 
  replace regression_`counter'_`x'=_b[federal_shock_coarse_supp] in 6/6
  replace regression_`counter'_`x'=_se[federal_shock_coarse_supp] in 7/7
  replace regression_`counter'_`x'=_b[federal_shock_coarse_cust] in 8/8
  replace regression_`counter'_`x'=_se[federal_shock_coarse_cust] in 9/9
  replace regression_`counter'_`x'=_b[federal_shock_inter_coarse] in 10/10
  replace regression_`counter'_`x'=_se[federal_shock_inter_coarse] in 11/11
  replace regression_`counter'_`x'=e(F) in 12/12
  reg  relprice_between_coarse federal_shock_coarse_supp federal_shock_coarse_cust federal_shock_inter_coarse  if rank_within_customer_coarse<=`x'   & sic_cust~=30 & sic_supp~=30   , 
  replace regression_`counter'_`x'=_b[federal_shock_coarse_supp] in 13/13
  replace regression_`counter'_`x'=_se[federal_shock_coarse_supp] in 14/14
  replace regression_`counter'_`x'=_b[federal_shock_coarse_cust] in 15/15
  replace regression_`counter'_`x'=_se[federal_shock_coarse_cust] in 16/16
  replace regression_`counter'_`x'=_b[federal_shock_inter_coarse] in 17/17
  replace regression_`counter'_`x'=_se[federal_shock_inter_coarse] in 18/18
  replace regression_`counter'_`x'=e(F) in 19/19
}

/* Create Figures 1-2, 5-6 of the paper */
replace relprice_within=-relprice_within 
replace relprice_between=-relprice_between

tostring year, gen(yr)
replace yr=substr(yr,3,4)
graph twoway (lfit within_grow relprice_within if sic_cust==8 & rank_within_customer==1, color(black))  (scatter within_grow relprice_within if sic_cust==8 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the Cost Share" "of the Top Interm. Input") xtitle("Change in the Relative Price of" "the Top Intermediate Input")  title("Lumber")
graph save  scatter_within_1.gph, replace
graph twoway (lfit within_grow relprice_within if sic_cust==9 & rank_within_customer==1, color(black))  (scatter within_grow relprice_within if sic_cust==9 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the Cost Share" "of the Top Interm. Input") xtitle("Change in the Relative Price of" "the Top Intermediate Input") xlab(-.06(0.03).06) title("Furniture") 
graph save  scatter_within_2.gph, replace
graph twoway (lfit within_grow relprice_within if sic_cust==15 & rank_within_customer==1, color(black))  (scatter within_grow relprice_within if sic_cust==15 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the Cost Share" "of the Top Interm. Input") xtitle("Change in the Relative Price of" "the Top Intermediate Input") xlab(-.03(0.02).03) title("Non-Metallic Minerals")
graph save  scatter_within_3.gph, replace
graph twoway (lfit within_grow relprice_within if sic_cust==26 & rank_within_customer==1, color(black))  (scatter within_grow relprice_within if sic_cust==26 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the Cost Share" "of the Top Interm. Input") xtitle("Change in the Relative Price of" "the Top Intermediate Input") xlab(-.3(0.1).3) title("Electric/Gas Utilities")
graph save  scatter_within_4.gph, replace
graph combine scatter_within_1.gph scatter_within_2.gph scatter_within_3.gph scatter_within_4.gph , rows(2) 
graph export within_scatter.eps, replace

graph twoway (lfit between_grow relprice_between if sic_cust==8 & rank_within_customer==1, color(black))  (scatter between_grow relprice_between if sic_cust==8 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the" "Interm. Input Cost Share") xtitle("Change in Relative Price of" "Intermediate Inputs")  title("Lumber")
graph save  scatter_between_1.gph, replace
graph twoway (lfit between_grow relprice_between if sic_cust==9 & rank_within_customer==1, color(black))  (scatter between_grow relprice_between if sic_cust==9 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the" "Interm. Input Cost Share") xtitle("Change in Relative Price of" "Intermediate Inputs") xlab(-.04(0.02).04) title("Furniture") 
graph save  scatter_between_2.gph, replace
graph twoway (lfit between_grow relprice_between if sic_cust==15 & rank_within_customer==1, color(black))  (scatter between_grow relprice_between if sic_cust==15 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the" "Interm. Input Cost Share") xtitle("Change in Relative Price of" "Intermediate Inputs") xlab(-.03(0.02).03) title("Non-Metallic Minerals")
graph save  scatter_between_3.gph, replace
graph twoway (lfit between_grow relprice_between if sic_cust==26 & rank_within_customer==1, color(black))  (scatter between_grow relprice_between if sic_cust==26 & rank_within_customer==1, mlabel(yr) mlabpos(0) mlabcolor(black) msym(i)),  legend(off) ytitle("Change in the" "Interm. Input Cost Share") xtitle("Change in Relative Price of" "Intermediate Inputs") xlab(-.15(0.05).10) title("Electric/Gas Utilities")
graph save  scatter_between_4.gph, replace
graph combine scatter_between_1.gph scatter_between_2.gph scatter_between_3.gph scatter_between_4.gph , rows(2) 
graph export between_scatter.eps, replace

local names "Agric Mining Oil Cnstr Food Txtile Clothes Lumber Frntre Paper Print Chem Petrl Plastic Stone PrMetal FbMetal OthMach ElcMach Autos OthTrans Instrum. Misc. Transport Communic. Utilities Whole/Retail FIRE OthSrv Government"
if `makeplots'==1 {

forvalues x=1/6 {
local x1=`x'*5-4
local x2=`x'*5-3
local x3=`x'*5-2
local x4=`x'*5-1
local x5=`x'*5
local nm1=word("`names'", `x1')
local nm2=word("`names'", `x2')
local nm3=word("`names'", `x3')
local nm4=word("`names'", `x4')
local nm5=word("`names'", `x5')
di "`nm1'"
 graph twoway (lpoly between_grow relprice_between if sic_cust==`x1' & rank_within_customer==1) (lpoly between_grow relprice_between if sic_cust==`x2' & rank_within_customer==1, lcolor(black) lpattern(dash)) (lpoly between_grow relprice_between if sic_cust==`x3' & rank_within_customer==1, lpattern(longdash)) (lpoly between_grow relprice_between if sic_cust==`x4' & rank_within_customer==1, lwidth(thick)) (lpoly between_grow relprice_between if sic_cust==`x5' & rank_within_customer==1,  lwidth(thick) lpattern(dash)) , legend(lab(1 "`nm1'") lab(2 "`nm2'") lab(3 "`nm3'")  lab(4 "`nm4'") lab(5 "`nm5'") rows(2) size(small) region(lwidth(none) )) xtitle("") ytitle("")  
graph save relationship_between_`x'.gph, replace
 graph twoway (lpoly within_grow relprice_within if sic_cust==`x1' & rank_within_customer==1) (lpoly within_grow relprice_within if sic_cust==`x2' & rank_within_customer==1, lcolor(black) lpattern(dash)) (lpoly within_grow relprice_within if sic_cust==`x3' & rank_within_customer==1, lpattern(longdash)) (lpoly within_grow relprice_within if sic_cust==`x4' & rank_within_customer==1, lwidth(thick)) (lpoly within_grow relprice_within if sic_cust==`x5' & rank_within_customer==1, lwidth(thick) lpattern(dash)) , legend(lab(1 "`nm1'") lab(2 "`nm2'") lab(3 "`nm3'")  lab(4 "`nm4'") lab(5 "`nm5'") rows(2)  size(small) region(lwidth(none) )) xtitle("") ytitle("") 
graph save relationship_within_`x'.gph, replace
}
graph combine relationship_between_1.gph relationship_between_2.gph relationship_between_3.gph relationship_between_4.gph relationship_between_5.gph relationship_between_6.gph , rows(2) xsize(5.5) ysize(4.1) 
graph export between_graphs.eps, replace
graph combine relationship_within_1.gph relationship_within_2.gph relationship_within_3.gph relationship_within_4.gph relationship_within_5.gph relationship_within_6.gph, rows(2) xsize(5.5) ysize(4.1) 
graph export within_graphs.eps, replace
}

keep reg*
keep in 1/23
save all_regression_results_us, replace

/* Last couple hundred lines of code: put together the material for the middle columns of Table 11, which requires 
  constructing a similar dataset of price changes and input usage changes for a 67 industry classification (the BEA's 
  71 industry classification with the five government sectors collapsed into one). */

insheet using price_changes.csv, clear
local naics = "111CA 113FF 211 212 213 22 23 321 327 331 332 333 334 335 3361MV 3364OT 337 339 311FT 313TT 315AL 322 323 324 325 326 42 441 445 452 4A0 481 482 483 484 485 486 487OS 493 511 512 513 514 521CI 523 524 525 HS ORE 532RL 5411 5415 5412OP 55 561 562 61 621 622 623 624 711AS 713 721 722 81"
local counter = 0
gen index =.
foreach x of local naics {
	local counter = `counter'+1
	qui replace index = `counter' if naics == "`x'"
}
	qui replace index = 70 if substr(naics,1,1) == "G"

qui reshape long v, i(naics index variable) j(year)
sort naics year
qui replace year=year+1994
qui reshape wide v, i(naics index year) j(variable)
qui rename v2 go
qui gen price_change = ln(v1/v1[_n-1]) if year>1997
qui gen weight=1/2*(go+go[_n-1]) if year>1997
bys index year: egen numer=sum(weight*price_change)
bys index year: egen denom=sum(weight)
gen dp=numer/denom
collapse (max) dp, by(year index)
save price_changes67, replace

forvalues yr=1997/2013 {
	/* Clean the io use tables, originally from  http://www.bea.gov/industry/io_annual.htm */
	qui insheet using io_use_`yr'.csv, clear names   
	qui drop commoditydescription
	local count=0
	foreach var of varlist ca-t007  {
		local count=`count'+1
		qui ren `var' v`count'
	}
	qui reshape long v, i(code) j(code_n)
	by code: gen x=_n
	qui sum code_n
	local variable_count=r(max)
	qui tostring code_n, replace
	local var_names="111CA 113FF 211 212 213 22 23 321 327 331 332 333 334 335 3361MV 3364OT 337 339 311FT 313TT 315AL 322 323 324 325 326 42 441 445 452 4A0 481 482 483 484 485 486 487OS 493 511 512 513 514 521CI 523 524 525 HS ORE 532RL 5411 5415 5412OP 55 561 562 61 621 622 623 624 711AS 713 721 722 81 GFGD GFGN GFE GSLG GSLE F010 F02S F02E F02N F02R F030 F040 F050 F06C F06S F06E F06N F07C F07S F07E F07N F10C F10S F10E F10N T004 T007"
	qui gen code_t=""
	forvalues x=1/`variable_count' {
		qui replace code_t=word("`var_names'", `x') if code_n=="`x'"
	}
	qui drop x code_n
	qui ren code naics_s
	qui ren code_t naics_c
	qui gen year=`yr'
	qui ren v valIO
	if `yr'~=1997 {
		append using iousetable67
	}
	compress
	save iousetable67, replace
}

* Index the sectors. 

use iousetable67, clear
gen ind_c =.
gen ind_s =.

local naics = "111CA 113FF 211 212 213 22 23 321 327 331 332 333 334 335 3361MV 3364OT 337 339 311FT 313TT 315AL 322 323 324 325 326 42 441 445 452 4A0 481 482 483 484 485 486 487OS 493 511 512 513 514 521CI 523 524 525 HS ORE 532RL 5411 5415 5412OP 55 561 562 61 621 622 623 624 711AS 713 721 722 81"
local counter = 0
foreach x of local naics {
	local counter = `counter'+1
	qui replace ind_c = `counter' if naics_c == "`x'"
	qui replace ind_s = `counter' if naics_s == "`x'"
}
local nm "c s"
foreach x of local nm {
	qui replace ind_`x' = 70 if substr(naics_`x',1,1) == "G"
}
qui replace ind_c=91 if substr(naics_c,1,3)=="F06" /*federal national defense*/
qui replace ind_c=70 if substr(naics_c,1,3)=="F07" /*federal national nondefense*/
qui replace ind_c=70 if substr(naics_c,1,3)=="F10" /*state & local gov*/
qui replace ind_c=95 if naics_c=="F050"/*import*/
qui replace ind_c=98 if naics_c=="T004"/*total commodity GDP*/
qui replace ind_c=99 if naics_c=="T007"/*total commodity output*/
qui replace ind_s=97 if naics_s=="T005"/*total intermediate use by industry*/
qui replace ind_s=98 if naics_s=="T006"/*total industry GDP*/
qui replace ind_s=99 if naics_s=="T008"/*total industry output*/
qui drop if ind_s ==. | ind_c==.
collapse (sum) valIO, by(ind_s ind_c year)
sort year ind_s ind_c
save iotable67, replace

* Indexing finished

use iotable67, clear
qui keep if ind_c == 95    /* keep imports */
qui drop if ind_s > 90
qui gen imports=-valIO
qui keep ind_s imports year
qui rename ind_s commodity
save imports67, replace

use if year==1997 using iotable67, clear
drop if ind_c == 95 | ind_c == 98 | ind_s > 90
bys ind_s: egen tot_send = sum(valIO*((ind_c==99)))
gen share_down=valIO/tot_send
save federal_temporary67, replace

use federal_temporary67, clear
drop valIO tot_send year
drop if ind_c == 99
reshape wide share_down, i(ind_s) j(ind_c)
replace share_down70=share_down91+share_down70
mkmat share_down1-share_down70, matrix(mat1)
mkmat share_down91, matrix(mat1_A)
matrix mat2=inv(I(67)-1*mat1)*mat1_A
svmat mat2 
ren mat21 federal_share_initial
keep federal_share_initial  ind_s
save federal_initial67, replace

use if ind_c == 91 using iotable67, replace
keep if ind_s < 90
bys year: egen fed_spending=sum(valIO)
bys year: keep if _n==1
keep fed_spending year
gen federal_spending_within=log(fed_spending/fed_spending[_n-1])
cross using federal_initial67
gen federal_shock=federal_spending_within*federal_share_initial
keep year ind_s federal_shock
rename ind_s index
save federal_shocks67, replace

use iotable67, replace
rename ind_c commodity
merge n:1 commodity year using imports67
rename commodity ind_c
/* The merge is matched on all producing sectors include those 80s sectors. 
Data that exist for master file only are the ones with ind_c>90*/
rename import import_c
qui bys ind_c year: egen TotInt_c=max( valIO*(ind_s==97)) 
qui bys ind_c year: egen GO_c=max(valIO*(ind_s==99)) 
qui replace valIO = valIO*(TotInt_c + import_c)/TotInt_c
qui replace TotInt_c = TotInt_c + import_c
qui replace GO_c = GO_c + import_c

qui drop if ind_s>90
qui drop if _merge<3
qui drop _merge

rename ind_s index
merge n:1 index year using price_changes67
/* All matched*/
drop _merge
rename dp dp_s
rename index ind_s

rename ind_c index
merge n:1 index year using price_changes67
/*All mathced*/
drop _merge
rename index ind_c
rename dp dp_c

qui gen share_within = valIO / TotInt_c
qui gen share_between = TotInt_c/ GO_c
sort ind_c ind_s year
qui gen g_within=ln(share_within/share_within[_n-1]) if year>1997
qui gen g_between=ln(share_between/share_between[_n-1]) if year>1997
qui gen dpmat_temp=(1/2*share_within+1/2*share_within[_n-1])*dp_s if year>1997 
bys ind_c year: egen dpmat=total(dpmat_temp)
drop dpmat_temp
replace dpmat=. if year == 1997

gen g_all=g_within+g_between
gen rp_b=dp_c-dpmat
gen rp_w=dpmat-dp_s

rename ind_c index 
merge n:1 index year using federal_shocks67 /* All matched*/
rename federal_shock shock_c
drop _merge
rename index ind_c

rename ind_s index
merge n:1 index year using federal_shocks67 /* All matched*/
rename federal_shock shock_s
drop _merge
rename index ind_s

sort ind_c ind_s year
gen lag_within=share_within[_n-1]
replace lag_within =. if year == 1997
gen TotIntLag=TotInt_c[_n-1]
replace TotIntLag =. if year == 1997
sort ind_c year
by ind_c year: egen shock_int=sum((1/2*share_within+1/2*lag_within)*shock_s)

bys ind_c ind_s: egen mean_share=mean(share_within)
gsort ind_c year -mean_share
by ind_c year: gen rank=_n 

label var ind_c "Downstream Industry"
label var ind_s "Upstream Industry"
label var TotInt_c "Total Intermediate Purchases, as taken from row 83 from the Use tables"
label var GO_c "Total Costs, as taken from row 90 from the Use tables"
label var mean_share "Mean Share (over the years of the sample) of Upstream Industry, as a share of the intermediate input purchases of the downstream industry"
label var rank "Rank of the upstream industry, in terms of importance as a supplier of intermediate inputs for the downstream industry"
label var share_within "share of upstream industry of downstream industry's intermediate input purchases"
label var share_between "share of intermediate input purchases of downstream industry's total costs"
label var valIO "value of shipments from upstream industry to downstream industry"
label var g_within "year over year growth in within share"
label var g_between "year over year growth in between share"
label var g_all" year over year growtyh in within share plut between share"
label var dpmat "year over year change in the (ideal) price of the intermediate input"
label var dp_c "change in the price of the downstream industry"
label var dp_s "change in the price of the upstream industry"
label var rp_w "difference between the change in the price of the intermediate input and the change in price of the upstream industry"
label var rp_b "difference between the change in the price of the intermediate input and the change in price of the downstream industry"
label var shock_s "demand shifter for supplier (upstream) industry output due to federal spending changes"
label var shock_c "demand shifter for customer (downstream) industry output due to federal spending changes"
label var shock_int" demand shifter for the intermediate input bundle due to federal spending changes"
save before_regression67, replace

local counter = 0
* R2-1. Without instrument, with year fixed effect
	local counter=`counter'+1
	gen regression_`counter'_10=.
	reg g_all rp_w rp_b i.year if rank<=10 
	replace regression_`counter'_10=_b[rp_w] in 1/1
	replace regression_`counter'_10=_se[rp_w] in 2/2
	replace regression_`counter'_10=_b[rp_b] in 3/3
	replace regression_`counter'_10=_se[rp_b] in 4/4
	replace regression_`counter'_10=e(N) in 5/5
	
* R2-2. Without instrument, without year fixed effect
	local counter=`counter'+1
	gen regression_`counter'_10=.
	reg g_all rp_w rp_b  if  rank<=10 
	replace regression_`counter'_10=_b[rp_w] in 1/1
	replace regression_`counter'_10=_se[rp_w] in 2/2
	replace regression_`counter'_10=_b[rp_b] in 3/3
	replace regression_`counter'_10=_se[rp_b] in 4/4
	replace regression_`counter'_10=e(N) in 5/5

* R2-3. With instrument, with year fixed effect
	local counter=`counter'+1
	gen regression_`counter'_10=.
	/* when the federal spending variable is used as an instrument, 
	drop the government industry (industry>70) from the sample*/
	ivregress 2sls g_all (rp_w rp_b= shock_s shock_c shock_int)  i.year  if rank<=10  & ind_c<70 & ind_s<70  , 
	replace regression_`counter'_10=_b[rp_w] in 1/1
	replace regression_`counter'_10=_se[rp_w] in 2/2
	replace regression_`counter'_10=_b[rp_b] in 3/3
	replace regression_`counter'_10=_se[rp_b] in 4/4
	replace regression_`counter'_10=e(N) in 5/5
	estat first
	replace regression_`counter'_10=r(mineig) in 20/20
	matrix temp_matrix=r(mineigcv)
	replace regression_`counter'_10=temp_matrix[2,1] in 21/21
	estat endogenous , forceweights
	replace regression_`counter'_10=r(p_wu) in 22/22
	replace regression_`counter'_10=r(p_durbin) in 23/23

	reg  rp_w shock_s shock_c  shock_int i.year if rank<=10    & ind_c<70 & ind_s<70 , 
	replace regression_`counter'_10=_b[shock_s] in 6/6
	replace regression_`counter'_10=_se[shock_s] in 7/7
	replace regression_`counter'_10=_b[shock_c] in 8/8
	replace regression_`counter'_10=_se[shock_c] in 9/9
	replace regression_`counter'_10=_b[shock_int] in 10/10
	replace regression_`counter'_10=_se[shock_int] in 11/11
	replace regression_`counter'_10=e(F) in 12/12
	
	reg  rp_b shock_s shock_c shock_int i.year if rank<=10     & ind_c<70 & ind_s<70  , 
	replace regression_`counter'_10=_b[shock_s] in 13/13
	replace regression_`counter'_10=_se[shock_s] in 14/14
	replace regression_`counter'_10=_b[shock_c] in 15/15
	replace regression_`counter'_10=_se[shock_c] in 16/16
	replace regression_`counter'_10=_b[shock_int] in 17/17
	replace regression_`counter'_10=_se[shock_int] in 18/18
	replace regression_`counter'_10=e(F) in 19/19

* R2-4. With instrument, without year fixed effect
	local counter=`counter'+1
	gen regression_`counter'_10=.
	/* when the federal spending variable is used as an instrument, 
	drop the government industry (industry>70) from the sample*/
	ivregress 2sls g_all (rp_w rp_b= shock_s shock_c shock_int)  if rank<=10   & ind_c<70 & ind_s<70  , 
	replace regression_`counter'_10=_b[rp_w] in 1/1
	replace regression_`counter'_10=_se[rp_w] in 2/2
	replace regression_`counter'_10=_b[rp_b] in 3/3
	replace regression_`counter'_10=_se[rp_b] in 4/4
	replace regression_`counter'_10=e(N) in 5/5
	estat first
	replace regression_`counter'_10=r(mineig) in 20/20
	matrix temp_matrix=r(mineigcv)
	replace regression_`counter'_10=temp_matrix[2,1] in 21/21
	estat endogenous , forceweights
	replace regression_`counter'_10=r(p_wu) in 22/22
	replace regression_`counter'_10=r(p_durbin) in 23/23

	reg  rp_w shock_s shock_c  shock_int if rank<=10     & ind_c<70 & ind_s<70 , 
	replace regression_`counter'_10=_b[shock_s] in 6/6
	replace regression_`counter'_10=_se[shock_s] in 7/7
	replace regression_`counter'_10=_b[shock_c] in 8/8
	replace regression_`counter'_10=_se[shock_c] in 9/9
	replace regression_`counter'_10=_b[shock_int] in 10/10
	replace regression_`counter'_10=_se[shock_int] in 11/11
	replace regression_`counter'_10=e(F) in 12/12

	reg  rp_b shock_s shock_c shock_int if rank<=10   & ind_c<70 & ind_s<70  , 
	replace regression_`counter'_10=_b[shock_s] in 13/13
	replace regression_`counter'_10=_se[shock_s] in 14/14
	replace regression_`counter'_10=_b[shock_c] in 15/15
	replace regression_`counter'_10=_se[shock_c] in 16/16
	replace regression_`counter'_10=_b[shock_int] in 17/17
	replace regression_`counter'_10=_se[shock_int] in 18/18
	replace regression_`counter'_10=e(F) in 19/19

keep reg*
keep in 1/23
save regression_results_us67, replace

use all_regression_results_us, replace
keep regression_*10
keep regression_5-regression_8
foreach var of varlist regression* {
   replace `var'=`var'+1 in 1/1
   replace `var'=`var'+1 in 3/3
}
order regression_6 regression_5 regression_8 regression_7
outsheet using  regression_table_1.csv, replace delim(,)  /* This is Table 1 of the paper, in Section 3 */

use all_regression_results_us, replace
keep regression_*10
keep regression_21-regression_28
merge using regression_results_us67
drop _merge
foreach var of varlist regression* {
   replace `var'=`var'+1 in 1/1
   replace `var'=`var'+1 in 3/3
}
order regression_22 regression_21  regression_24 regression_23 regression_2_10  regression_1_10 regression_4_10 regression_3_10 regression_26 regression_25 
outsheet using regression_table_11.csv, replace delim(,)  /* This is Table 11 of the paper, in Appendix D2 */

use all_regression_results_us, replace
keep regression_*10
keep regression_10-regression_12  regression_14-regression_16  regression_14-regression_16 regression_18-regression_20
foreach var of varlist regression* {
   replace `var'=`var'+1 in 1/1
   replace `var'=`var'+1 in 3/3
}
order regression_10 regression_12 regression_11  regression_14 regression_16 regression_15 regression_18 regression_20 regression_19
outsheet using regression_table_12.csv, replace delim(,)  /* This is Table 12 of the paper, in Appendix D2 */

use all_regression_results_us, replace
keep regression_7_4 regression_8_4  regression_7_8 regression_8_8  regression_7_15 regression_8_15
order regression_8_4  regression_7_4  regression_8_8  regression_7_8  regression_8_15  regression_7_15
foreach var of varlist regression* {
   replace `var'=`var'+1 in 1/1
   replace `var'=`var'+1 in 3/3
}
outsheet using  regression_table_13.csv, replace delim(,)  /* This is Table 13 of the paper, in Appendix D2 */

insheet using dataOJ.csv, clear
keep v1-v5
outsheet using table7.csv, replace delim(,) /* This is Table 7 of the paper, in Appendix A */
